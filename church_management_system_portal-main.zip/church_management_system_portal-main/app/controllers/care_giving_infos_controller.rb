class CareGivingInfosController < ApplicationController
  before_action :set_care_giving_info, only: %i[ show edit update destroy ]

  # GET /care_giving_infos or /care_giving_infos.json
  def index
    # @care_giving_infos = CareGivingInfo.all
  end

  def care_giving_infos_index
    @person_infos = PersonInfo.where(assigned_code: params[:main_code], del_status: false)
    @person_info = PersonInfo.where(assigned_code: params[:main_code], active_status:true).order('person_infos.created_at desc').first

    @condition_search = PersonConditionType.where(active_status: true).order(condition_desc: :desc)
    @facility_name_search = CareGivingInfo.where(active_status: true).order(facility_name: :desc)
    @username_search = User.unscoped.user_join.where("ur.active_status is true AND main_code = '#{params[:main_code]}'").order(username: :desc)

    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    if params[:count] == "All"
      @care_giving_infos = CareGivingInfo.where(person_assigned_code: params[:main_code],active_status: true)
      saved_size = @care_giving_infos.exists? ? @care_giving_infos.size : 0
      @care_giving_infos = CareGivingInfo.where(person_assigned_code: params[:main_code],active_status: true).paginate(page: 1, per_page: saved_size).order("created_at desc")
    else

      the_search = ""
      search_arr = ["person_assigned_code = '#{params[:main_code]}' AND del_status = false"]

      if params[:filter_main].present? || params[:condition_type_code].present? || params[:facility_type].present? || params[:user_id].present?|| params[:facility_name].present? || params[:activity_code].present? || params[:active_status].present? || params[:start_date].present? || params[:end_date].present?

        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @condition_type_code = filter_params[:condition_type_code]
          @facility_type = filter_params[:facility_type]
          @facility_name = filter_params[:facility_name]
          @user_id = filter_params[:user_id]
          @active_status = filter_params[:active_status]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:condition_type_code] = filter_params[:condition_type_code]
          params[:facility_type] = filter_params[:facility_type]
          params[:facility_name] = filter_params[:facility_name]
          params[:user_id] = filter_params[:user_id]
          params[:active_status] = filter_params[:active_status]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]
        else

          if  params[:condition_type_code].present?  || params[:facility_type].present? || params[:facility_name].present? || params[:user_id].present? || params[:active_status].present? || params[:start_date].present? || params[:end_date].present? # || params[:trans_id].present? || params[:nw].present? || params[:status].present? || params[:start_date].present? || params[:end_date].present?

            @condition_type_code = params[:condition_type_code]
            @facility_type = params[:facility_type]
            @facility_name = params[:facility_name]
            @user_id = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:condition_type_code] = @condition_type_code
            params[:facility_type] = @facility_type
            params[:facility_name] = @facility_name
            params[:user_id] = @user_id
            params[:active_status] = @active_status
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:condition_type_code] = filter_params[:condition_type_code]
            params[:facility_type] = filter_params[:facility_type]
            params[:facility_name] = filter_params[:facility_name]
            params[:user_id] = filter_params[:user_id]
            params[:active_status] = filter_params[:active_status]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          end
        end

        if @condition_type_code.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "condition_type_code = '#{@condition_type_code}'"
        end

        if @facility_name.present?
          search_arr << "facility_name = '#{@assign_code}'"
        end
        if @user_id.present?
          search_arr << "user_id = '#{@user_id}'"
        end
        if @active_status.present?
          #search_arr << "service_label = '#{@serv_label}'"
          search_arr << "active_status = '#{@active_status}'"
        end
        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
        # $service_filter = ""
        filter_params = ""
      end


      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"

      @division_search = CareGivingInfo.where(person_assigned_code: params[:main_code], active_status: true).order(condition_type_code: :asc)
      @username_search = User.unscoped.user_join.where("ur.active_status is true AND main_code = '#{params[:main_code]}'").order(username: :desc)

      @care_giving_infos = CareGivingInfo.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

    end
  end

  def create
    @care_giving_info = CareGivingInfo.new(care_giving_info_params)
    respond_to do |format|
      if @care_giving_info.valid?
        @care_giving_info.save(validate: false)
        care_giving_infos_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Care Giving was successfully created."
        format.js { render "/care_giving_infos/care_giving_infos_index" }
        format.html { redirect_to care_giving_infos_path(id: @care_giving_info.id), notice: 'Care Giving was successfully created.' }
        format.json { render :index, status: :created, location: @care_giving_info }
      else
        logger.info "error messages #{@care_giving_info.errors.messages.inspect}"
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @care_giving_info.errors, status: :unprocessable_entity }

        @condition_search = PersonConditionType.where(active_status: true).order(condition_desc: :desc)
      end
    end
  end

  def update
    respond_to do |format|
      @care_giving_info = CareGivingInfo.where(active_status: true, id: params[:id]).order(created_at: :desc).first
      flash.now[:notice] = "Care Giving was updated successfully."

      logger.info params[:care_giving_info].inspect
      @new_record = CareGivingInfo.new(care_giving_info_params)

      @new_record.person_assigned_code = @care_giving_info.person_assigned_code
      if @new_record.valid?
        @care_giving_info.active_status = false
        @care_giving_info.del_status = true
        @care_giving_info.save(validate: false)
        if @new_record.save
        else
          # CareGivingInfo.update_last_but_one("care_giving_infos", @care_giving_info.person_assigned_code , prev_updated_at)
        end
        care_giving_infos_index
        format.js { render "/care_giving_infos/care_giving_infos_index" }
        format.html { redirect_to care_giving_infos_path, notice: 'Care Giving was updated successfully.' }
        format.json { render :care_giving_info_index, status: :ok, location: @care_giving_info }
      else
        logger.info "Division Error Messages Edit :: #{@new_record.errors.messages.inspect}"

        format.html {render :edit}
        format.js { render :edit }
        format.json { render json: @care_giving_info.errors, status: :unprocessable_entity }

        @condition_search = PersonConditionType.where(active_status: true).order(condition_desc: :desc)
      end
    end
  end
  # GET /care_giving_infos/1 or /care_giving_infos/1.json
  def show
  end

  # GET /care_giving_infos/new
  def new
    @condition_search = PersonConditionType.where(active_status: true).order(condition_desc: :desc)
    @care_giving_info = CareGivingInfo.new
  end

  # GET /care_giving_infos/1/edit
  def edit
    @condition_search = PersonConditionType.where(active_status: true).order(condition_desc: :desc)

    @care_giving_info.start_date = @care_giving_info.start_date.strftime('%Y-%m-%d') if @care_giving_info.start_date != nil
    @care_giving_info.end_date = @care_giving_info.end_date.strftime('%Y-%m-%d') if @care_giving_info.end_date != nil

  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_care_giving_info
      @care_giving_info = CareGivingInfo.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def care_giving_info_params
      params.require(:care_giving_info).permit(:person_assigned_code, :condition_type_code, :start_date, :end_date, :facility_type, :facility_name, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
