class CityTownMastersController < ApplicationController
  before_action :set_city_town_master, only: [:show, :edit, :update, :destroy]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /city_town_masters or /city_town_masters.json
  def index
    # @city_town_masters = CityTownMaster.all
  end

  def city_town_masters_index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @city_town_name_search = CityTownMaster.where(del_status: false).order(city_town_name: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)
    @region_desc_search = RegionMaster.where(del_status: false).order(region_desc: :desc)

    if params[:count] == "All"
      @city_town_masters = CityTownMaster.where(active_status: true).order('created_at desc')
      saved_size = @city_town_masters.exists? ? @city_town_masters.size : 0
      @city_town_masters = CityTownMaster.where(active_status: true).paginate(page: 1, per_page: saved_size).order("id desc")
    else

      the_search = ""
      search_arr = ["del_status = false"]

      if params[:filter_main].present? || params[:city_town_name].present? || params[:region_code].present? || params[:active_status].present? || params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?

        $merchant_filter = params[:filter_main]
        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @city_town_name = filter_params[:city_town_name]
          @region_code = filter_params[:region_code]
          @active_status = filter_params[:active_status]
          @username = filter_params[:user_id]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:city_town_name] = filter_params[:city_town_name]
          params[:region_code] = filter_params[:region_code]
          params[:active_status] = filter_params[:active_status]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        else

          if  params[:city_town_name].present? || params[:region_code].present? || params[:active_status].present?|| params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

            @city_town_name = params[:city_town_name]
            @region_code = params[:region_code]
            @active_status = params[:active_status]
            @username = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:city_town_name] = @city_town_name
            params[:region_code] = @region_code
            params[:active_status] = @active_status
            params[:user_id] = @username
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:city_town_name] = filter_params[:city_town_name]
            params[:region_code] = filter_params[:region_code]
            params[:active_status] = filter_params[:active_status]
            params[:user_id] = filter_params[:user_id]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          end
        end

        if @city_town_name.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "city_town_name = '#{@city_town_name}'"
        end

        if @region_code.present?
          search_arr << "region_code = '#{@region_code}'"
        end

        if @active_status.present?
          search_arr << "active_status = '#{@active_status}'"
        end

        if @username.present?
          search_arr << "user_id = '#{@username}'"
        end

        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
        $merchant_filter = ""
      end

      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"

      @city_town_masters = CityTownMaster.where(del_status: false).where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
    
    
  end
  # GET /city_town_masters/1 or /city_town_masters/1.json
  def show
  end

  # GET /city_town_masters/new
  def new
    @region_desc_search = RegionMaster.where(del_status: false).order(region_desc: :desc)
    @city_town_master = CityTownMaster.new
  end

  # GET /city_town_masters/1/edit
  def edit
    @region_desc_search = RegionMaster.where(del_status: false).order(region_desc: :desc)

  end

  # POST /city_town_masters or /city_town_masters.json
  def create
    @city_town_master = CityTownMaster.new(city_town_master_params)

    respond_to do |format|
      if @city_town_master.valid?
        @city_town_master.save
        city_town_masters_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "City was successfully created."

        format.js { render "/city_town_masters/city_town_masters_index" }
        format.html { redirect_to city_town_masters_path(id: @city_town_master.id), notice: 'Region was successfully created.' }
        format.json { render :index, status: :created, location: @city_town_master }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @city_town_master.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
     respond_to do |format|
      if @city_town_master.update(city_town_master_params)
        city_town_masters_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "City was updated successfully."

        format.js { render "/city_town_masters/city_town_masters_index" }
        format.html { redirect_to city_town_masters_path(id: @city_town_master.id)}
        format.json { render :city_town_masters_index, status: :ok, location: @city_town_master }

      else
        format.js { render :edit }
        format.html { render :edit }
        format.json { render json: @city_town_master.errors, status: :unprocessable_entity }
      end
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_city_town_master
      @city_town_master = CityTownMaster.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def city_town_master_params
      params.require(:city_town_master).permit(:region_code, :city_town_name, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
