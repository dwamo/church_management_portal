class ContribTypesController < ApplicationController
  before_action :set_contrib_type, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource

  # GET /contrib_types or /contrib_types.json
  def index
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    params[:branch_code] = current_user.user_branch_code

    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.super_admin? || current_user.user_admin?
      @contrib_types = ContribType.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
      @sub_entity_contribs = SubEntityContrib.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @entity_name_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
      @contribution_search = ContribType.where(active_status: true).order(contribution_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

    elsif current_user.merchant_admin?
      @contrib_types = ContribType.where(entity_code: params[:main_code], del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
      @sub_entity_contribs = SubEntityContrib.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @entity_name_search = EntityInfo.where(assigned_code: params[:main_code], active_status: true).order(entity_name: :desc)
      @contribution_search = ContribType.where(entity_code: params[:main_code], active_status: true).order(contribution_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true AND main_code = '#{params[:main_code]}'").order(username: :desc)

    elsif current_user.division_admin?
      @contrib_types = ContribType.where(entity_code: params[:main_code], del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
      @sub_entity_contribs = SubEntityContrib.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @entity_name_search = EntityInfo.where(assigned_code: params[:main_code], active_status: true).order(entity_name: :desc)
      @contribution_search = ContribType.where(entity_code: params[:main_code], active_status: true).order(contribution_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.del_status is false AND ur.div_code = '#{params[:div_code]}'").order(username: :desc)

    elsif current_user.branch_admin?
      @contrib_types = ContribType.where(entity_code: params[:main_code], del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
      @sub_entity_contribs = SubEntityContrib.where(sub_entity_code: params[:div_code], del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @entity_name_search = EntityInfo.where(assigned_code: params[:main_code], active_status: true).order(entity_name: :desc)
      @contribution_search = ContribType.where(entity_code: params[:main_code], active_status: true).order(contribution_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.del_status is false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(username: :desc)

    else

    end

  end

  def contrib_types_index
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    params[:branch_code] = current_user.user_branch_code

    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.super_admin? || current_user.user_admin?
      @entity_name_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
      @contribution_search = ContribType.where(active_status: true).order(contribution_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

    elsif current_user.merchant_admin?
      @entity_name_search = EntityInfo.where(assigned_code: params[:main_code], active_status: true).order(entity_name: :desc)
      @contribution_search = ContribType.where(entity_code: params[:main_code], active_status: true).order(contribution_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true AND main_code = '#{params[:main_code]}'").order(username: :desc)

    elsif current_user.division_admin?
      @entity_name_search = EntityInfo.where(assigned_code: params[:main_code], active_status: true).order(entity_name: :desc)
      @contribution_search = ContribType.where(entity_code: params[:main_code], active_status: true).order(contribution_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.del_status is false AND ur.div_code = '#{params[:div_code]}'").order(username: :desc)

    elsif current_user.branch_admin?
      @entity_name_search = EntityInfo.where(assigned_code: params[:main_code], active_status: true).order(entity_name: :desc)
      @contribution_search = ContribType.where(entity_code: params[:main_code], active_status: true).order(contribution_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.del_status is false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(username: :desc)

    else
    end

    if current_user.super_admin? || current_user.user_admin?
      search_arr = ["del_status = false"]
    elsif current_user.merchant_admin?
      search_arr = ["entity_code = '#{params[:main_code]}' AND del_status = false"]
    elsif current_user.division_admin?
      search_arr = ["entity_code = '#{params[:main_code]}' AND del_status = false"]
    elsif current_user.branch_admin?
      search_arr = ["entity_code = '#{params[:main_code]}' AND del_status = false"]
    end
    the_search = ""

    if params[:filter_main].present? || params[:assigned_code].present? || params[:active_status].present? || params[:contribution_desc].present? || params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

      filter_params = params[:filter_main]
      if params[:filter_main].present?
        @assigned_code = filter_params[:assigned_code]
        @active_status = filter_params[:active_status]
        @contribution_desc = filter_params[:contribution_desc]
        @username = filter_params[:user_id]
        @start_date = filter_params[:start_date]
        @end_date = filter_params[:end_date]

        params[:assigned_code] = filter_params[:assigned_code]
        params[:active_status] = filter_params[:active_status]
        params[:contribution_desc] = filter_params[:contribution_desc]
        params[:user_id] = filter_params[:user_id]
        params[:start_date] = filter_params[:start_date]
        params[:end_date] = filter_params[:end_date]

      else

        if params[:assigned_code].present? || params[:active_status].present? || params[:contribution_desc].present? || params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

          @assigned_code = params[:assigned_code]
          @active_status = params[:active_status]
          @contribution_desc = params[:contribution_desc]
          @username = params[:user_id]
          @start_date = params[:start_date]
          @end_date = params[:end_date]

          params[:assigned_code] = @assigned_code
          params[:active_status] = @active_status
          params[:contribution_desc] = @contribution_desc
          params[:user_id] = @susername
          params[:start_date] = @start_date
          params[:end_date] = @end_date

        else
          params[:assigned_code] = filter_params[:assigned_code]
          params[:active_status] = filter_params[:active_status]
          params[:contribution_desc] = filter_params[:contribution_desc]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        end
      end

      if @assigned_code.present?
        #search_arr << "customer_number LIKE '%#{@cust_num}%'"
        search_arr << "assigned_code = '#{@assigned_code}'"
      end

      if @active_status.present?
        search_arr << "active_status = '#{@active_status}'"
      end

      if @contribution_desc.present?
        search_arr << "contribution_desc = '#{@contribution_desc}'"
      end

      if @username.present?
        search_arr << "user_id = '#{@username}'"
      end

      if @start_date.present? && @end_date.present?
        f_start_date = @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
        f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
        if f_start_date <= f_end_date
          search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
        end
      end

    else
    end

    the_search = search_arr.join(" AND ")
    logger.info "The search array :: #{search_arr.inspect}"
    logger.info "The Search :: #{the_search.inspect}"

    if params[:count] == "All"
      saved_size = @contrib_types.exists? ? @contrib_types.size : 0
      @contrib_types = ContribType.where(the_search).paginate(:page => 1, :per_page => saved_size).order('created_at desc')
    else
      @contrib_types = ContribType.where(del_status: false).where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end

  end

  # GET /contrib_types/1 or /contrib_types/1.json
  def show
  end

  # GET /contrib_types/new
  def new
    params[:main_code] = current_user.user_main_code
    @job_cat_code_search = JobCat.where(active_status: true).order(job_cat_desc: :desc)
    @entity_name_search = EntityInfo.where(del_status: false).order(entity_name: :desc)

    @contrib_type = ContribType.new

  end

  # GET /contrib_types/1/edit
  def edit
    params[:main_code] = current_user.user_main_code
    @job_cat_code_search = JobCat.where(active_status: true).order(job_cat_desc: :desc)
    @entity_name_search = EntityInfo.where(del_status: false).order(entity_name: :desc)

  end

  # POST /contrib_types or /contrib_types.json
  def create
    @contrib_type = ContribType.new(contrib_type_params)

    respond_to do |format|
      if @contrib_type.valid?
        @contrib_type.save
        contrib_types_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Contribution type was successfully created."

        format.js { render "/contrib_types/contrib_types_index" }
        format.html { redirect_to contrib_types_path(id: @contrib_type.id), notice: 'Contribution type was successfully created.' }
        format.json { render :index, status: :created, location: @contrib_type }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @contrib_type.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /contrib_types/1 or /contrib_types/1.json
  def update
    respond_to do |format|
      if @contrib_type.update(contrib_type_params)
        contrib_types_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Contribution type was updated successfully."

        format.js { render "/contrib_types/contrib_types_index" }
        format.html { redirect_to contrib_types_path(id: @contrib_type.id) }
        format.json { render :contrib_types_index, status: :ok, location: @contrib_type }

      else
        format.js { render :edit }
        format.html { render :edit }
        format.json { render json: @contrib_type.errors, status: :unprocessable_entity }
      end
    end
  end

  private

  # Use callbacks to share common setup or constraints between actions.
  def set_contrib_type
    # @contrib_type = ContribType.find(params[:id])

    @contrib_type = ContribType.where(active_status: true, assigned_code: params[:id]).order(created_at: :desc).first

  end

  # Only allow a list of trusted parameters through.
  def contrib_type_params
    params.require(:contrib_type).permit(:assigned_code, :contribution_desc, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at, :entity_code, :frequency)
  end
end
