class DisabilityMastersController < ApplicationController
  before_action :set_disability_master, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /disability_masters or /disability_masters.json
  def index
    # @disability_masters = DisabilityMaster.all

    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @disability_masters = DisabilityMaster.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

    @disability_search = DisabilityMaster.where(active_status: true).order(disability_desc: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)
  end

  def disability_masters_index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)

    @disability_search = DisabilityMaster.where(active_status: true).order(disability_desc: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

    if params[:count] == "All"
      @disability_masters = DisabilityMaster.where(active_status: true).order('created_at desc')
      saved_size = @disability_masters.exists? ? @disability_masters.size : 0
      @disability_masters = DisabilityMaster.where(active_status: true).paginate(page: 1, per_page: saved_size).order("id desc")
    else

      search_arr = ["active_status = true"]
      the_search = ""

      if params[:filter_main].present? || params[:person_assigned_code].present? || params[:active_status].present?|| params[:disability_desc].present?|| params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?

        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @active_status = filter_params[:active_status]
          @disability_desc = filter_params[:disability_desc]
          @username = filter_params[:user_id]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:person_assigned_code] = filter_params[:person_assigned_code]
          params[:active_status] = filter_params[:active_status]
          params[:disability_desc] = filter_params[:disability_desc]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        else

          if  params[:person_assigned_code].present? || params[:active_status].present? || params[:disability_desc].present?|| params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

            @active_status = params[:active_status]
            @disability_desc = params[:disability_desc]
            @username = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:person_assigned_code] = @person_assigned_code
            params[:active_status] = @active_status
            params[:disability_desc] = @disability_desc
            params[:user_id] = @susername
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:person_assigned_code] = filter_params[:person_assigned_code]
            params[:active_status] = filter_params[:active_status]
            params[:disability_desc] = filter_params[:disability_desc]
            params[:user_id] = filter_params[:user_id]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          end
        end
        if @active_status.present?
          search_arr << "active_status = '#{@active_status}'"
        end

        if @disability_desc.present?
          search_arr << "disability_desc = '#{@disability_desc}'"
        end

        if @username.present?
          search_arr << "user_id = '#{@username}'"
        end

        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
      end

      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"

      @disability_masters = DisabilityMaster.where(del_status: false).where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
  end


  # GET /disability_masters/1 or /disability_masters/1.json
  def show
  end

  # GET /disability_masters/new
  def new
    @job_cat_code_search = JobCat.where(active_status: true).order(job_cat_desc: :desc)
    @disability_master = DisabilityMaster.new

  end

  # GET /disability_masters/1/edit
  def edit
    @job_cat_code_search = JobCat.where(active_status: true).order(job_cat_desc: :desc)

  end

  # POST /disability_masters or /disability_masters.json
  def create
    @disability_master = DisabilityMaster.new(disability_master_params)

    respond_to do |format|
      if @disability_master.valid?
        @disability_master.save
        disability_masters_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Disability was successfully created."

        format.js { render "/disability_masters/disability_masters_index" }
        format.html { redirect_to disability_masters_path(id: @disability_master.id), notice: 'Disability was successfully created.' }
        format.json { render :index, status: :created, location: @disability_master }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @disability_master.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /disability_masters/1 or /disability_masters/1.json
  def update
    respond_to do |format|
      if @disability_master.update(disability_master_params)
        disability_masters_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Disability was updated successfully."

        format.js { render "/disability_masters/disability_masters_index" }
        format.html { redirect_to disability_masters_path(id: @disability_master.id)}
        format.json { render :disability_masters_index, status: :ok, location: @disability_master }

      else
        format.js { render :edit }
        format.html { render :edit }
        format.json { render json: @disability_master.errors, status: :unprocessable_entity }
      end
    end
  end


  # DELETE /disability_masters/1 or /disability_masters/1.json
  def destroy
    @disability_master.destroy
    respond_to do |format|
      format.html { redirect_to disability_masters_url, notice: "Disability master was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_disability_master
      @disability_master = DisabilityMaster.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def disability_master_params
      params.require(:disability_master).permit(:disability_desc, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
