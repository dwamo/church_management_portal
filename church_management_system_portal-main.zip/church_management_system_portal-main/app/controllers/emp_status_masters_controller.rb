class EmpStatusMastersController < ApplicationController
  before_action :set_emp_status_master, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /emp_status_masters or /emp_status_masters.json
  def index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @emp_status_masters = EmpStatusMaster.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

    @emp_status_search = EmpStatusMaster.where(active_status: true).order(emp_status_desc: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

  end

  def emp_status_masters_index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @emp_status_search = EmpStatusMaster.where(active_status: true).order(emp_status_desc: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

      search_arr = ["active_status = true"]
      the_search = ""

      if params[:filter_main].present? || params[:assigned_code].present? || params[:active_status].present?|| params[:birth_date].present?|| params[:gender].present?|| params[:emp_status_desc].present?|| params[:first_name].present? || params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?

        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @assigned_code = filter_params[:assigned_code]
          @active_status = filter_params[:active_status]
          @emp_status_desc = filter_params[:emp_status_desc]
          @username = filter_params[:user_id]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:assigned_code] = filter_params[:assigned_code]
          params[:active_status] = filter_params[:active_status]
          params[:emp_status_desc] = filter_params[:emp_status_desc]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        else

          if  params[:assigned_code].present? || params[:active_status].present?|| params[:birth_date].present?|| params[:gender].present?|| params[:emp_status_desc].present?|| params[:first_name].present?|| params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

            @assigned_code = params[:assigned_code]
            @active_status = params[:active_status]
            @emp_status_desc = params[:emp_status_desc]
            @username = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:assigned_code] = @assigned_code
            params[:active_status] = @active_status
            params[:emp_status_desc] = @emp_status_desc
            params[:user_id] = @susername
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:assigned_code] = filter_params[:assigned_code]
            params[:active_status] = filter_params[:active_status]
            params[:emp_status_desc] = filter_params[:emp_status_desc]
            params[:user_id] = filter_params[:user_id]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          end
        end

        if @assigned_code.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "assigned_code = '#{@assigned_code}'"
        end
        if @active_status.present?
          search_arr << "active_status = '#{@active_status}'"
        end

        if @emp_status_desc.present?
          search_arr << "emp_status_desc = '#{@emp_status_desc}'"
        end

        if @username.present?
          search_arr << "user_id = '#{@username}'"
        end

        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
      end

      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"

    if params[:count] == "All"
      @emp_status_masters = EmpStatusMaster.order('created_at desc')
      saved_size = @emp_status_masters.exists? ? @emp_status_masters.size : 0
      @emp_status_masters = EmpStatusMaster.where(the_search).paginate(page: 1, per_page: saved_size).order("id desc")
    else
      @emp_status_masters = EmpStatusMaster.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
  end
  # GET /emp_status_masters/1 or /emp_status_masters/1.json
  def show
  end

  # GET /emp_status_masters/new
  def new
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    @job_cat_code_search = JobCat.where(active_status: true).order(job_cat_desc: :desc)

    @emp_status_master = EmpStatusMaster.new

  end

  # GET /emp_status_masters/1/edit
  def edit
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
  end

  # POST /emp_status_masters or /emp_status_masters.json
  def create
    @emp_status_master = EmpStatusMaster.new(emp_status_master_params)

    respond_to do |format|
      if @emp_status_master.valid?
        @emp_status_master.save
        emp_status_masters_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Employment Status was successfully created."

        format.js { render "/emp_status_masters/emp_status_masters_index" }
        format.html { redirect_to emp_status_masters_path(id: @emp_status_master.id), notice: 'Employment Status was successfully created.' }
        format.json { render :index, status: :created, location: @emp_status_master }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @emp_status_master.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /emp_status_masters/1 or /emp_status_masters/1.json
  def update
    respond_to do |format|
      if @emp_status_master.update(emp_status_master_params)
        emp_status_masters_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Employment Status was updated successfully."

        format.js { render "/emp_status_masters/emp_status_masters_index" }
        format.html { redirect_to emp_status_masters_path(id: @emp_status_master.id)}
        format.json { render :emp_status_masters_index, status: :ok, location: @emp_status_master }

      else
        format.js { render :edit }
        format.html { render :edit }
        format.json { render json: @emp_status_master.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /emp_status_masters/1 or /emp_status_masters/1.json
  def destroy
    @emp_status_master.destroy
    respond_to do |format|
      format.html { redirect_to emp_status_masters_url, notice: "Emp status master was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_emp_status_master
      @emp_status_master = EmpStatusMaster.where(active_status: true, assigned_code: params[:id]).order(created_at: :asc).first
    end

    # Only allow a list of trusted parameters through.
    def emp_status_master_params
      params.require(:emp_status_master).permit(:assigned_code, :emp_status_desc, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
