class EntityDivisionsController < ApplicationController
  before_action :set_entity_division, only: [:show, :edit, :update, :destroy, :edit_entity_div]
  before_action :load_permissions
  load_and_authorize_resource

  # GET /entity_divisions
  # GET /entity_divisions.json
  def index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.merchant_admin?
      params[:main_code] = current_user.user_main_code
      params[:div_code] = current_user.user_div_code
      @entity_divisions = EntityDivision.where(entity_code: params[:main_code], del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
      @sub_entity_infos = EntitySubDivision.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @division_name_search = EntityDivision.where(entity_code: params[:main_code], del_status: false).order(division_name: :desc)
      @username_search = User.unscoped.user_join.where("ur.del_status is false AND main_code = '#{params[:main_code]}'").order(username: :desc)

      @last_name_search = EntitySubDivision.where(del_status: false).order(last_name: :desc)
      @first_name_search = EntitySubDivision.where(del_status: false).order(first_name: :desc)
      @entity_info_search = EntityInfo.where(del_status: false).order(entity_name: :asc)

    elsif current_user.division_admin?
      params[:main_code] = current_user.user_main_code
      params[:div_code] = current_user.user_div_code
      logger.info "DIVISION WAS HERE ============================ #{params[:main_code].inspect}"

      @entity_divisions = EntityDivision.where(assigned_code: params[:div_code], del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
      @sub_entity_infos = EntitySubDivision.where(entity_division_code:  params[:div_code], del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @division_name_search = EntityDivision.where(assigned_code: params[:div_code], del_status: false).order(division_name: :desc)
      @username_search = User.unscoped.user_join.where("ur.del_status is false AND div_code = '#{params[:div_code]}'").order(username: :desc)

      @last_name_search = EntitySubDivision.where(entity_division_code:  params[:div_code], del_status: false).order(last_name: :desc)
      @first_name_search = EntitySubDivision.where(entity_division_code:  params[:div_code], del_status: false).order(first_name: :desc)

    end
   end

  # for merchant admin
  def entity_div_index
      params[:count] ? params[:count] : params[:count] = 20
      params[:page] ? params[:page] : params[:page] = 1

      params[:main_code] = current_user.user_main_code
      params[:div_code] = current_user.div_code

      if current_user.merchant_admin?
        @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :desc)
        @username_search = User.unscoped.user_join.where("ur.active_status is true AND main_code = '#{params[:main_code]}'").order(username: :desc)
        search_arr = ["entity_code = '#{params[:main_code]}' AND del_status = false"]
      elsif current_user.division_admin?
        search_arr = ["assigned_code = '#{params[:div_code]}' AND del_status = false"]
      end
      if params[:filter_main].present? || params[:division_name].present? || params[:division_type].present? || params[:user_id].present?|| params[:assign_code].present? || params[:activity_code].present? || params[:active_status].present? || params[:start_date].present? || params[:end_date].present?
        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @division_name = filter_params[:division_name]
          @division_type = filter_params[:division_type]
          @assign_code = filter_params[:assign_code]
          @user_id = filter_params[:user_id]
          @active_status = filter_params[:active_status]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:division_name] = filter_params[:division_name]
          params[:division_type] = filter_params[:division_type]
          params[:assign_code] = filter_params[:assign_code]
          params[:user_id] = filter_params[:user_id]
          params[:active_status] = filter_params[:active_status]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]
        else
          if  params[:division_name].present?  || params[:division_type].present? || params[:assign_code].present? || params[:user_id].present? || params[:active_status].present? || params[:start_date].present? || params[:end_date].present? # || params[:trans_id].present? || params[:nw].present? || params[:status].present? || params[:start_date].present? || params[:end_date].present?
            @division_name = params[:division_name]
            @division_type = params[:division_type]
            @assign_code = params[:assign_code]
            @user_id = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:division_name] = @division_name
            params[:division_type] = @division_type
            params[:assign_code] = @assign_code
            params[:user_id] = @user_id
            params[:active_status] = @active_status
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:division_name] = filter_params[:division_name]
            params[:division_type] = filter_params[:division_type]
            params[:assign_code] = filter_params[:assign_code]
            params[:user_id] = filter_params[:user_id]
            params[:active_status] = filter_params[:active_status]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]
          end
        end
        if @division_name.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "division_name = '#{@division_name}'"
        end
        if @assign_code.present?
          search_arr << "assigned_code = '#{@assign_code}'"
        end
        if @user_id.present?
          search_arr << "user_id = '#{@user_id}'"
        end
        if @active_status.present?
          #search_arr << "service_label = '#{@serv_label}'"
          search_arr << "active_status = '#{@active_status}'"
          end
        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end
      else
        # $service_filter = ""
        filter_params = ""
      end

      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"

    if params[:count] == "All"
      @entity_divisions = EntityDivision.all
      saved_size = @entity_divisions.exists? ? @entity_divisions.size : 0
      @entity_divisions = EntityDivision.where(the_search, entity_code: params[:main_code]).paginate(page: 1, per_page: saved_size).order("created_at desc")
    else
     @entity_divisions = EntityDivision.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
    
  end

  # for super || user-admin
  def entity_division_index
      @entity_infos = EntityInfo.where(assigned_code: params[:main_code], del_status: false)

      params[:count] ? params[:count] : params[:count] = 20
      params[:page] ? params[:page] : params[:page] = 1

      the_search = ""
      search_arr = ["entity_code = '#{params[:main_code]}' AND del_status = false"]

      if params[:filter_main].present? || params[:division_name].present? || params[:division_type].present? || params[:user_id].present?|| params[:assign_code].present? || params[:activity_code].present? || params[:active_status].present? || params[:start_date].present? || params[:end_date].present?

        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @division_name = filter_params[:division_name]
          @division_type = filter_params[:division_type]
          @assign_code = filter_params[:assign_code]
          @user_id = filter_params[:user_id]
          @active_status = filter_params[:active_status]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:division_name] = filter_params[:division_name]
          params[:division_type] = filter_params[:division_type]
          params[:assign_code] = filter_params[:assign_code]
          params[:user_id] = filter_params[:user_id]
          params[:active_status] = filter_params[:active_status]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]
        else

          if  params[:division_name].present?  || params[:division_type].present? || params[:assign_code].present? || params[:user_id].present? || params[:active_status].present? || params[:start_date].present? || params[:end_date].present? # || params[:trans_id].present? || params[:nw].present? || params[:status].present? || params[:start_date].present? || params[:end_date].present?

            @division_name = params[:division_name]
            @division_type = params[:division_type]
            @assign_code = params[:assign_code]
            @user_id = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:division_name] = @division_name
            params[:division_type] = @division_type
            params[:assign_code] = @assign_code
            params[:user_id] = @user_id
            params[:active_status] = @active_status
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:division_name] = filter_params[:division_name]
            params[:division_type] = filter_params[:division_type]
            params[:assign_code] = filter_params[:assign_code]
            params[:user_id] = filter_params[:user_id]
            params[:active_status] = filter_params[:active_status]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          end
        end

        if @division_name.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "division_name = '#{@division_name}'"
        end

        if @assign_code.present?
          search_arr << "assigned_code = '#{@assign_code}'"
        end

        if @user_id.present?
          search_arr << "user_id = '#{@user_id}'"
        end

        if @active_status.present?
          #search_arr << "service_label = '#{@serv_label}'"
          search_arr << "active_status = '#{@active_status}'"
        end

        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
        # $service_filter = ""
        filter_params = ""
      end


      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"
      if params[:count] == "All"
        @entity_divisions = EntityDivision.all
        saved_size = @entity_divisions.exists? ? @entity_divisions.size : 0
        @entity_divisions = EntityDivision.where(the_search).paginate(page: 1, per_page: saved_size).order("created_at desc")
      else
      @division_search = EntityDivision.where(entity_code: params[:main_code], del_status: false).order(division_name: :asc)
      @user_search = User.unscoped.user_join.where("ur.active_status is true AND main_code = '#{params[:main_code]}'").order(username: :asc)

      @entity_divisions = EntityDivision.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

    end
  end



  # GET /entity_divisions/1
  # GET /entity_divisions/1.json
  def show
  end

  # GET /entity_divisions/new
  def new
    @entity_division = EntityDivision.new
    # @entity_wallet_config = EntityWalletConfig.new
  end

  def new_entity_div
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.div_code

    @entity_division = EntityDivision.new
  end

  def edit
    # @entity_division.client_key = @entity_division.entity_wallet_configs&.first.client_key if @entity_division.entity_wallet_configs&.first
    # @entity_division.secret_key = @entity_division.entity_wallet_configs&.first.secret_key if @entity_division.entity_wallet_configs&.first
    # @entity_division.service_id = @entity_division.entity_wallet_configs&.first.service_id if @entity_division.entity_wallet_configs&.first

  end

  def edit_entity_div
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.div_code

  end

  # POST /entity_divisions or /entity_divisions.json
  def create
    @entity_division = EntityDivision.new(entity_division_params)
    div_code = EntityDivision.gen_div_code

    if params[:for_main] == "for_main"
      respond_to do |format|
        if @entity_division.valid?
          @entity_division.assigned_code = div_code
          @entity_division.save(validate: false)

          entity_div_index
          ##################### FLASH MESSAGE ######################################
          flash.now[:notice] = "Division was successfully created."
          format.js { render "/entity_divisions/entity_div_index" }
          format.html { redirect_to entity_div_index_path(id: @entity_division.id), notice: 'Division was successfully created.' }
          format.json { render :index, status: :created, location: @entity_division }
        else
          format.js { render :new_sub_entity }
          format.html { render :new_sub_entity }
          format.json { render json: @entity_division.errors, status: :unprocessable_entity }

          params[:main_code] = current_user.user_main_code
          params[:div_code] = current_user.div_code
          @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
        end
      end
    else
      respond_to do |format|
        if @entity_division.valid?
          @entity_division.assigned_code = div_code
          @entity_division.save(validate: false)
          entity_division_index
          ##################### FLASH MESSAGE ######################################
          flash.now[:notice] = "Division was successfully created."
          format.js { render "/entity_divisions/entity_division_index" }
          format.html { redirect_to entity_division_path(id: @entity_division.id), notice: 'Division was successfully created.' }
          format.json { render :index, status: :created, location: @entity_division }
        else
          format.js { render :new }
          format.html { render :new }
          format.json { render json: @entity_division.errors, status: :unprocessable_entity }
          @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :desc)
        end
      end
    end
  end

  def update
    respond_to do |format|
      @entity_division = EntityDivision.where(active_status: true, assigned_code: params[:id]).order(created_at: :desc).first
      flash.now[:notice] = "Division was updated successfully."

      logger.info params[:entity_division].inspect
      @new_record = EntityDivision.new(entity_division_params)

      @new_record.assigned_code = @entity_division.assigned_code
      if @new_record.valid?
        @entity_division.active_status = false
        @entity_division.del_status = true
        @entity_division.save(validate: false)
        if @new_record.save
        else
        end
        if params[:for_main] == "for_main"
          entity_div_index
          format.js { render "/entity_divisions/entity_div_index" }
          format.html { redirect_to entity_div_index_path, notice: 'Division updated successfully.' }
          format.json { render :entity_div_index, status: :ok, location: @entity_division }
        else
          entity_division_index
          format.js { render "/entity_divisions/entity_division_index" }
          format.html { redirect_to entity_divisions_path, notice: 'Division was updated successfully.' }
          format.json { render :entity_division_index, status: :ok, location: @entity_division }
        end
      else
        logger.info "Division Error Messages Edit :: #{@new_record.errors.messages.inspect}"

        format.html {render :edit}
        format.js { render :edit }
        format.json { render json: @entity_division.errors, status: :unprocessable_entity }
      end
    end
  end

  def enable_division
    entity_info = EntityDivision.where('assigned_code =? ', params[:div_id]).where(del_status: false).last
    respond_to do |format|
      if entity_info.update(active_status: true)
        entity_division_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Division enabled successfully."
        format.js {render layout: false}
      else
        entity_division_index
        format.js {render layout: false}
      end
    end
  end

  def disable_division
    entity_info = EntityDivision.where('assigned_code =? ', params[:div_id]).where(del_status: false).last
    respond_to do |format|
      if entity_info.update(active_status: false)
        entity_division_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Division disabled successfully."
        format.js {render layout: false}
      else
        entity_division_index
        format.js {render layout: false}
      end
    end
  end

  def enable_entity_div
    entity_info = EntityDivision.where('assigned_code =? ', params[:div_id]).where(del_status: false).last
    respond_to do |format|
      if entity_info.update(active_status: true)
        index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Division enabled successfully."
        format.js {render layout: false}
      else
        index
        format.js {render layout: false}
      end
    end
  end

  def disable_entity_div
    entity_info = EntityDivision.where('assigned_code =? ', params[:div_id]).where(del_status: false).last
    respond_to do |format|
      if entity_info.update(active_status: false)
        index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Division disabled successfully."
        format.js {render layout: false}
      else
        index
        format.js {render layout: false}
      end
    end
  end


  private
  # Use callbacks to share common setup or constraints between actions.
  def set_entity_division
    # @entity_division = EntityDivision.find(params[:id])
    @entity_division = EntityDivision.where(active_status: true, assigned_code: params[:id]).order(created_at: :desc).first
    # logger.info "Entity Division :: #{@entity_division.inspect}"
  end

  # Only allow a list of trusted parameters through.
  def entity_division_params
    params.require(:entity_division).permit(:assigned_code, :entity_code, :division_alias, :division_name, :user_id, :active_status, :del_status, :created_at, :updated_at, :entity_code)
  end

end
