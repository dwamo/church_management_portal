class EntityExtraInfosController < ApplicationController
  before_action :set_entity_extra_info, only: %i[ show edit add_extra_info update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /entity_extra_infos or /entity_extra_infos.json
  def index
    @entity_extra_infos = EntityExtraInfo.all
  end

  def add_extra_info

  end

  # GET /entity_extra_infos/1 or /entity_extra_infos/1.json
  def show
  end

  # GET /entity_extra_infos/new
  def new
    @entity_extra_info = EntityExtraInfo.new
  end

  # GET /entity_extra_infos/1/edit
  def edit
  end

  # POST /entity_extra_infos or /entity_extra_infos.json
  def create
    @entity_extra_info = EntityExtraInfo.new(entity_extra_info_params)

    respond_to do |format|
      if @entity_extra_info.save
        format.html { redirect_to @entity_extra_info, notice: "Entity extra info was successfully created." }
        format.json { render :show, status: :created, location: @entity_extra_info }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @entity_extra_info.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /entity_extra_infos/1 or /entity_extra_infos/1.json
  def update
    respond_to do |format|
      if @entity_extra_info.update(entity_extra_info_params)
        format.html { redirect_to @entity_extra_info, notice: "Entity extra info was successfully updated." }
        format.json { render :show, status: :ok, location: @entity_extra_info }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @entity_extra_info.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /entity_extra_infos/1 or /entity_extra_infos/1.json
  def destroy
    @entity_extra_info.destroy
    respond_to do |format|
      format.html { redirect_to entity_extra_infos_url, notice: "Entity extra info was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_entity_extra_info
      @entity_extra_info = EntityExtraInfo.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def entity_extra_info_params
      params.require(:entity_extra_info).permit(:entity_code, :entity_division_code, :sub_entity_code, :person_assigned_code, :person_role_code, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
