class EntityInfoBoardsController < ApplicationController
  before_action :set_entity_info_board, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /entity_info_boards or /entity_info_boards.json
  def index
    @entity_info_boards = EntityInfoBoard.all
  end

  # GET /entity_info_boards/1 or /entity_info_boards/1.json
  def show
  end

  # GET /entity_info_boards/new
  def new
    @entity_info_board = EntityInfoBoard.new
  end

  # GET /entity_info_boards/1/edit
  def edit
  end

  # POST /entity_info_boards or /entity_info_boards.json
  def create
    @entity_info_board = EntityInfoBoard.new(entity_info_board_params)

    respond_to do |format|
      if @entity_info_board.save
        format.html { redirect_to @entity_info_board, notice: "Entity info board was successfully created." }
        format.json { render :show, status: :created, location: @entity_info_board }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @entity_info_board.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /entity_info_boards/1 or /entity_info_boards/1.json
  def update
    respond_to do |format|
      if @entity_info_board.update(entity_info_board_params)
        format.html { redirect_to @entity_info_board, notice: "Entity info board was successfully updated." }
        format.json { render :show, status: :ok, location: @entity_info_board }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @entity_info_board.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /entity_info_boards/1 or /entity_info_boards/1.json
  def destroy
    @entity_info_board.destroy
    respond_to do |format|
      format.html { redirect_to entity_info_boards_url, notice: "Entity info board was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_entity_info_board
      @entity_info_board = EntityInfoBoard.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def entity_info_board_params
      params.require(:entity_info_board).permit(:entity_code, :motto, :logo_path, :logo_data)
    end
end
