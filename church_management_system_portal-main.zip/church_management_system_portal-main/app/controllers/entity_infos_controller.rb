 class EntityInfosController < ApplicationController
    before_action :set_entity_info, only: [:show, :edit, :update, :destroy]
    before_action :load_permissions
    load_and_authorize_resource
    require 'church_core'

    def index
      params[:count] ? params[:count] : params[:count] = 20
      params[:page] ? params[:page] : params[:page] = 1

      @entity_infos = EntityInfo.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
      @entity_divisions = EntityDivision.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
      @sub_entity_infos = SubEntityInfo.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
      @entity_sub_divisions = EntitySubDivision.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @entity_name_search = EntityInfo.where("del_status = false").order(entity_name: :asc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :asc)
      @sub_entity_name_search = SubEntityInfo.where(del_status: false).order(sub_entity_name: :asc)
      @sub_entity_alias_search = SubEntityInfo.where(del_status: false).order(sub_entity_alias: :asc)
      @sub_division_desc_search = EntitySubDivision.where(active_status: true).order(sub_division_desc: :asc)

    end

    def entity_infos_index
      params[:count] ? params[:count] : params[:count] = 20
      params[:page] ? params[:page] : params[:page] = 1

      @entity_name_search = EntityInfo.where("del_status = false").order(entity_name: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

        the_search = ""
        search_arr = ["del_status = false"]

        if params[:filter_main].present? || params[:entity_name].present? || params[:entity_alias].present? || params[:active_status].present? || params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?

          $merchant_filter = params[:filter_main]
          filter_params = params[:filter_main]
          if params[:filter_main].present?
            @entity_name = filter_params[:entity_name]
            @entity_alias = filter_params[:entity_alias]
            @active_status = filter_params[:active_status]
            @username = filter_params[:user_id]
            @start_date = filter_params[:start_date]
            @end_date = filter_params[:end_date]

            params[:entity_name] = filter_params[:entity_name]
            params[:entity_alias] = filter_params[:entity_alias]
            params[:active_status] = filter_params[:active_status]
            params[:user_id] = filter_params[:user_id]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          else

            if  params[:entity_name].present? || params[:entity_alias].present? || params[:active_status].present?|| params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

              @entity_name = params[:entity_name]
              @entity_alias = params[:entity_alias]
              @active_status = params[:active_status]
              @username = params[:user_id]
              @start_date = params[:start_date]
              @end_date = params[:end_date]

              params[:entity_name] = @entity_name
              params[:entity_alias] = @entity_alias
              params[:active_status] = @active_status
              params[:user_id] = @username
              params[:start_date] = @start_date
              params[:end_date] = @end_date

            else
              params[:entity_name] = filter_params[:entity_name]
              params[:entity_alias] = filter_params[:entity_alias]
              params[:active_status] = filter_params[:active_status]
              params[:user_id] = filter_params[:user_id]
              params[:start_date] = filter_params[:start_date]
              params[:end_date] = filter_params[:end_date]

            end
          end
          if @entity_name.present?
            #search_arr << "customer_number LIKE '%#{@cust_num}%'"
            search_arr << "entity_name = '#{@entity_name}'"
          end
          if @entity_alias.present?
            search_arr << "entity_alias = '#{@entity_alias}'"
          end
          if @active_status.present?
            search_arr << "active_status = '#{@active_status}'"
          end
          if @username.present?
            search_arr << "user_id = '#{@username}'"
          end
          if @start_date.present? && @end_date.present?
            f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
            f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
            if f_start_date <= f_end_date
              search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
            end
          end

        else
          $merchant_filter = ""
        end

        the_search = search_arr.join(" AND ")
        logger.info "The search array :: #{search_arr.inspect}"
        logger.info "The Search :: #{the_search.inspect}"

      if params[:count] == "All"
        saved_size = @entity_infos.exists? ? @entity_infos.size : 0
        @entity_infos = EntityInfo.where(the_search).paginate(:page => 1, :per_page => saved_size).order('created_at desc')
      else
        @entity_infos = EntityInfo.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
      end

    end

    def sample_csv
      send_file("#{Rails.root}/public/sample_csv.csv", filename: "sample_csv.csv", type: "application/csv")
    end

    def show
    end

    # GET /entity_infos/new
    def new
      @entity_info = EntityInfo.new

    end

    # GET /entity_infos/1/edit
    def edit
      @entity_info.motto = @entity_info.entity_info_boards&.first.motto if @entity_info.entity_info_boards&.first
      @entity_info.logo_data = @entity_info.entity_info_boards&.first.logo_data if @entity_info.entity_info_boards&.first

    end

    def create
      @entity_info = EntityInfo.new(entity_info_params)

      respond_to do |format|
      if @entity_info.valid?
        assigned_code = EntityInfo.gen_info_code

        logo_uploader = ChurchCore::ImageDataUploader.new
        logo_data = entity_info_params[:logo_data].present? ? entity_info_params[:logo_data] : ""
        img_public_id = logo_uploader.public_id(logo_data)
        img_store_dir = logo_uploader.store_dir
        logger.info "Image Data 1 :: #{logo_data.original_filename.split(".").inspect}"

        tab_logo_path = "#{entity_info_params[:logo_path]}#{img_store_dir}/"
        tab_logo_data = logo_uploader.filename(logo_data, img_public_id)
        logger.info "===========================//////////////////================="
        logger.info "logo data #{entity_info_params[:logo_data].inspect}"
        logger.info "Image Path :: #{@entity_info.logo_path.inspect}"
        logger.info "Image Data :: #{@entity_info.logo_data.inspect}"

        motto = entity_info_params[:motto].present? ? entity_info_params[:motto] : nil

        logger.info "Cloudinary Saving =========================="

        @logo_results = Cloudinary::Uploader.upload(logo_data, :public_id => img_public_id)
        logger.info "The Image Data :: #{@logo_results["secure_url"].inspect}"
        @entity_info_boards = EntityInfoBoard.new(logo_path: @logo_results["secure_url"], logo_data: tab_logo_data, entity_code: assigned_code, motto:motto)
        @entity_info_boards.save(validate: false)


        entity_name = entity_info_params[:entity_name].present? ? entity_info_params[:entity_name] : nil
        entity_alias = entity_info_params[:entity_alias].present? ? entity_info_params[:entity_alias] : nil
        user_id = entity_info_params[:user_id].present? ? entity_info_params[:user_id] : nil
        comment = entity_info_params[:comment].present? ? entity_info_params[:comment] : nil
        @entity_info = EntityInfo.new(assigned_code: assigned_code, entity_name: entity_name, entity_alias: entity_alias, user_id: user_id, comment: comment)
        @entity_info.save(validate: false)

        entity_infos_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Entity Info was successfully created."
        format.js { render "/entity_infos/entity_infos_index" }
        format.html { redirect_to entity_infos_path(id: @entity_info.id) }
        format.json { render :entity_infos_index, status: :created, location: @entity_info }

        else
          format.js { render :new }
          format.html { render :new }
          format.json { render json: @entity_info.errors, status: :unprocessable_entity }
        end
      end
    end

    def update
      @new_record = EntityInfo.new(entity_info_params)
      logo_uploader = ChurchCore::ImageDataUploader.new

      respond_to do |format|
        if @new_record.valid?
          if entity_info_params.has_key?(:logo_data)
            if (!@entity_info.logo_data.present? && entity_info_params[:logo_data].present?) || (@entity_info.logo_data.present? && entity_info_params[:logo_data].present?)
              logo_data = entity_info_params[:logo_data].present? ? entity_info_params[:logo_data] : ""
              img_public_id = logo_uploader.public_id(logo_data)
              img_store_dir = logo_uploader.store_dir
              logger.info "Image Data 1 :: #{logo_data.original_filename.split(".").inspect}"

              tab_logo_path = "#{entity_info_params[:logo_path]}#{img_store_dir}/"
              tab_logo_data = logo_uploader.filename(logo_data, img_public_id)
              motto = entity_info_params[:motto].present? ? entity_info_params[:motto] : nil
              assigned_code = @entity_info.assigned_code.present? ? @entity_info.assigned_code : nil

              @entity_info_boards = EntityInfoBoard.where(active_status: true, entity_code: assigned_code).order(id: :desc).first
              @logo_results = Cloudinary::Uploader.upload(logo_data, :public_id => img_public_id)
              logger.info "The Image Data :: #{@logo_results["secure_url"].inspect}"
              if @entity_info_boards
                @entity_info_boards.active_status = false
                @entity_info_boards.del_status = true
                @entity_info_boards.save(validate: false)
                @entity_info_boards = EntityInfoBoard.new(logo_path: @logo_results["secure_url"], logo_data: tab_logo_data, entity_code: assigned_code, motto:motto, active_status: true, del_status: false)
                @entity_info_boards.save(validate: false)
              else
                @entity_info_boards = EntityInfoBoard.new(logo_path: @logo_results["secure_url"], logo_data: tab_logo_data, entity_code: assigned_code, motto:motto)
                @entity_info_boards.save(validate: false)
              end
            end
          else
          end

          logger.info "=============================== Entity Info :: #{@entity_info.inspect}"
          @entity_info.active_status = false
          @entity_info.del_status = true
          @entity_info.save(validate: false)
          logger.info "===================== UPDATE =============================="
          @new_record.assigned_code = @entity_info.assigned_code
          @new_record.save(validate: false)
          @entity_info = @new_record


          entity_infos_index
          ##################### FLASH MESSAGE ######################################
          flash.now[:notice] = "Entity Info was updated successfully."

          format.js { render "/entity_infos/entity_infos_index" }
          format.html { redirect_to entity_infos_path(id: @entity_info.id)}
          format.json { render :entity_infos_index, status: :ok, location: @entity_info }

        else
          # @entity_info.update(entity_info_params)
          format.js { render :edit }
          format.html { render :edit }
          format.json { render json: @entity_info.errors, status: :unprocessable_entity }
        end
      end
    end


    def enable_entity_info
      entity_info = EntityInfo.where('assigned_code =? ', params[:main_id]).where(del_status: false).last
      respond_to do |format|
        if entity_info.update(active_status: true)
          entity_infos_index
          ##################### FLASH MESSAGE ######################################
          flash.now[:notice] = "Entity Info Enabled successfully."
          format.js {render layout: false}
        else
          entity_infos_index
          format.js {render layout: false}
        end
      end
    end

    def disable_entity_info
      entity_info = EntityInfo.where('assigned_code =? ', params[:main_id]).where(del_status: false).last
      respond_to do |format|
        if entity_info.update(active_status: false)
          entity_infos_index
          ##################### FLASH MESSAGE ######################################
          flash.now[:notice] = "Entity Info Disabled successfully."
          format.js {render layout: false}
        else
          entity_infos_index
          format.js {render layout: false}
        end
      end
    end

    # DETAILS MODAL
    def entity_show
      # @entity_info = EntityInfo.find(params[:entity_id])
      @entity_info = EntityInfo.where(assigned_code: params[:entity_id], del_status: false).order(created_at: :desc).first
    end
    
    private
    # Use callbacks to share common setup or constraints between actions.
    def set_entity_info
      # @entity_info = EntityInfo.find(params[:id])
      @entity_info = EntityInfo.where(active_status: true, assigned_code: params[:id]).order(created_at: :desc).first
    end

    # Only allow a list of trusted parameters through.
    def entity_info_params
      params.require(:entity_info).permit(:id, :entity_code, :assigned_code, :entity_name, :comment, :active_status, :del_status, :user_id, :motto, :logo_data, :logo_path, :entity_alias, :created_at, :updated_at)
    end
  end
