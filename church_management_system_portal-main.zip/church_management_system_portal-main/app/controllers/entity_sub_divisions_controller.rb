class EntitySubDivisionsController < ApplicationController
  before_action :set_entity_sub_division, only: [:show, :edit, :edit_sub_div, :update, :destroy]
  before_action :load_permissions
  load_and_authorize_resource

  # GET /entity_sub_divisions or /entity_sub_divisions.json
  def index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1
    params[:div_code] = current_user.user_div_code

    @entity_sub_divisions = EntitySubDivision.where(entity_division_code: params[:div_code], del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    @sub_division_desc_search = EntitySubDivision.where(entity_division_code: params[:div_code], del_status: false).order(sub_division_desc: :asc)

    @user_search = User.unscoped.user_join.where("ur.del_status = false AND div_code = '#{params[:div_code]}'").order(username: :desc)

  end

  # for super_admin || user_admin
  def entity_sub_div_main
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    the_search = ""
    search_arr = ["del_status = false"]

    if params[:filter_main].present? || params[:division_name].present? || params[:division_type].present? || params[:user_id].present? || params[:assign_code].present? || params[:sub_division_desc].present? || params[:active_status].present? || params[:start_date].present? || params[:end_date].present?

      filter_params = params[:filter_main]
      if params[:filter_main].present?
        @division_name = filter_params[:division_name]
        @division_type = filter_params[:division_type]
        @sub_division_desc = filter_params[:sub_division_desc]
        @assign_code = filter_params[:assign_code]
        @user_id = filter_params[:user_id]
        @active_status = filter_params[:active_status]
        @start_date = filter_params[:start_date]
        @end_date = filter_params[:end_date]

        params[:division_name] = filter_params[:division_name]
        params[:division_type] = filter_params[:division_type]
        params[:sub_division_desc] = filter_params[:sub_division_desc]
        params[:assign_code] = filter_params[:assign_code]
        params[:user_id] = filter_params[:user_id]
        params[:active_status] = filter_params[:active_status]
        params[:start_date] = filter_params[:start_date]
        params[:end_date] = filter_params[:end_date]
      else

        if params[:division_name].present? || params[:division_type].present? || params[:assign_code].present? || params[:sub_division_desc].present? || params[:user_id].present? || params[:active_status].present? || params[:start_date].present? || params[:end_date].present?

          @division_name = params[:division_name]
          @division_type = params[:division_type]
          @assign_code = params[:assign_code]
          @sub_division_desc = params[:sub_division_desc]
          @user_id = params[:user_id]
          @start_date = params[:start_date]
          @end_date = params[:end_date]

          params[:division_name] = @division_name
          params[:division_type] = @division_type
          params[:assign_code] = @assign_code
          params[:sub_division_desc] = @sub_division_desc
          params[:user_id] = @user_id
          params[:active_status] = @active_status
          params[:start_date] = @start_date
          params[:end_date] = @end_date

        else
          params[:division_name] = filter_params[:division_name]
          params[:division_type] = filter_params[:division_type]
          params[:assign_code] = filter_params[:assign_code]
          params[:sub_division_desc] = filter_params[:sub_division_desc]
          params[:user_id] = filter_params[:user_id]
          params[:active_status] = filter_params[:active_status]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        end
      end
      if @division_name.present?
        #search_arr << "customer_number LIKE '%#{@cust_num}%'"
        search_arr << "division_name = '#{@division_name}'"
      end
      if @sub_division_desc.present?
        search_arr << "sub_division_desc = '#{@sub_division_desc}'"
      end
      if @assign_code.present?
        search_arr << "assigned_code = '#{@assign_code}'"
      end
      if @user_id.present?
        search_arr << "user_id = '#{@user_id}'"
      end
      if @active_status.present?
        #search_arr << "service_label = '#{@serv_label}'"
        search_arr << "active_status = '#{@active_status}'"
      end
      if @start_date.present? && @end_date.present?
        f_start_date = @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
        f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
        if f_start_date <= f_end_date
          search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
        end
      end
    else
      # $service_filter = ""
      filter_params = ""
    end

    the_search = search_arr.join(" AND ")
    logger.info "The search array :: #{search_arr.inspect}"
    logger.info "The Search :: #{the_search.inspect}"

    @division_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :asc)
    @sub_division_desc_search = EntitySubDivision.where(del_status: false).order(sub_division_desc: :asc)
    @user_search = User.unscoped.user_join.where("ur.del_status = false").order(username: :desc)

    if params[:count] == "All"
      @entity_sub_divisions = EntitySubDivision.order('created_at desc')
      saved_size = @entity_sub_divisions.exists? ? @entity_sub_divisions.size : 0
      @entity_sub_divisions = EntitySubDivision.where(the_search).paginate(page: 1, per_page: saved_size).order("id desc")
    else
      @entity_sub_divisions = EntitySubDivision.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end

  end

  # for merchant_admin || entity_divisions
  def entity_sub_divisions_index
    @entity_divisions = EntityDivision.where(assigned_code: params[:div_code], del_status: false)

    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.division_admin?
      params[:div_code] = current_user.user_div_code
      search_arr = ["entity_division_code = '#{params[:div_code]}' AND del_status = false"]
    else
      search_arr = ["entity_division_code = '#{params[:div_code]}' AND del_status = false"]
    end
    the_search = ""

    if params[:filter_main].present? || params[:entity_division_code].present? || params[:active_status].present? || params[:sub_division_desc].present? || params[:sub_division_alias].present? || params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

      filter_params = params[:filter_main]
      if params[:filter_main].present?
        @entity_division_code = filter_params[:entity_division_code]
        @active_status = filter_params[:active_status]
        @sub_division_desc = filter_params[:sub_division_desc]
        @sub_division_alias = filter_params[:sub_division_alias]
        @username = filter_params[:user_id]
        @start_date = filter_params[:start_date]
        @end_date = filter_params[:end_date]

        params[:entity_division_code] = filter_params[:entity_division_code]
        params[:active_status] = filter_params[:active_status]
        params[:sub_division_desc] = filter_params[:sub_division_desc]
        params[:sub_division_alias] = filter_params[:sub_division_alias]
        params[:user_id] = filter_params[:user_id]
        params[:start_date] = filter_params[:start_date]
        params[:end_date] = filter_params[:end_date]

      else

        if params[:entity_division_code].present? || params[:active_status].present? || params[:sub_division_desc].present? || params[:sub_division_alias].present? || params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

          @entity_division_code = params[:entity_division_code]
          @active_status = params[:active_status]
          @sub_division_desc = params[:sub_division_desc]
          @sub_division_alias = params[:sub_division_alias]
          @username = params[:user_id]
          @start_date = params[:start_date]
          @end_date = params[:end_date]

          params[:entity_division_code] = @entity_division_code
          params[:active_status] = @active_status
          params[:sub_division_desc] = @sub_division_desc
          params[:sub_division_alias] = @sub_division_alias
          params[:user_id] = @username
          params[:start_date] = @start_date
          params[:end_date] = @end_date

        else
          params[:entity_division_code] = filter_params[:entity_division_code]
          params[:active_status] = filter_params[:active_status]
          params[:sub_division_desc] = filter_params[:sub_division_desc]
          params[:sub_division_alias] = filter_params[:sub_division_alias]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        end
      end

      if @entity_division_code.present?
        search_arr << "entity_division_code = '#{@entity_division_code}'"
      end
      if @active_status.present?
        search_arr << "active_status = '#{@active_status}'"
      end
      if @sub_division_desc.present?
        search_arr << "sub_division_desc = '#{@sub_division_desc}'"
      end
      if @sub_division_alias.present?
        search_arr << "sub_division_alias = '#{@sub_division_alias}'"
      end
      if @username.present?
        search_arr << "user_id = '#{@username}'"
      end
      if @start_date.present? && @end_date.present?
        f_start_date = @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
        f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
        if f_start_date <= f_end_date
          search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
        end
      end

    else
    end

    the_search = search_arr.join(" AND ")
    logger.info "The search array :: #{search_arr.inspect}"
    logger.info "The Search :: #{the_search.inspect}"

    if params[:count] == "All"
      saved_size = @entity_sub_divisions.exists? ? @entity_sub_divisions.size : 0
      @entity_sub_divisions = EntitySubDivision.where(the_search).paginate(:page => 1, :per_page => saved_size).order('created_at desc')
    else
      @entity_sub_divisions = EntitySubDivision.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
    @sub_division_desc_search = EntitySubDivision.where(entity_division_code: params[:div_code], del_status: false).order(sub_division_desc: :asc)
    @user_search = User.unscoped.user_join.where("ur.del_status = false AND div_code = '#{params[:div_code]}'").order(username: :desc)

  end

  # GET /entity_sub_divisions/1 or /entity_sub_divisions/1.json
  def show
  end

  # GET /entity_sub_divisions/new
  def new
    @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
    @sub_entity_name_search = SubEntityInfo.where(del_status: false).order(sub_entity_name: :desc)

    @entity_sub_division = EntitySubDivision.new
  end

  def new_sub_div
    if current_user.division_admin?
      params[:div_code] = current_user.user_div_code
    end
    @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
    @entity_sub_division = EntitySubDivision.new
  end

  # GET /entity_sub_divisions/1/edit
  def edit
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    params[:branch_code] = current_user.user_branch_code
    @sub_entity_name_search = SubEntityInfo.where(del_status: false).order(sub_entity_name: :desc)
    @division_name_search = EntityDivision.where(active_status: true).order(division_name: :desc)
    @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)

  end

  def edit_sub_div

  end

  # def edit_sub_entity
  #
  # end

  # POST /entity_sub_divisions or /entity_sub_divisions.json
  def create
    @entity_sub_division = EntitySubDivision.new(entity_sub_division_params)
    entity_sub_division = EntitySubDivision.gen_sub_division_code

    if params[:for_main] == "for_main"
      respond_to do |format|
        if @entity_sub_division.valid?
          @entity_sub_division.assigned_code = entity_sub_division
          @entity_sub_division.save(validate: false)

          entity_sub_divisions_index
          ##################### FLASH MESSAGE ######################################
          flash.now[:notice] = "Sub Division was successfully created."
          format.js { render "/entity_sub_divisions/entity_sub_divisions_index" }
          format.html { redirect_to entity_sub_divisions_index(id: @entity_sub_division.id), notice: 'Sub Division was successfully created.' }
          format.json { render :index, status: :created, location: @entity_sub_division }
        else
          format.js { render :new }
          format.html { render :new }
          format.json { render json: @entity_sub_division.errors, status: :unprocessable_entity }

          params[:main_code] = current_user.user_main_code
          params[:div_code] = current_user.div_code
          @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
        end
      end
    else
      respond_to do |format|
        if @entity_sub_division.valid?
          @entity_sub_division.assigned_code = entity_sub_division
          @entity_sub_division.save(validate: false)
          entity_sub_div_main
          ##################### FLASH MESSAGE ######################################
          flash.now[:notice] = "Sub Division was successfully created."
          format.js { render "/entity_sub_divisions/entity_sub_div_main" }
          format.html { redirect_to entity_sub_divisions_path(id: @entity_sub_division.id), notice: 'Sub Division was successfully created.' }
          format.json { render :index, status: :created, location: @entity_sub_division }
        else
          format.js { render :new }
          format.html { render :new }
          format.json { render json: @entity_sub_division.errors, status: :unprocessable_entity }
          @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :desc)
        end
      end
    end
  end

  def update
    respond_to do |format|
      @entity_sub_division = EntitySubDivision.where(active_status: true, assigned_code: params[:id]).order(created_at: :desc).first
      flash.now[:notice] = "Sub Division was updated successfully."

      logger.info params[:entity_sub_division].inspect
      @new_record = EntitySubDivision.new(entity_sub_division_params)

      @new_record.assigned_code = @entity_sub_division.assigned_code
      if @new_record.valid?
        @entity_sub_division.active_status = false
        @entity_sub_division.del_status = true
        @entity_sub_division.save(validate: false)
        if @new_record.save
        else
        end
        if params[:for_main] == "for_main"
          entity_sub_divisions_index
          format.js { render "/entity_sub_divisions/entity_sub_divisions_index" }
          format.html { redirect_to entity_sub_divisions_index_path, notice: 'Sub Division updated successfully.' }
          format.json { render :entity_sub_divisions_index, status: :ok, location: @entity_sub_division }
        else
          entity_sub_div_main
          format.js { render "/entity_sub_divisions/entity_sub_div_main" }
          format.html { redirect_to entity_sub_divisions_path, notice: 'Sub Division was updated successfully.' }
          format.json { render :entity_sub_div_main, status: :ok, location: @entity_sub_division }
        end
      else
        logger.info "Sub Division Error Messages Edit :: #{@new_record.errors.messages.inspect}"

        format.html { render :edit }
        format.js { render :edit }
        format.json { render json: @entity_sub_division.errors, status: :unprocessable_entity }
      end
    end
  end

  def entity_update
    logger.info "Params:: #{params[:id_for_entity_info].inspect}"
    if params[:id_for_entity_info].empty?
      @info_update_division = [["", ""]].insert(0, ['Please select a Division', ""])
    else
      info_update_division = EntityDivision.where(entity_code: params[:id_for_entity_info], active_status: true).order(division_name: :desc).map { |a| [a.division_name, a.id] }.insert(0, ['Please select a Division', ""])
      @info_update_division = info_update_division.empty? ? [["", ""]].insert(0, ['Please select a Division', ""]) : info_update_division
    end
    logger.info "For Entity Division :: #{@info_update_division.inspect}"
  end

  # DELETE /entity_sub_divisions/1 or /entity_sub_divisions/1.json

  private

  # Use callbacks to share common setup or constraints between actions.
  def set_entity_sub_division
    # @entity_sub_division = EntitySubDivision.find(params[:id])
    @entity_sub_division = EntitySubDivision.where(active_status: true, assigned_code: params[:id]).order(created_at: :desc).first

  end

  # Only allow a list of trusted parameters through.
  def entity_sub_division_params
    params.require(:entity_sub_division).permit(:entity_division_code, :sub_division_desc, :sub_division_alias, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at, :assigned_code, :entity_info_code)
  end
end
