class GroupCatsController < ApplicationController
  before_action :set_group_cat, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /group_cats or /group_cats.json
  def index
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    params[:branch_code] = current_user.user_branch_code

    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.super_admin? || current_user.user_admin?
    @group_cats = GroupCat.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    @group_masters = GroupMaster.where(active_status: true).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

    @group_cat_search = GroupCat.where(active_status: true).order(group_cat_desc: :desc)
    @entity_name_search = EntityInfo.where(del_status: false).order(entity_name: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)
    @group_master_search = GroupMaster.where(active_status: true).order(group_name: :desc)

    elsif current_user.merchant_admin?
    params[:main_code] = current_user.user_main_code
    @group_cats = GroupCat.where(entity_info_code: params[:main_code], del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    @group_masters = GroupMaster.where(entity_info_code: params[:main_code], active_status: true).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

    @group_cat_search = GroupCat.where(entity_info_code: params[:main_code], active_status: true).order(group_cat_desc: :desc)
    @entity_name_search = EntityInfo.where(assigned_code: params[:main_code], del_status: false).order(entity_name: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status is true AND main_code = '#{params[:main_code]}'").order(username: :desc)
    @group_master_search = GroupMaster.where(entity_info_code: params[:main_code], active_status: true).order(group_name: :desc)
    else
    end

  end

  def group_cats_index
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    params[:branch_code] = current_user.user_branch_code

    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.super_admin? || current_user.user_admin?
      @group_cat_search = GroupCat.where(active_status: true).order(group_cat_desc: :desc)
      @entity_name_search = EntityInfo.where(del_status: false).order(entity_name: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)
    elsif current_user.merchant_admin?
      params[:main_code] = current_user.user_main_code
      @group_cat_search = GroupCat.where(entity_info_code: params[:main_code], active_status: true).order(group_cat_desc: :desc)
      @entity_name_search = EntityInfo.where(assigned_code: params[:main_code], del_status: false).order(entity_name: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status is true AND main_code = '#{params[:main_code]}'").order(username: :desc)
    else
    end


      if current_user.super_admin? || current_user.user_admin?
        search_arr = ["del_status = false"]
      elsif current_user.merchant_admin?
        search_arr = ["entity_info_code = '#{params[:main_code]}' AND del_status = false"]
      end
      the_search = ""

      if params[:filter_main].present? || params[:assigned_code].present? || params[:active_status].present?|| params[:birth_date].present?|| params[:entity_info_code].present?|| params[:group_cat_desc].present? || params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?

        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @assigned_code = filter_params[:assigned_code]
          @active_status = filter_params[:active_status]
          @group_cat_desc = filter_params[:group_cat_desc]
          @entity_info_code = filter_params[:entity_info_code]
          @username = filter_params[:user_id]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:assigned_code] = filter_params[:assigned_code]
          params[:active_status] = filter_params[:active_status]
          params[:group_cat_desc] = filter_params[:group_cat_desc]
          params[:entity_info_code] = filter_params[:entity_info_code]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        else

          if  params[:assigned_code].present? || params[:active_status].present?|| params[:birth_date].present?|| params[:entity_info_code].present?|| params[:group_cat_desc].present?|| params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

            @assigned_code = params[:assigned_code]
            @active_status = params[:active_status]
            @group_cat_desc = params[:group_cat_desc]
            @entity_info_code = params[:entity_info_code]
            @username = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:assigned_code] = @assigned_code
            params[:active_status] = @active_status
            params[:group_cat_desc] = @group_cat_desc
            params[:entity_info_code] = @entity_info_code
            params[:user_id] = @susername
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:assigned_code] = filter_params[:assigned_code]
            params[:active_status] = filter_params[:active_status]
            params[:group_cat_desc] = filter_params[:group_cat_desc]
            params[:entity_info_code] = filter_params[:entity_info_code]
            params[:user_id] = filter_params[:user_id]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          end
        end

        if @assigned_code.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "assigned_code = '#{@assigned_code}'"
        end
        if @active_status.present?
          search_arr << "active_status = '#{@active_status}'"
        end

        if @group_cat_desc.present?
          search_arr << "group_cat_desc = '#{@group_cat_desc}'"
        end
       if @entity_info_code.present?
          search_arr << "entity_info_code = '#{@entity_info_code}'"
        end

        if @username.present?
          search_arr << "user_id = '#{@username}'"
        end

        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
      end

      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"
    if params[:count] == "All"
      saved_size = @group_cats.exists? ? @group_cats.size : 0
      @group_cats = GroupCat.where(the_search).paginate(:page => 1, :per_page => saved_size).order('created_at desc')
    else
      @group_cats = GroupCat.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end


  end

  # GET /group_cats/1 or /group_cats/1.json
  def show
  end

  # GET /group_cats/new
  def new
    params[:main_code] = current_user.user_main_code
    @entity_name_search = EntityInfo.where(del_status: false).order(entity_name: :desc)

    @group_cat = GroupCat.new
  end
  # GET /group_cats/1/edit
  def edit
    params[:main_code] = current_user.user_main_code
    @entity_name_search = EntityInfo.where(del_status: false).order(entity_name: :desc)

  end
  # POST /group_cats or /group_cats.json
  def create
    @group_cat = GroupCat.new(group_cat_params)

    respond_to do |format|
      if @group_cat.valid?
        assigned_code = GroupCat.gen_group_code
        @group_cat.assigned_code = assigned_code
        @group_cat.save
        group_cats_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Group category was successfully created."

        format.js { render "/group_cats/group_cats_index" }
        format.html { redirect_to group_cat_path(id: @group_cat.id), notice: 'Group cat was successfully created.' }
        format.json { render :index, status: :created, location: @group_cat }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @group_cat.errors, status: :unprocessable_entity }
      end
    end
  end
  

  # PATCH/PUT /group_cats/1 or /group_cats/1.json
  def update
    respond_to do |format|
      @group_cat = GroupCat.where(active_status: true, assigned_code: params[:id]).order(created_at: :desc).first
      flash.now[:notice] = "Group category was updated successfully."

      logger.info params[:group_cat].inspect
      @new_record = GroupCat.new(group_cat_params)

      @new_record.assigned_code = @group_cat.assigned_code
      if @new_record.valid?
        @group_cat.active_status = false
        @group_cat.del_status = true
        @group_cat.save(validate: false)
        if @new_record.save
        else
        end
        group_cats_index
        format.js { render "/group_cats/group_cats_index" }
        format.html { redirect_to group_cats_path, notice: 'Group category was updated successfully.' }
        format.json { render :group_cats_index, status: :ok, location: @group_cat }
      else
        logger.info "Division Error Messages Edit :: #{@new_record.errors.messages.inspect}"

        format.html {render :edit}
        format.js { render :edit }
        format.json { render json: @group_cat.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /group_cats/1 or /group_cats/1.json
  def destroy
    @group_cat.destroy
    respond_to do |format|
      format.html { redirect_to group_cats_url, notice: "Group cat was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_group_cat
      # @group_cat = GroupCat.find(params[:id])
      @group_cat = GroupCat.where(active_status: true, assigned_code: params[:id]).order(created_at: :desc).first

    end

    # Only allow a list of trusted parameters through.
    def group_cat_params
      params.require(:group_cat).permit(:assigned_code, :entity_info_code, :group_cat_desc, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
