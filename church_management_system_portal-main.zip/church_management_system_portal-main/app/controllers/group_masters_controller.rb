class GroupMastersController < ApplicationController
  before_action :set_group_master, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /group_masters or /group_masters.json
  def index
    # @group_masters = GroupMaster.all
  end

  def group_masters_index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.super_admin? || current_user.user_admin?
    @group_cat_search = GroupCat.where(active_status: true).order(group_cat_desc: :desc)
    @group_master_search = GroupMaster.where(active_status: true).order(group_name: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)
    elsif current_user.merchant_admin?
      params[:main_code] = current_user.user_main_code
      @group_cat_search = GroupCat.where(entity_info_code: params[:main_code], active_status: true).order(group_cat_desc: :desc)
      @group_master_search = GroupMaster.where(entity_info_code: params[:main_code], active_status: true).order(group_name: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true AND ur.main_code = '#{params[:main_code]}'").order(username: :desc)

    else
    end

    if params[:count] == "All"
      @group_masters = GroupMaster.where(active_status: true).order('created_at desc')
      saved_size = @group_masters.exists? ? @group_masters.size : 0
      @group_masters = GroupMaster.where(active_status: true).paginate(page: 1, per_page: saved_size).order("id desc")
    else
    if current_user.super_admin? || current_user.user_admin?
      search_arr = ["active_status = true"]
    elsif current_user.merchant_admin?
      search_arr = ["entity_info_code = '#{params[:main_code]}' AND active_status = true"]
    end
      the_search = ""

      if params[:filter_main].present? || params[:assigned_code].present?|| params[:group_cat_code].present? || params[:active_status].present?|| params[:birth_date].present?|| params[:gender].present?|| params[:group_name].present?|| params[:first_name].present? || params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?

        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @assigned_code = filter_params[:assigned_code]
          @group_cat_code = filter_params[:group_cat_code]
          @active_status = filter_params[:active_status]
          @group_name = filter_params[:group_name]
          @username = filter_params[:user_id]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:assigned_code] = filter_params[:assigned_code]
          params[:group_cat_code] = filter_params[:group_cat_code]
          params[:active_status] = filter_params[:active_status]
          params[:group_name] = filter_params[:group_name]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        else

          if  params[:assigned_code].present? ||params[:group_cat_code].present? || params[:active_status].present?|| params[:birth_date].present?|| params[:gender].present?|| params[:group_name].present?|| params[:first_name].present?|| params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

            @assigned_code = params[:assigned_code]
            @group_cat_code = params[:group_cat_code]
            @active_status = params[:active_status]
            @group_name = params[:group_name]
            @username = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:assigned_code] = @assigned_code
            params[:group_cat_code] = @group_cat_code
            params[:active_status] = @active_status
            params[:group_name] = @group_name
            params[:user_id] = @susername
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:assigned_code] = filter_params[:assigned_code]
            params[:group_cat_code] = filter_params[:group_cat_code]
            params[:active_status] = filter_params[:active_status]
            params[:group_name] = filter_params[:group_name]
            params[:user_id] = filter_params[:user_id]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          end
        end

        if @assigned_code.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "assigned_code = '#{@assigned_code}'"
        end
        if @group_cat_code.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "group_cat_code = '#{@group_cat_code}'"
        end
        if @active_status.present?
          search_arr << "active_status = '#{@active_status}'"
        end

        if @group_name.present?
          search_arr << "group_name = '#{@group_name}'"
        end

        if @username.present?
          search_arr << "user_id = '#{@username}'"
        end

        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
      end

      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"

      @group_masters = GroupMaster.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
  end


  # GET /group_masters/1 or /group_masters/1.json
  def show
  end

  # GET /group_masters/new
  def new
    if current_user.super_admin? || current_user.user_admin?
      @entity_name_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
      @group_cat_search = GroupCat.where(active_status: true).order(group_cat_desc: :desc)
    elsif current_user.merchant_admin?
      params[:main_code] = current_user.user_main_code
      @entity_name_search = EntityInfo.where(assigned_code: params[:main_code], active_status: true).order(entity_name: :desc)
      @group_cat_search = GroupCat.where(entity_info_code: params[:main_code], active_status: true).order(group_cat_desc: :desc)

    else
    end
      @group_master = GroupMaster.new

  end

  # GET /group_masters/1/edit
  def edit
    if current_user.super_admin? || current_user.user_admin?
      @entity_name_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
    elsif current_user.merchant_admin?
      params[:main_code] = current_user.user_main_code
      @entity_name_search = EntityInfo.where(assigned_code: params[:main_code], active_status: true).order(entity_name: :desc)
      @group_cat_search = GroupCat.where(entity_info_code: params[:main_code], active_status: true).order(group_cat_desc: :desc)
    else
    end
  end

  # POST /group_masters or /group_masters.json
  def create
    @group_master = GroupMaster.new(group_master_params)

    respond_to do |format|
      if @group_master.valid?
        assigned_code = GroupMaster.group_master_code
        @group_master.assigned_code = assigned_code
        @group_master.save
        group_masters_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Group Type was successfully created."

        format.js { render "/group_masters/group_masters_index" }
        format.html { redirect_to group_masters_path(id: @group_master.id), notice: 'Group master was successfully created.' }
        format.json { render :index, status: :created, location: @group_master }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @group_master.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      @group_master = GroupMaster.where(active_status: true, assigned_code: params[:id]).order(created_at: :desc).first
      flash.now[:notice] = "Group Type was updated successfully."

      logger.info params[:group_master].inspect
      @new_record = GroupMaster.new(group_master_params)

      @new_record.assigned_code = @group_master.assigned_code
      if @new_record.valid?
        @group_master.active_status = false
        @group_master.del_status = true
        @group_master.save(validate: false)
        if @new_record.save
        else
          # GroupMaster.update_last_but_one("group_masters", @group_master.entity_code , prev_updated_at)
        end
        group_masters_index
        format.js { render "/group_masters/group_masters_index" }
        format.html { redirect_to group_masters_path, notice: 'Group Type was updated successfully.' }
        format.json { render :group_masters_index, status: :ok, location: @group_master }
      else
        logger.info "Division Error Messages Edit :: #{@new_record.errors.messages.inspect}"

        format.html {render :edit}
        format.js { render :edit }
        format.json { render json: @group_master.errors, status: :unprocessable_entity }
      end
    end
  end

  def group_update
    logger.info "Params:: #{params[:id_for_entity_info].inspect}"
    if params[:id_for_entity_info].empty?
      @entity_update_group = [["", ""]].insert(0,['Please select a Group Category', ""])
    else
      entity_update_group = GroupCat.where(entity_info_code: params[:id_for_entity_info],
                                                active_status: true).order(group_cat_desc: :desc)
                               .map { |a| [a.group_cat_desc, a.id] }.insert(0,['Please select a Group Category', ""])

      @entity_update_group = entity_update_group.empty? ? [["", ""]].insert(0,['Please select a Group Category', ""]) : entity_update_group
    end
    logger.info "For Group :: #{@entity_update_group.inspect}"
  end

  # DELETE /group_masters/1 or /group_masters/1.json
  def destroy
    @group_master.destroy
    respond_to do |format|
      format.html { redirect_to group_masters_url, notice: "Group master was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_group_master
      # @group_master = GroupMaster.find(params[:id])
      @group_master = GroupMaster.where(active_status: true, assigned_code: params[:id]).order(created_at: :desc).first

    end

    # Only allow a list of trusted parameters through.
    def group_master_params
      params.require(:group_master).permit(:assigned_code, :group_cat_code, :entity_info_code, :group_name, :group_alias, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
