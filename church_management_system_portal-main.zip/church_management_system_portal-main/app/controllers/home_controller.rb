class HomeController < ApplicationController
  def index
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.div_code
    params[:branch_code] = current_user.user_branch_code

    params[:count] ? params[:count] : params[:count] = 2
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.super_admin? || current_user.user_admin?
      # Membership Records
      @person_infos = PersonInfo.persons_join.where("person_infos.active_status = true").where("DATE(person_infos.created_at) =? ", Date.today.to_s).paginate(:page => params[:page], :per_page => params[:count]).order('person_infos.created_at desc')

      @last_name_search = PersonInfo.persons_join.where("person_infos.active_status = true").order('person_infos.last_name desc').order('person_infos.last_name desc')
      @first_name_search = PersonInfo.persons_join.where("person_infos.active_status = true").order('person_infos.first_name desc')
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

      # Gender and employment status
      @gender = PersonInfo.select("gender").where("active_status = true and birth_date is not null")
      @gender_count = @gender.count
      @gender_male_cnt = @gender.where(gender: 'M').count
      @gender_female_cnt = @gender.where(gender: 'F').count
      logger.info "================================================="
      logger.info "Gender Count :: #{@gender_count.inspect}"
      logger.info "Gender Male :: #{@gender_male_cnt.inspect}"
      logger.info "Gender Female :: #{@gender_female_cnt.inspect}"

      # members for today
      @member = PersonInfo.select("gender").where("active_status = true and birth_date is not null").where("DATE(person_infos.created_at) =? ", Date.today.to_s)
      @today_member_count = @member.count


      @emp_status_cnt = PersonExtraInfo.person_xtra_join.select("person_extra_infos.emp_status_code").where("psi.active_status = true AND person_extra_infos.active_status = true AND person_extra_infos.emp_status_code IS NOT NULL ")
      @emp_count = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'EMP'").count
      @self_emp = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'SMP'").count
      @ent_count = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'ENT'").count
      @pens_count = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'PNS'").count
      @ret_count = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'RTD'").count

      # Pie chart (ChartKick/fusionChart)
      @day_borns = PersonExtraInfo.person_xtra_join.select("day_born").where("psi.active_status = true AND person_extra_infos.active_status = true AND day_born IS NOT NULL").group("day_born").count
      logger.info "Day Borns :: #{@day_borns.inspect}"

      # Chartkick
      @day_born_pie = @day_borns.map{|a,b| [a,"#{b}"]}
      logger.info "Day borns :: #{@day_born.inspect}"
      # Pie chart fusionChart
      @day_born_3d = @day_borns.map{|day_born, val| { :label => day_born, :value => "#{val}" }}
      logger.info "Day borns 3d :: #{@day_born_3d.inspect}"

      # ChartKick (Column charts)
      @male_fmale_column = PersonInfo.select("gender").where("active_status = true AND gender IS NOT NULL").group("gender").count
      @employment_column = PersonExtraInfo.person_xtra_join.select("emp_status_code").where("psi.active_status = true AND person_extra_infos.active_status = true AND emp_status_code IS NOT NULL").group("emp_status_code").count
      @date_of_birth = PersonInfo.select("birth_date").where("active_status = true AND gender IS NOT NULL").group("birth_date").count

      # Column charts(age range)
      age_ranges = PersonInfo.find_by_sql(PersonInfo.gender_dist(current_user))
      gender_dist_male = PersonInfo.find_by_sql(PersonInfo.gender_dist(current_user, 'M'))
      gender_dist_female = PersonInfo.find_by_sql(PersonInfo.gender_dist(current_user, 'F'))

      # work in progress
      # emp_statuss = PersonExtraInfo.find_by_sql(PersonExtraInfo.emp_dist)
      # emp_dist = PersonInfo.find_by_sql(PersonInfo.emp_dist('EMP'))
      # slf_emp_dist = PersonInfo.find_by_sql(PersonInfo.emp_dist('SMP'))
      # retired_dist = PersonInfo.find_by_sql(PersonInfo.emp_dist('RTD'))
      # pens_dist = PersonInfo.find_by_sql(PersonInfo.emp_dist('PNS'))
      # ent_dist = PersonInfo.find_by_sql(PersonInfo.emp_dist('ENT'))
      #
      # @emp_statuss = emp_statuss.map{|emp_state| { :label => "#{emp_state.emp_state}" }}


      # ChartKick
      @gender_dist_male = gender_dist_male.map{|male| [male.age_range, male.member_number]}
      @gender_dist_female = gender_dist_female.map{|female| [female.age_range, female.member_number]}
      logger.info "Male Gender Dist. :: #{@gender_dist_male.inspect}"
      logger.info "Female Gender Dist. :: #{@gender_dist_female.inspect}"

      # Column charts(age range fusionChart)
      @category = age_ranges.map{|age_range| { :label => "#{age_range.age_range}" }}
      @gender_dist_male_fc = gender_dist_male.map{|male| { :value => "#{male.member_number}" }}
      @gender_dist_female_fc = gender_dist_female.map{|female| { :value => "#{female.member_number}" }}

      logger.info "Categories :: #{@category.inspect}"
      logger.info "Male Gender Dist. FC :: #{@gender_dist_male_fc.inspect}"
      logger.info "Female Gender Dist. FC :: #{@gender_dist_female_fc.inspect}"

      @chart = Fusioncharts::Chart.new(
        {
          width: '400',
          height: '350',
          type: 'mscolumn3d',
          renderAt: 'chartContainer',
          dataSource: {
            :"chart" => {
              :"paletteColors" => '#0066FF,#FFB700',
              :"caption" => 'Distribution of Members by Age',
              # :"subcaption" => 'Super User level',
              :"xaxisname" => 'Age range',
              :"yaxisname" => 'Number of members',
              :"formatnumberscale" => '1',
              :"plottooltext" =>
                '<b>$dataValue</b> <b>$seriesName</b> within $label',
              :"theme" => 'fusion'
            },
            :"categories" => [
              {
                :"category" => @category
              }
            ],
            :"dataset" => [
              {
                :"seriesname" => 'Males',
                :"data" => @gender_dist_male_fc
              },
              {
                :"seriesname" => 'Females',
                :"data" => @gender_dist_female_fc
              }
            ]
          }
        }
      )

      @chart_pie = Fusioncharts::Chart.new(
          {
            width: '400',
            height: '350',
            type: 'pie3d',
            renderAt: 'chartContainer1',
            dataSource: {
              :"chart" => {
                :"paletteColors" => '#0066FF,#FFB700,#00CE01,#67C7F9,#E4E4E4,#F12830,#F7FFA7',
                :"caption" => 'Dayborn Distributions',
                # :"subcaption" => 'For a net-worth of $1M',
                :"showvalues" => '1',
                :"showpercentintooltip" => '0',
                :"numberprefix" => '',
                :"enablemultislicing" => '1',
                :"theme" => 'fusion'
              },
              :"data" => @day_born_3d
            }
          }
        )


      @chart_emp_fc = Fusioncharts::Chart.new(
        {
          width: '700',
          height: '500',
          type: 'mscolumn3d',
          renderAt: 'chartContainer',
          dataSource: {
            :"chart" => {
              :"caption" => 'Distribution of Employment Status',
              # :"subcaption" => 'Super User level',
              :"xaxisname" => 'Age range',
              :"yaxisname" => 'Number of members',
              :"formatnumberscale" => '1',
              :"plottooltext" =>
                '<b>$dataValue</b> <b>$seriesName</b> within $label',
              :"theme" => 'fusion'
            },
            :"categories" => [
              {
                :"category" => @category
              }
            ],
            :"dataset" => [
              {
                :"seriesname" => 'Males',
                :"data" => @gender_dist_male_fc
              },
              {
                :"seriesname" => 'Females',
                :"data" => @gender_dist_female_fc
              }
            ]
          }
        }
      )
      
    elsif current_user.merchant_admin?
      @person_infos = PersonInfo.persons_join.where("person_infos.active_status = true AND person_infos.entity_info_code = '#{params[:main_code]}'").where("DATE(person_infos.created_at) =? ", Date.today.to_s).paginate(:page => params[:page], :per_page => params[:count]).order('person_infos.created_at desc')
      @last_name_search = PersonInfo.persons_join.where("person_infos.active_status = true AND person_infos.entity_info_code = '#{params[:main_code]}'").order('person_infos.last_name desc')
      @first_name_search = PersonInfo.persons_join.where("person_infos.active_status = true AND person_infos.entity_info_code = '#{params[:main_code]}'").order('person_infos.first_name desc')
      @user_search = User.unscoped.user_join.where("ur.del_status = false AND ur.main_code = '#{params[:main_code]}'").order(username: :desc)


      # Gender and employment status
      @gender = PersonInfo.select("gender").where("active_status = true AND entity_info_code = '#{params[:main_code]}'")
      @gender_count = @gender.count
      @gender_male_cnt = @gender.where(gender: 'M').count
      @gender_female_cnt = @gender.where(gender: 'F').count
      logger.info "================================================="
      logger.info "Gender Count :: #{@gender_count.inspect}"
      logger.info "Gender Male :: #{@gender_male_cnt.inspect}"
      logger.info "Gender Female :: #{@gender_female_cnt.inspect}"

      # Members for today
      @member = PersonInfo.select("gender").where("active_status = true AND entity_info_code = '#{params[:main_code]}'").where("DATE(person_infos.created_at) =? ", Date.today.to_s)
      @today_member_count = @member.count

      @emp_status_cnt = PersonExtraInfo.person_xtra_join.select("person_extra_infos.emp_status_code").where("psi.active_status = true AND person_extra_infos.active_status = true AND psi.entity_info_code = '#{params[:main_code]}' AND person_extra_infos.emp_status_code IS NOT NULL ")
      @emp_count = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'EMP'").count
      @self_emp = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'SMP'").count
      @ent_count = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'ENT'").count
      @pens_count = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'PNS'").count
      @ret_count = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'RTD'").count

      # Pie chart
      @day_borns = PersonExtraInfo.person_xtra_join.select("day_born").where("psi.active_status = true AND person_extra_infos.active_status = true AND psi.entity_info_code = '#{params[:main_code]}' AND day_born IS NOT NULL").group("day_born").count
      logger.info "Day Borns :: #{@day_borns.inspect}"

      # Pie chart fusionChart
      @day_born_3d = @day_borns.map{|day_born, val| { :label => day_born, :value => "#{val}" }}
      logger.info "Day borns 3d :: #{@day_born_3d.inspect}"

      # Column charts
      @male_fmale_column = PersonInfo.select("gender").where("active_status = true AND gender IS NOT NULL AND entity_info_code = '#{params[:main_code]}'").group("gender").count
      @employment_column = PersonExtraInfo.person_xtra_join.select("emp_status_code").where("psi.active_status = true AND person_extra_infos.active_status = true AND psi.entity_info_code = '#{params[:main_code]}' AND emp_status_code IS NOT NULL").group("emp_status_code").count
      @date_of_birth = PersonInfo.select("birth_date").where("active_status = true AND gender IS NOT NULL AND entity_info_code = '#{params[:main_code]}'").group("birth_date").count

      # Column charts(age range)
      age_ranges = PersonInfo.find_by_sql(PersonInfo.gender_dist(current_user))
      gender_dist_male = PersonInfo.find_by_sql(PersonInfo.gender_dist(current_user, 'M'))
      gender_dist_female = PersonInfo.find_by_sql(PersonInfo.gender_dist(current_user, 'F'))

      # Column charts(age range fusionChart)
      @category = age_ranges.map{|age_range| { :label => "#{age_range.age_range}" }}
      @gender_dist_male_fc = gender_dist_male.map{|male| { :value => "#{male.member_number}" }}
      @gender_dist_female_fc = gender_dist_female.map{|female| { :value => "#{female.member_number}" }}

      logger.info "Categories :: #{@category.inspect}"
      logger.info "Male Gender Dist. FC :: #{@gender_dist_male_fc.inspect}"
      logger.info "Female Gender Dist. FC :: #{@gender_dist_female_fc.inspect}"

      @chart = Fusioncharts::Chart.new(
        {
          width: '400',
          height: '375',
          type: 'mscolumn3d',
          renderAt: 'chartContainer',
          dataSource: {
            :"chart" => {
              :"paletteColors" => '#0066FF,#FFB700',
              :"caption" => 'Distribution of Members by Age',
              # :"subcaption" => 'Super User level',
              :"xaxisname" => 'Age range',
              :"yaxisname" => 'Number of members',
              :"formatnumberscale" => '1',
              :"plottooltext" =>
                '<b>$dataValue</b> <b>$seriesName</b> within $label',
              :"theme" => 'fusion'
            },
            :"categories" => [
              {
                :"category" => @category
              }
            ],
            :"dataset" => [
              {
                :"seriesname" => 'Males',
                :"data" => @gender_dist_male_fc
              },
              {
                :"seriesname" => 'Females',
                :"data" => @gender_dist_female_fc
              }
            ]
          }
        }
      )

      @chart_pie = Fusioncharts::Chart.new(
        {
          width: '400',
          height: '375',
          type: 'pie3d',
          renderAt: 'chartContainer1',
          dataSource: {
            :"chart" => {
              :"paletteColors" => '#0066FF,#FFB700,#00CE01,#67C7F9,#E4E4E4,#F12830,#F7FFA7',
              :"caption" => 'Dayborn Distributions',
              # :"subcaption" => 'For a net-worth of $1M',
              :"showvalues" => '1',
              :"showpercentintooltip" => '0',
              :"numberprefix" => '',
              :"enablemultislicing" => '1',
              :"theme" => 'fusion'
            },
            :"data" => @day_born_3d
          }
        }
      )


    elsif current_user.division_admin?
      @person_infos = PersonInfo.persons_join.where("person_infos.active_status = true AND person_infos.entity_info_code = '#{params[:main_code]}'").where("DATE(person_infos.created_at) =? ", Date.today.to_s).paginate(:page => params[:page], :per_page => params[:count]).order('person_infos.created_at desc')
      @last_name_search = PersonInfo.persons_join.where("person_infos.active_status = true AND person_infos.assigned_code = '#{params[:main_code]}'").order('person_infos.last_name desc')
      @first_name_search = PersonInfo.persons_join.where("person_infos.active_status = true AND person_infos.entity_info_code = '#{params[:main_code]}'").order('person_infos.first_name desc')
      # @first_name_search = PersonInfo.persons_join.where("person_infos.active_status = true AND exi.entity_division_code = '#{params[:div_code]}'").order('person_infos.first_name desc')
      @user_search = User.unscoped.user_join.where("ur.del_status = false AND ur.div_code = '#{params[:div_code]}'").order(username: :desc)

      # Gender and employment status
      @gender = PersonInfo.select("gender").where("active_status = true AND entity_info_code = '#{params[:main_code]}'")
      @gender_count = @gender.count
      @gender_male_cnt = @gender.where(gender: 'M').count
      @gender_female_cnt = @gender.where(gender: 'F').count
      logger.info "================================================="
      logger.info "Gender Count :: #{@gender_count.inspect}"
      logger.info "Gender Male :: #{@gender_male_cnt.inspect}"
      logger.info "Gender Female :: #{@gender_female_cnt.inspect}"

      # members for today
      @member = PersonInfo.select("gender").where("active_status = true AND entity_info_code = '#{params[:main_code]}'").where("DATE(person_infos.created_at) =? ", Date.today.to_s)
      @today_member_count = @member.count

      @emp_status_cnt = PersonExtraInfo.person_xtra_join.select("person_extra_infos.emp_status_code").where("psi.active_status = true AND person_extra_infos.active_status = true AND psi.entity_info_code = '#{params[:main_code]}' AND person_extra_infos.emp_status_code IS NOT NULL ")
      @emp_count = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'EMP'").count
      @self_emp = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'SMP'").count
      @ent_count = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'ENT'").count
      @pens_count = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'PNS'").count
      @ret_count = @emp_status_cnt.where("person_extra_infos.emp_status_code = 'RTD'").count

      # Pie chart
      @day_borns = PersonExtraInfo.person_xtra_join.select("day_born").where("psi.active_status = true AND person_extra_infos.active_status = true AND psi.entity_info_code = '#{params[:main_code]}' AND day_born IS NOT NULL").group("day_born").count
      logger.info "Day Borns :: #{@day_borns.inspect}"

      # Pie chart fusionChart
      @day_born_3d = @day_borns.map{|day_born, val| { :label => day_born, :value => "#{val}" }}
      logger.info "Day borns 3d :: #{@day_born_3d.inspect}"

      # Column charts
      @male_fmale_column = PersonInfo.select("gender").where("active_status = true AND gender IS NOT NULL AND entity_info_code = '#{params[:main_code]}'").group("gender").count
      @employment_column = PersonExtraInfo.person_xtra_join.select("emp_status_code").where("psi.active_status = true AND person_extra_infos.active_status = true AND psi.entity_info_code = '#{params[:main_code]}' AND emp_status_code IS NOT NULL").group("emp_status_code").count
      @date_of_birth = PersonInfo.select("birth_date").where("active_status = true AND gender IS NOT NULL AND entity_info_code = '#{params[:main_code]}'").group("birth_date").count

      # Column charts(age range)
      age_ranges = PersonInfo.find_by_sql(PersonInfo.gender_dist(current_user))
      gender_dist_male = PersonInfo.find_by_sql(PersonInfo.gender_dist(current_user, 'M'))
      gender_dist_female = PersonInfo.find_by_sql(PersonInfo.gender_dist(current_user, 'F'))

      # Column charts(age range fusionChart)
      @category = age_ranges.map{|age_range| { :label => "#{age_range.age_range}" }}
      @gender_dist_male_fc = gender_dist_male.map{|male| { :value => "#{male.member_number}" }}
      @gender_dist_female_fc = gender_dist_female.map{|female| { :value => "#{female.member_number}" }}

      logger.info "Categories :: #{@category.inspect}"
      logger.info "Male Gender Dist. FC :: #{@gender_dist_male_fc.inspect}"
      logger.info "Female Gender Dist. FC :: #{@gender_dist_female_fc.inspect}"

      @chart = Fusioncharts::Chart.new(
        {
          width: '400',
          height: '375',
          type: 'mscolumn3d',
          renderAt: 'chartContainer',
          dataSource: {
            :"chart" => {
              :"paletteColors" => '#0066FF,#FFB700',
              :"caption" => 'Distribution of Members by Age',
              # :"subcaption" => 'Super User level',
              :"xaxisname" => 'Age range',
              :"yaxisname" => 'Number of members',
              :"formatnumberscale" => '1',
              :"plottooltext" =>
                '<b>$dataValue</b> <b>$seriesName</b> within $label',
              :"theme" => 'fusion'
            },
            :"categories" => [
              {
                :"category" => @category
              }
            ],
            :"dataset" => [
              {
                :"seriesname" => 'Males',
                :"data" => @gender_dist_male_fc
              },
              {
                :"seriesname" => 'Females',
                :"data" => @gender_dist_female_fc
              }
            ]
          }
        }
      )

      @chart_pie = Fusioncharts::Chart.new(
        {
          width: '400',
          height: '375',
          type: 'pie3d',
          renderAt: 'chartContainer1',
          dataSource: {
            :"chart" => {
              :"paletteColors" => '#0066FF,#FFB700,#00CE01,#67C7F9,#E4E4E4,#F12830,#F7FFA7',
              :"caption" => 'Dayborn Distributions',
              # :"subcaption" => 'For a net-worth of $1M',
              :"showvalues" => '1',
              :"showpercentintooltip" => '0',
              :"numberprefix" => '',
              :"enablemultislicing" => '1',
              :"theme" => 'fusion'
            },
            :"data" => @day_born_3d
          }
        }
      )

    elsif current_user.branch_admin?
      @person_infos = PersonInfo.persons_join.where("person_infos.active_status = true AND person_infos.entity_info_code = '#{params[:main_code]}'").where("DATE(person_infos.created_at) =? ", Date.today.to_s).paginate(:page => params[:page], :per_page => params[:count]).order('person_infos.created_at desc')
      @last_name_search = PersonInfo.persons_join.where("person_infos.active_status = true AND person_infos.assigned_code = '#{params[:main_code]}'").order('person_infos.last_name desc')
      @first_name_search = PersonInfo.persons_join.where("person_infos.active_status = true AND person_infos.entity_info_code = '#{params[:main_code]}'").order('person_infos.first_name desc')
      # @first_name_search = PersonInfo.persons_join.where("person_infos.active_status = true AND exi.entity_division_code = '#{params[:div_code]}'").order('person_infos.first_name desc')
      @user_search = User.unscoped.user_join.where("ur.del_status = false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(username: :desc)

      # Gender and employment status
      @gender = PersonInfo.person_branch_2.select("gender").where("person_infos.active_status = true AND pxi.active_status = true AND birth_date IS NOT NULL AND pse.sub_entity_code = '#{params[:branch_code]}'")
      @gender_count = @gender.count
      @gender_male_cnt = @gender.where(gender: 'M').count
      @gender_female_cnt = @gender.where(gender: 'F').count
      logger.info "================================================="
      logger.info "Gender Count :: #{@gender_count.inspect}"
      logger.info "Gender Male :: #{@gender_male_cnt.inspect}"
      logger.info "Gender Female :: #{@gender_female_cnt.inspect}"

      # Members for today
      @member = PersonInfo.person_branch_2.select("gender").where("person_infos.active_status = true AND pxi.active_status = true AND birth_date IS NOT NULL AND pse.sub_entity_code = '#{params[:branch_code]}'").where("DATE(person_infos.created_at) =? ", Date.today.to_s)
      @today_member_count = @member.count

      @emp_status_cnt = PersonInfo.person_branch_2.select("pxi.emp_status_code").where("person_infos.active_status = true AND pxi.active_status = true AND pxi.emp_status_code IS NOT NULL AND pse.sub_entity_code = '#{params[:branch_code]}'")
      @emp_count = @emp_status_cnt.where("pxi.emp_status_code = 'EMP'").count
      @self_emp = @emp_status_cnt.where("pxi.emp_status_code = 'SMP'").count
      @ent_count = @emp_status_cnt.where("pxi.emp_status_code = 'ENT'").count
      @pens_count = @emp_status_cnt.where("pxi.emp_status_code = 'PNS'").count
      @ret_count = @emp_status_cnt.where("pxi.emp_status_code = 'RTD'").count

      # Pie chart fusionChart
      @day_borns = PersonInfo.person_branch_2.select("day_born").where("person_infos.active_status = true AND pxi.active_status = true AND day_born IS NOT NULL AND pse.sub_entity_code = '#{params[:branch_code]}'").group("day_born").count
      logger.info "Day Borns :: #{@day_borns.inspect}"

      @day_born_3d = @day_borns.map{|day_born, val| { :label => day_born, :value => "#{val}" }}
      logger.info "Day borns 3d :: #{@day_born_3d.inspect}"

      # Column charts
      @male_fmale_column = PersonInfo.person_branch_2.select("gender").where("person_infos.active_status = true AND gender IS NOT NULL AND pse.sub_entity_code = '#{params[:branch_code]}'").group("gender").count
      @employment_column = PersonInfo.person_branch_2.select("emp_status_code").where("person_infos.active_status = true AND pxi.active_status = true AND emp_status_code IS NOT NULL AND pse.sub_entity_code = '#{params[:branch_code]}'").group("emp_status_code").count
      @date_of_birth = PersonInfo.person_branch_2.select("birth_date").where("person_infos.active_status = true AND gender IS NOT NULL AND pse.sub_entity_code = '#{params[:branch_code]}'").group("birth_date").count

      # Column charts(age range)
      age_ranges = PersonInfo.find_by_sql(PersonInfo.gender_dist(current_user))
      gender_dist_male = PersonInfo.find_by_sql(PersonInfo.gender_dist(current_user, 'M'))
      gender_dist_female = PersonInfo.find_by_sql(PersonInfo.gender_dist(current_user, 'F'))

      @gender_dist_male = gender_dist_male.map{|male| [male.age_range, male.member_number]}
      @gender_dist_female = gender_dist_female.map{|female| [female.age_range, female.member_number]}
      logger.info "Male Gender Dist. :: #{@gender_dist_male.inspect}"
      logger.info "Female Gender Dist. :: #{@gender_dist_female.inspect}"

      # Column charts(age range fusionChart)
      @category = age_ranges.map{|age_range| { :label => "#{age_range.age_range}" }}
      @gender_dist_male_fc = gender_dist_male.map{|male| { :value => "#{male.member_number}" }}
      @gender_dist_female_fc = gender_dist_female.map{|female| { :value => "#{female.member_number}" }}

      logger.info "Categories :: #{@category.inspect}"
      logger.info "Male Gender Dist. FC :: #{@gender_dist_male_fc.inspect}"
      logger.info "Female Gender Dist. FC :: #{@gender_dist_female_fc.inspect}"

      @chart = Fusioncharts::Chart.new(
        {
          width: '400',
          height: '375',
          type: 'mscolumn3d',
          renderAt: 'chartContainer',
          dataSource: {
            :"chart" => {
              :"paletteColors" => '#0066FF,#FFB700',
              :"caption" => 'Distribution of Members by Age',
              # :"subcaption" => 'Super User level',
              :"xaxisname" => 'Age range',
              :"yaxisname" => 'Number of members',
              :"formatnumberscale" => '1',
              :"plottooltext" =>
                '<b>$dataValue</b> <b>$seriesName</b> within $label',
              :"theme" => 'fusion'
            },
            :"categories" => [
              {
                :"category" => @category
              }
            ],
            :"dataset" => [
              {
                :"seriesname" => 'Males',
                :"data" => @gender_dist_male_fc
              },
              {
                :"seriesname" => 'Females',
                :"data" => @gender_dist_female_fc
              }
            ]
          }
        }
      )

      @chart_pie = Fusioncharts::Chart.new(
        {
          width: '400',
          height: '375',
          type: 'pie3d',
          renderAt: 'chartContainer1',
          dataSource: {
            :"chart" => {
              :"paletteColors" => '#0066FF,#FFB700,#00CE01,#67C7F9,#E4E4E4,#F12830,#F7FFA7',
              :"caption" => 'Dayborn Distributions',
              # :"subcaption" => 'For a net-worth of $1M',
              :"showvalues" => '1',
              :"showpercentintooltip" => '0',
              :"numberprefix" => '',
              :"enablemultislicing" => '1',
              :"theme" => 'fusion'
            },
            :"data" => @day_born_3d
          }
        }
      )

    end

  end



  def home_index
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.div_code
    params[:branch_code] = current_user.user_branch_code

    if current_user.super_admin? || current_user.user_admin?
      # Gender count
      @gender = PersonInfo.select("gender").where("active_status = true and birth_date is not null").where("DATE(person_infos.created_at) =? ", Date.today.to_s)
      @gender_count = @gender.count
      # Membership Records
      if params[:count] == 'All'
        @person_infos = PersonInfo.persons_join
        saved_size = @person_infos.exists? ? @person_infos.size : 0
        @person_infos = PersonInfo.persons_join.where("person_infos.active_status = true").where("DATE(person_infos.created_at) =? ", Date.today.to_s).paginate(:page => 1, :per_page => saved_size).order('person_infos.created_at desc')
      else
        @person_infos = PersonInfo.persons_join.where("person_infos.active_status = true").where("DATE(person_infos.created_at) =? ", Date.today.to_s).paginate(:page => params[:page], :per_page => params[:count]).order('person_infos.created_at desc')
      end
    elsif current_user.merchant_admin?
      # Gender Count
      @gender = PersonInfo.select("gender").where("active_status = true AND entity_info_code = '#{params[:main_code]}'").where("DATE(person_infos.created_at) =? ", Date.today.to_s)
      @gender_count = @gender.count

      if params[:count] == "All"
        @person_infos = PersonInfo.persons_join
        saved_size = @person_infos.exists? ? @person_infos.size : 0
        @person_infos = PersonInfo.persons_join.where("person_infos.active_status = true").where("DATE(person_infos.created_at) =? ", Date.today.to_s).paginate(:page => 1, :per_page => saved_size).order('person_infos.created_at desc')
      else
        @person_infos = PersonInfo.persons_join.where("person_infos.entity_info_code = '#{params[:main_code]}' AND person_infos.active_status = true").where("DATE(person_infos.created_at) =? ", Date.today.to_s).paginate(:page => params[:page], :per_page => params[:count]).order('person_infos.created_at desc')
      end

    elsif current_user.division_admin?
      # Gender Count
      @gender = PersonInfo.select("gender").where("active_status = true AND entity_info_code = '#{params[:main_code]}'").where("DATE(person_infos.created_at) =? ", Date.today.to_s)
      @gender_count = @gender.count

      if params[:count] == "All"
        @person_infos = PersonInfo.persons_join
        saved_size = @person_infos.exists? ? @person_infos.size : 0
        @person_infos = PersonInfo.persons_join.where("person_infos.active_status = true").where("DATE(person_infos.created_at) =? ", Date.today.to_s).paginate(:page => 1, :per_page => saved_size).order('person_infos.created_at desc')
      else
        @person_infos = PersonInfo.persons_join.where("person_infos.entity_info_code = '#{params[:main_code]}' AND person_infos.active_status = true").where("DATE(person_infos.created_at) =? ", Date.today.to_s).paginate(:page => params[:page], :per_page => params[:count]).order('person_infos.created_at desc')
      end

    elsif current_user.branch_admin? || current_user.branch_user?
      # Gender Count
      @gender = PersonInfo.person_branch_2.select("gender").where("person_infos.active_status = true AND pxi.active_status = true AND birth_date IS NOT NULL AND pse.sub_entity_code = '#{params[:branch_code]}'").where("DATE(person_infos.created_at) =? ", Date.today.to_s)
      @gender_count = @gender.count

      if params[:count] == "All"
        @person_infos = PersonInfo.persons_join
        saved_size = @person_infos.exists? ? @person_infos.size : 0
        @person_infos = PersonInfo.persons_join.where("person_infos.active_status = true").where("DATE(person_infos.created_at) =? ", Date.today.to_s).paginate(:page => 1, :per_page => saved_size).order('person_infos.created_at desc')
      else
        @person_infos = PersonInfo.persons_join.where("person_infos.entity_info_code = '#{params[:main_code]}' AND person_infos.active_status = true").where("DATE(person_infos.created_at) =? ", Date.today.to_s).paginate(:page => params[:page], :per_page => params[:count]).order('person_infos.created_at desc')
      end
    end



  end

end
