class IssueLogTypesController < ApplicationController
  before_action :set_issue_log_type, only: %i[ show edit update destroy ]

  # GET /issue_log_types or /issue_log_types.json
  def index
    @issue_log_types = IssueLogType.all
  end

  # GET /issue_log_types/1 or /issue_log_types/1.json
  def show
  end

  # GET /issue_log_types/new
  def new
    @issue_log_type = IssueLogType.new
  end

  # GET /issue_log_types/1/edit
  def edit
  end

  # POST /issue_log_types or /issue_log_types.json
  def create
    @issue_log_type = IssueLogType.new(issue_log_type_params)

    respond_to do |format|
      if @issue_log_type.save
        format.html { redirect_to issue_log_type_url(@issue_log_type), notice: "Issue log type was successfully created." }
        format.json { render :show, status: :created, location: @issue_log_type }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @issue_log_type.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /issue_log_types/1 or /issue_log_types/1.json
  def update
    respond_to do |format|
      if @issue_log_type.update(issue_log_type_params)
        format.html { redirect_to issue_log_type_url(@issue_log_type), notice: "Issue log type was successfully updated." }
        format.json { render :show, status: :ok, location: @issue_log_type }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @issue_log_type.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /issue_log_types/1 or /issue_log_types/1.json
  def destroy
    @issue_log_type.destroy

    respond_to do |format|
      format.html { redirect_to issue_log_types_url, notice: "Issue log type was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_issue_log_type
      @issue_log_type = IssueLogType.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def issue_log_type_params
      params.require(:issue_log_type).permit(:log_type_desc, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
