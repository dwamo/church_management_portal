class JobCatsController < ApplicationController
  before_action :set_job_cat, only: [:show, :edit, :update, :destroy]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /job_cats or /job_cats.json
  def index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    # params[:main_code] = current_user.user_main_code
    # params[:div_code] = current_user.div_code

    @job_cats = JobCat.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    @job_types = JobType.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    @person_emp_infos = PersonEmpInfo.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

    @job_cat_search = JobCat.where(active_status: true).order(job_cat_desc: :desc)
    @job_type_search = JobType.where(active_status: true).order(job_type_desc: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

  end

  def job_cats_index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @job_cat_search = JobCat.where(active_status: true).order(job_cat_desc: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

    if params[:count] == "All"
      @job_cats = JobCat.where(active_status: true).order('created_at desc')
      saved_size = @job_cats.exists? ? @job_cats.size : 0
      @job_cats = JobCat.where(active_status: true).paginate(page: 1, per_page: saved_size).order("id desc")
    else

      the_search = ""
      search_arr = ["del_status = false"]

      if params[:filter_main].present? || params[:job_cat_desc].present? || params[:entity_alias].present? || params[:active_status].present? || params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?

        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @job_cat_desc = filter_params[:job_cat_desc]
          @entity_alias = filter_params[:entity_alias]
          @active_status = filter_params[:active_status]
          @username = filter_params[:user_id]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:job_cat_desc] = filter_params[:job_cat_desc]
          params[:entity_alias] = filter_params[:entity_alias]
          params[:active_status] = filter_params[:active_status]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        else

          if  params[:job_cat_desc].present? || params[:entity_alias].present? || params[:active_status].present?|| params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

            @job_cat_desc = params[:job_cat_desc]
            @active_status = params[:active_status]
            @username = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:job_cat_desc] = @job_cat_desc
            params[:active_status] = @active_status
            params[:user_id] = @username
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:job_cat_desc] = filter_params[:job_cat_desc]
            params[:active_status] = filter_params[:active_status]
            params[:user_id] = filter_params[:user_id]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          end
        end

        if @job_cat_desc.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "job_cat_desc = '#{@job_cat_desc}'"
        end
        if @active_status.present?
          search_arr << "active_status = '#{@active_status}'"
        end
        if @username.present?
          search_arr << "user_id = '#{@username}'"
        end

        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
      end


      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"


      @job_cats = JobCat.where(del_status: false).where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
  end
  # GET /job_cats/1 or /job_cats/1.json
  def show
  end

  # GET /job_cats/new
  def new
    @job_cat = JobCat.new
  end

  # GET /job_cats/1/edit
  def edit
  end

  # POST /job_cats or /job_cats.json
  def create
    @job_cat = JobCat.new(job_cat_params)

    respond_to do |format|
      if @job_cat.valid?
        assigned_code = JobCat.job_cats_code
        @job_cat.assigned_code = assigned_code
        @job_cat.save
        job_cats_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Job cat was successfully created."

        format.js { render "/job_cats/job_cats_index" }
        format.html { redirect_to job_cat_path(id: @job_cat.id), notice: 'Job cat was successfully created.' }
        format.json { render :index, status: :created, location: @job_cat }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @job_cat.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @job_cat.update(job_cat_params)
        job_cats_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Job cat was successfully updated."

        format.js { render "/job_cats/job_cats_index" }
        format.html { redirect_to job_cats_path(id: @job_cat.id)}
        format.json { render :job_cats_index, status: :ok, location: @job_cat }

      else
        format.js { render :edit }
        format.html { render :edit }
        format.json { render json: @job_cat.errors, status: :unprocessable_entity }
      end
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_job_cat
      @job_cat = JobCat.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def job_cat_params
      params.require(:job_cat).permit(:assigned_code, :job_cat_desc, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
