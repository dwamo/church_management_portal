class JobTypesController < ApplicationController
  before_action :set_job_type, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource

  def job_types_index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @job_cat_search = JobCat.where(active_status: true).order(job_cat_desc: :desc)
    @job_type_search = JobType.where(active_status: true).order(job_type_desc: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)


    if params[:count] == "All"
      @job_types = JobType.where(active_status: true).order('created_at desc')
      saved_size = @job_types.exists? ? @job_types.size : 0
      @job_types = JobType.where(active_status: true).paginate(page: 1, per_page: saved_size).order("id desc")
    else

      search_arr = ["active_status = true"]
      the_search = ""

      if params[:filter_main].present? || params[:assigned_code].present?|| params[:job_cat_code].present? || params[:active_status].present?|| params[:birth_date].present?|| params[:gender].present?|| params[:job_type_desc].present?|| params[:first_name].present? || params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?

        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @assigned_code = filter_params[:assigned_code]
          @job_cat_code = filter_params[:job_cat_code]
          @active_status = filter_params[:active_status]
          @job_type_desc = filter_params[:job_type_desc]
          @username = filter_params[:user_id]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:assigned_code] = filter_params[:assigned_code]
          params[:job_cat_code] = filter_params[:job_cat_code]
          params[:active_status] = filter_params[:active_status]
          params[:job_type_desc] = filter_params[:job_type_desc]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        else

          if  params[:assigned_code].present? ||params[:job_cat_code].present? || params[:active_status].present?|| params[:birth_date].present?|| params[:gender].present?|| params[:job_type_desc].present?|| params[:first_name].present?|| params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

            @assigned_code = params[:assigned_code]
            @job_cat_code = params[:job_cat_code]
            @active_status = params[:active_status]
            @job_type_desc = params[:job_type_desc]
            @username = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:assigned_code] = @assigned_code
            params[:job_cat_code] = @job_cat_code
            params[:active_status] = @active_status
            params[:job_type_desc] = @job_type_desc
            params[:user_id] = @susername
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:assigned_code] = filter_params[:assigned_code]
            params[:job_cat_code] = filter_params[:job_cat_code]
            params[:active_status] = filter_params[:active_status]
            params[:job_type_desc] = filter_params[:job_type_desc]
            params[:user_id] = filter_params[:user_id]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          end
        end

        if @assigned_code.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "assigned_code = '#{@assigned_code}'"
        end
        if @job_cat_code.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "job_cat_code = '#{@job_cat_code}'"
        end
        if @active_status.present?
          search_arr << "active_status = '#{@active_status}'"
        end

        if @job_type_desc.present?
          search_arr << "job_type_desc = '#{@job_type_desc}'"
        end

        if @username.present?
          search_arr << "user_id = '#{@username}'"
        end

        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
      end

      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"

      @job_types = JobType.where(del_status: false).where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
  end
  
  
  # GET /job_types/1 or /job_types/1.json
  def show
  end

  # GET /job_types/new
  def new
    @job_type = JobType.new

    @job_cat_search = JobCat.where(active_status: true).order(job_cat_desc: :desc)
  end

  # GET /job_types/1/edit
  def edit
    @job_cat_search = JobCat.where(active_status: true).order(job_cat_desc: :desc)
    
  end

  # PATCH/PUT /job_types/1 or /job_types/1.json
  def create
    @job_type = JobType.new(job_type_params)

    respond_to do |format|
      if @job_type.valid?
        assigned_code = JobType.job_type_code
        @job_type.assigned_code = assigned_code
        @job_type.save
        job_types_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Job type was successfully created."

        format.js { render "/job_types/job_types_index" }
        format.html { redirect_to set_job_type_path(id: @job_type.id), notice: 'Job type was successfully created.' }
        format.json { render :index, status: :created, location: @job_type }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @job_type.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @job_type.update(job_type_params)
        job_types_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Job type was updated successfully."

        format.js { render "/job_types/job_types_index" }
        format.html { redirect_to job_types_path(id: @job_type.id)}
        format.json { render :job_types_index, status: :ok, location: @job_type }

      else
        format.js { render :edit }
        format.html { render :edit }
        format.json { render json: @job_type.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /job_types/1 or /job_types/1.json
  def destroy
    @job_type.destroy
    respond_to do |format|
      format.html { redirect_to job_types_url, notice: "Job type was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_job_type
      @job_type = JobType.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def job_type_params
      params.require(:job_type).permit(:assigned_code, :job_cat_code, :job_type_desc, :comment, :active_status, :del_status, :comment, :created_at, :updated_at)
    end
end
