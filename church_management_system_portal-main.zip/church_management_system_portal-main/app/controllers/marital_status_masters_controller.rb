class MaritalStatusMastersController < ApplicationController
  before_action :set_marital_status_master, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /marital_status_masters or /marital_status_masters.json
  def index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

      @marital_status_masters = MaritalStatusMaster.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @marital_status_search = MaritalStatusMaster.where(active_status: true).order(status_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

  end

  def marital_status_masters_index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

      @marital_status_search = MaritalStatusMaster.where(active_status: true).order(status_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

    if params[:count] == "All"
      @marital_status_masters = MaritalStatusMaster.where(active_status: true).order('created_at desc')
      saved_size = @marital_status_masters.exists? ? @marital_status_masters.size : 0
      @marital_status_masters = MaritalStatusMaster.where(active_status: true).paginate(page: 1, per_page: saved_size).order("id desc")
    else

        search_arr = ["active_status = true"]
      the_search = ""

      if params[:filter_main].present? || params[:active_status].present?|| params[:birth_date].present?|| params[:gender].present?|| params[:status_desc].present?|| params[:first_name].present? || params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?

        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @active_status = filter_params[:active_status]
          @status_desc = filter_params[:status_desc]
          @username = filter_params[:user_id]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:active_status] = filter_params[:active_status]
          params[:status_desc] = filter_params[:status_desc]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        else

          if params[:active_status].present?|| params[:birth_date].present?|| params[:gender].present?|| params[:status_desc].present?|| params[:first_name].present?|| params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

            @active_status = params[:active_status]
            @status_desc = params[:status_desc]
            @username = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:active_status] = @active_status
            params[:status_desc] = @status_desc
            params[:user_id] = @susername
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:active_status] = filter_params[:active_status]
            params[:status_desc] = filter_params[:status_desc]
            params[:user_id] = filter_params[:user_id]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          end
        end

        if @active_status.present?
          search_arr << "active_status = '#{@active_status}'"
        end

        if @status_desc.present?
          search_arr << "assigned_code = '#{@status_desc}'"
        end

        if @username.present?
          search_arr << "user_id = '#{@username}'"
        end

        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
      end

      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"

      @marital_status_masters = MaritalStatusMaster.where(del_status: false).where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
  end
  # GET /marital_status_masters/1 or /marital_status_masters/1.json
  def show
  end

  # GET /marital_status_masters/new
  def new
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    @job_cat_code_search = JobCat.where(active_status: true).order(job_cat_desc: :desc)

    @marital_status_master = MaritalStatusMaster.new

  end

  # GET /marital_status_masters/1/edit
  def edit
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
  end

  # POST /marital_status_masters or /marital_status_masters.json
  def create1
    @marital_status_master = MaritalStatusMaster.new(marital_status_master_params)

    respond_to do |format|
      if @marital_status_master.save
        format.html { redirect_to @marital_status_master, notice: "Marital Status was successfully created." }
        format.json { render :show, status: :created, location: @marital_status_master }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @marital_status_master.errors, status: :unprocessable_entity }
      end
    end
  end

  def create
    @marital_status_master = MaritalStatusMaster.new(marital_status_master_params)

    respond_to do |format|
      if @marital_status_master.valid?
        @marital_status_master.save
        marital_status_masters_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Marital Status was successfully created."

        format.js { render "/marital_status_masters/marital_status_masters_index" }
        format.html { redirect_to marital_status_master_path(id: @marital_status_master.id), notice: 'Marital Status was successfully created.' }
        format.json { render :index, status: :created, location: @marital_status_master }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @marital_status_master.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /marital_status_masters/1 or /marital_status_masters/1.json
  def update
    respond_to do |format|
      if @marital_status_master.update(marital_status_master_params)
        marital_status_masters_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Marital Status was updated successfully."

        format.js { render "/marital_status_masters/marital_status_masters_index" }
        format.html { redirect_to marital_status_masters_path(id: @marital_status_master.id)}
        format.json { render :marital_status_masters_index, status: :ok, location: @marital_status_master }

      else
        format.js { render :edit }
        format.html { render :edit }
        format.json { render json: @marital_status_master.errors, status: :unprocessable_entity }
      end
    end
  end


  # DELETE /marital_status_masters/1 or /marital_status_masters/1.json
  def destroy
    @marital_status_master.destroy
    respond_to do |format|
      format.html { redirect_to marital_status_masters_url, notice: "Marital status master was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_marital_status_master
      @marital_status_master = MaritalStatusMaster.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def marital_status_master_params
      params.require(:marital_status_master).permit(:assigned_code, :status_desc, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
