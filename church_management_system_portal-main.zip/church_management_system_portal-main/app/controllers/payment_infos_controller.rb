class PaymentInfosController < ApplicationController
  before_action :set_payment_info, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource

  def index
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    params[:branch_code] = current_user.user_branch_code

    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.super_admin? || current_user.user_admin?
      @payment_infos = PaymentInfo.paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
      @sub_entity_contribs = SubEntityContrib.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @entity_name_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
      @contribution_search = PaymentInfo.order(contribution_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)
      @name_search = PersonInfo.where("active_status = true").select("concat_ws(' ', last_name, other_names, first_name ) as fullname, other_names, last_name, first_name, assigned_code").order('last_name desc')


    elsif current_user.branch_admin?
      @payment_infos = PaymentInfo.payment_info_join.where("sec.sub_entity_code = '#{params[:branch_code]}'").paginate(:page => params[:page], :per_page => params[:count]).order('payment_infos.created_at desc')

      @contribution_search = PaymentInfo.where("payment_infos.status is true AND sec.sub_entity_code = '#{params[:branch_code]}'").order('payment_infos.created_at desc')
      @user_search = User.unscoped.user_join.where("ur.del_status is false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(username: :desc)
      @name_search = PersonInfo.where("active_status = true ").select("concat_ws(' ', last_name, other_names, first_name ) as fullname, other_names, last_name, first_name, assigned_code").order('last_name desc')

    else

    end
  end

  def payment_infos_index
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    params[:branch_code] = current_user.user_branch_code

    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.super_admin? || current_user.user_admin?
      @entity_name_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
      @contribution_search = PaymentInfo.where(active_status: true).order(contribution_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)
      @name_search = PersonInfo.where("active_status = true").select("concat_ws(' ', last_name, other_names, first_name ) as fullname, other_names, last_name, first_name, assigned_code").order('last_name desc')

    elsif current_user.branch_admin?
      @contribution_search = PaymentInfo.where("payment_infos.status is true AND sec.sub_entity_code = '#{params[:branch_code]}'").order('payment_infos.created_at desc')
      @user_search = User.unscoped.user_join.where("ur.del_status is false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(username: :desc)
      @name_search = PersonInfo.where("active_status = true").select("concat_ws(' ', last_name, other_names, first_name ) as fullname, other_names, last_name, first_name, assigned_code").order('last_name desc')

    else

    end

    if current_user.super_admin? || current_user.user_admin?
      search_arr = ["payment_infos.id is not null"]
    elsif current_user.branch_admin?
      search_arr = ["payment_infos.id is not null AND sec.sub_entity_code = '#{params[:branch_code]}' "]
    end
    the_search = ""

    if params[:filter_main].present? || params[:person_assigned_code].present? || params[:mobile_number].present? || params[:amount].present? || params[:status].present? || params[:start_date].present? || params[:end_date].present?

      filter_params = params[:filter_main]
      if params[:filter_main].present?
        @person_assigned_code = filter_params[:person_assigned_code]
        @mobile_number = filter_params[:mobile_number]
        @amount = filter_params[:amount]
        @status = filter_params[:status]
        @start_date = filter_params[:start_date]
        @end_date = filter_params[:end_date]

        params[:person_assigned_code] = filter_params[:person_assigned_code]
        params[:mobile_number] = filter_params[:mobile_number]
        params[:amount] = filter_params[:amount]
        params[:status] = filter_params[:status]
        params[:start_date] = filter_params[:start_date]
        params[:end_date] = filter_params[:end_date]

      else

        if params[:person_assigned_code].present? || params[:mobile_number].present? || params[:amount].present? || params[:status].present? || params[:start_date].present? || params[:end_date].present?

          @person_assigned_code = params[:person_assigned_code]
          @mobile_number = params[:mobile_number]
          @amount = params[:amount]
          @status = params[:status]
          @start_date = params[:start_date]
          @end_date = params[:end_date]

          params[:person_assigned_code] = @person_assigned_code
          params[:mobile_number] = @mobile_number
          params[:amount] = @amount
          params[:status] = @status
          params[:start_date] = @start_date
          params[:end_date] = @end_date

        else
          params[:person_assigned_code] = filter_params[:person_assigned_code]
          params[:mobile_number] = filter_params[:mobile_number]
          params[:amount] = filter_params[:amount]
          params[:status] = filter_params[:status]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        end
      end

      if @person_assigned_code.present?
        #search_arr << "customer_number LIKE '%#{@cust_num}%'"
        search_arr << "person_assigned_code = '#{@person_assigned_code}'"
      end

      if @mobile_number.present?
        if @mobile_number[0..2] == '233'
          @format_mobile_number = "0#{@mobile_number[3..12]}"
          @mobile_number = @mobile_number
        else
          @format_mobile_number = "233#{formatPhoneNo(@mobile_number)}"
          @mobile_number = @mobile_number
        end
        search_arr << "mobile_number IN ('#{@format_mobile_number}','#{@mobile_number}')"
      end

      if @amount.present?
        search_arr << "amount = '#{@amount}'"
      end

      if @status.present?
        search_arr << "status = '#{@status}'"
      end

      if @start_date.present? && @end_date.present?
        f_start_date = @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
        f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
        if f_start_date <= f_end_date
          search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
        end
      end

    else
    end

    the_search = search_arr.join(" AND ")
    logger.info "The search array :: #{search_arr.inspect}"
    logger.info "The Search :: #{the_search.inspect}"

    if params[:count] == "All"
      saved_size = @payment_infos.exists? ? @payment_infos.size : 0
      @payment_infos = PaymentInfo.where(the_search).paginate(:page => 1, :per_page => saved_size).order('payment_infos.created_at desc')
    else
      @payment_infos = PaymentInfo.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('payment_infos.created_at desc')
    end

  end

  def formatPhoneNo(mobile_no)
    mobile_no_full = ""
    msisdn = mobile_no[mobile_no.to_s.length - 9..-1]
    if !msisdn.nil? then
      if msisdn.length.to_i == 9 then
        ##return "#{CNTRY_CODE}#{msisdn}"
        return msisdn
      else
        return false
      end
    else
      return false
    end
  end

  # GET /payment_infos/1 or /payment_infos/1.json
  # DETAILS MODAL
  def payment_show
    @payment_info = PaymentInfo.find(params[:pay_id])
  end

  private

  # Use callbacks to share common setup or constraints between actions.
  def set_payment_info
    @payment_info = PaymentInfo.find(params[:id])
  end

  # Only allow a list of trusted parameters through.
  def payment_info_params
    params.require(:payment_info).permit(:person_assigned_code, :product_id, :mobile_number, :amount, :status, :trans_type, :payment_mode, :reference, :created_at, :updated_at)
  end
end
