class PersonConditionTypesController < ApplicationController
  before_action :set_person_condition_type, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /person_condition_types or /person_condition_types.json
  def index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @person_condition_types = PersonConditionType.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

    @condition_search = PersonConditionType.where(active_status: true).order(condition_desc: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

  end

  def person_condition_types_index
      params[:count] ? params[:count] : params[:count] = 20
      params[:page] ? params[:page] : params[:page] = 1

      @condition_search = PersonConditionType.where(active_status: true).order(condition_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

      search_arr = ["active_status = true"]
      the_search = ""

      if params[:filter_main].present? || params[:assigned_code].present? || params[:active_status].present?|| params[:birth_date].present?|| params[:gender].present?|| params[:condition_desc].present?|| params[:first_name].present? || params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?

        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @assigned_code = filter_params[:assigned_code]
          @active_status = filter_params[:active_status]
          @condition_desc = filter_params[:condition_desc]
          @username = filter_params[:user_id]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:assigned_code] = filter_params[:assigned_code]
          params[:active_status] = filter_params[:active_status]
          params[:condition_desc] = filter_params[:condition_desc]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        else

          if  params[:assigned_code].present? || params[:active_status].present?|| params[:birth_date].present?|| params[:gender].present?|| params[:condition_desc].present?|| params[:first_name].present?|| params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

            @assigned_code = params[:assigned_code]
            @active_status = params[:active_status]
            @condition_desc = params[:condition_desc]
            @username = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:assigned_code] = @assigned_code
            params[:active_status] = @active_status
            params[:condition_desc] = @condition_desc
            params[:user_id] = @susername
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:assigned_code] = filter_params[:assigned_code]
            params[:active_status] = filter_params[:active_status]
            params[:condition_desc] = filter_params[:condition_desc]
            params[:user_id] = filter_params[:user_id]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          end
        end

        if @assigned_code.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "assigned_code = '#{@assigned_code}'"
        end
        if @active_status.present?
          search_arr << "active_status = '#{@active_status}'"
        end

        if @condition_desc.present?
          search_arr << "condition_desc = '#{@condition_desc}'"
        end

        if @username.present?
          search_arr << "user_id = '#{@username}'"
        end

        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
      end

      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"

      if params[:count] == "All"
        @person_condition_types = PersonConditionType.order('created_at desc')
        saved_size = @person_condition_types.exists? ? @person_condition_types.size : 0
        @person_condition_types = PersonConditionType.where(the_search).paginate(page: 1, per_page: saved_size).order("id desc")
      else
      @person_condition_types = PersonConditionType.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
  end
  # GET /person_condition_types/1 or /person_condition_types/1.json
  def show
  end

  # GET /person_condition_types/new
  def new
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    @job_cat_code_search = JobCat.where(active_status: true).order(job_cat_desc: :desc)

    @person_condition_type = PersonConditionType.new

  end

  # GET /person_condition_types/1/edit
  def edit
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
  end

  # POST /person_condition_types or /person_condition_types.json
  def create
    @person_condition_type = PersonConditionType.new(person_condition_type_params)

    respond_to do |format|
      if @person_condition_type.valid?
        assigned_code = PersonConditionType.gen_condition_code
        @person_condition_type.assigned_code = assigned_code

        user_id = person_condition_type_params[:user_id].present? ? person_condition_type_params[:user_id] : nil
        condition_desc = person_condition_type_params[:condition_desc].present? ? person_condition_type_params[:condition_desc] : nil
        @person_group_info = PersonConditionType.new(assigned_code: assigned_code, condition_desc:condition_desc, user_id: user_id)
        @person_group_info.save(validate: false)
     
        person_condition_types_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Person Condition Type was successfully created."
        format.js { render "/person_condition_types/person_condition_types_index" }
        format.html { redirect_to person_condition_type_path(id: @person_condition_type.id), notice: 'Person Condition Type was successfully created.' }
        format.json { render :index, status: :created, location: @person_condition_type }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @person_condition_type.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /person_condition_types/1 or /person_condition_types/1.json
  def update
    respond_to do |format|
      if @person_condition_type.update(person_condition_type_params)
        person_condition_types_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Person's Condition was updated successfully."

        format.js { render "/person_condition_types/person_condition_types_index" }
        format.html { redirect_to person_condition_types_path(id: @person_condition_type.id)}
        format.json { render :person_condition_types_index, status: :ok, location: @person_condition_type }

      else
        format.js { render :edit }
        format.html { render :edit }
        format.json { render json: @person_condition_type.errors, status: :unprocessable_entity }
      end
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_person_condition_type
      # @person_condition_type = PersonConditionType.find(params[:id])

      @person_condition_type = PersonConditionType.where(active_status: true, assigned_code: params[:id]).order(created_at: :desc).first

    end

    # Only allow a list of trusted parameters through.
    def person_condition_type_params
      params.require(:person_condition_type).permit(:assigned_code, :condition_desc, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
