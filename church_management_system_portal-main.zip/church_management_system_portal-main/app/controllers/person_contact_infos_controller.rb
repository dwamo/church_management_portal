class PersonContactInfosController < ApplicationController
  before_action :set_person_contact_info, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /person_contact_infos or /person_contact_infos.json
  def index
    @person_contact_infos = PersonContactInfo.all

  end

  def add_contact
    @region_desc_search = RegionMaster.where(del_status: false).order(region_desc: :desc)
    @city_town_name_search = CityTownMaster.where(del_status: false).order(city_town_name: :desc)

    @person_contact_info = PersonContactInfo.new

  end
  # GET /person_contact_infos/1 or /person_contact_infos/1.json
  def show
  end

  # GET /person_contact_infos/new
  def new
    @person_contact_info = PersonContactInfo.new
  end

  # GET /person_contact_infos/1/edit
  def edit
  end

  # POST /person_contact_infos or /person_contact_infos.json
  def create
    @person_contact_info = PersonContactInfo.new(person_contact_info_params)

    respond_to do |format|
      if @person_contact_info.save
        format.html { redirect_to @person_contact_info, notice: "Person contact info was successfully created." }
        format.json { render :show, status: :created, location: @person_contact_info }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @person_contact_info.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /person_contact_infos/1 or /person_contact_infos/1.json
  def update
    respond_to do |format|
      if @person_contact_info.update(person_contact_info_params)
        format.html { redirect_to @person_contact_info, notice: "Person contact info was successfully updated." }
        format.json { render :show, status: :ok, location: @person_contact_info }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @person_contact_info.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /person_contact_infos/1 or /person_contact_infos/1.json
  def destroy
    @person_contact_info.destroy
    respond_to do |format|
      format.html { redirect_to person_contact_infos_url, notice: "Person contact info was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_person_contact_info
      @person_contact_info = PersonContactInfo.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def person_contact_info_params
      params.require(:person_contact_info).permit(:person_assigned_code, :contact_number, :contact_email, :res_addr, :postal_addr, :res_region_code, :res_city_town_id, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
