class PersonContribSetupsController < ApplicationController
  before_action :set_person_contrib_setup, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /person_contrib_setups or /person_contrib_setups.json
  def index
    # @person_contrib_setups = PersonContribSetup.all
  end

  def person_contrib_setups_index
      params[:count] ? params[:count] : params[:count] = 20
      params[:page] ? params[:page] : params[:page] = 1

      @person_infos = PersonInfo.where(assigned_code: params[:main_code], del_status: false)
      @person_info = PersonInfo.where(assigned_code: params[:main_code], active_status:true).order('person_infos.created_at desc').first

      if current_user.super_admin? || current_user.user_admin?
        @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :asc)

      elsif current_user.merchant_admin?
        params[:merchant_code] = current_user.user_main_code

        @contribution_search = SubEntityContrib.where(active_status: true, sub_entity_code: params[:merchant_code]).order(contribution_name: :asc)
        @division_name_search = EntityDivision.where(entity_code: params[:merchant_code], active_status: true).order(division_name: :asc)

      elsif current_user.division_admin?
        params[:division_code] = current_user.div_code
        @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :asc)
        @sub_entity_name_search = SubEntityInfo.where(entity_division_code: params[:division_code], active_status: true).order(sub_entity_name: :asc)

      elsif current_user.branch_admin?
        @contribution_search = SubEntityContrib.where(sub_entity_code: params[:branch_code], active_status: true).order(contribution_name: :asc)
        @sub_entity_name_search = SubEntityInfo.where(assigned_code: params[:branch_code], active_status: true).order(sub_entity_name: :asc)

      else
      end

      the_search = ""
      search_arr = ["person_contrib_setups.person_assigned_code = '#{params[:main_code]}' AND person_contrib_setups.del_status = false"]

      if params[:filter_main].present? || params[:condition_type_code].present? || params[:freq].present? || params[:user_id].present?|| params[:sub_entity_contribution_id].present? || params[:activity_code].present? || params[:complete_status].present? || params[:start_date].present?|| params[:from_date].present? || params[:to_date].present?

        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @condition_type_code = filter_params[:condition_type_code]
          @freq = filter_params[:freq]
          @sub_entity_contribution_id = filter_params[:sub_entity_contribution_id]
          @user_id = filter_params[:user_id]
          @complete_status = filter_params[:complete_status]
          @start_date = filter_params[:start_date]
          @from_date = filter_params[:from_date]
          @to_date = filter_params[:to_date]

          params[:condition_type_code] = filter_params[:condition_type_code]
          params[:freq] = filter_params[:freq]
          params[:sub_entity_contribution_id] = filter_params[:sub_entity_contribution_id]
          params[:user_id] = filter_params[:user_id]
          params[:complete_status] = filter_params[:complete_status]
          params[:start_date] = filter_params[:start_date]
          params[:from_date] = filter_params[:from_date]
          params[:to_date] = filter_params[:to_date]
        else

          if  params[:condition_type_code].present?  || params[:freq].present? || params[:sub_entity_contribution_id].present? || params[:user_id].present? || params[:complete_status].present? || params[:start_date].present?|| params[:from_date].present? || params[:to_date].present? # || params[:trans_id].present? || params[:nw].present? || params[:status].present? || params[:start_date].present? || params[:to_date].present?

            @condition_type_code = params[:condition_type_code]
            @freq = params[:freq]
            @sub_entity_contribution_id = params[:sub_entity_contribution_id]
            @user_id = params[:user_id]
            @complete_status = params[:complete_status]
            @start_date = params[:start_date]
            @from_date = params[:from_date]
            @to_date = params[:to_date]

            params[:condition_type_code] = @condition_type_code
            params[:freq] = @freq
            params[:sub_entity_contribution_id] = @sub_entity_contribution_id
            params[:user_id] = @user_id
            params[:complete_status] = @complete_status
            params[:start_date] = @start_date
            params[:from_date] = @from_date
            params[:to_date] = @to_date

          else
            params[:condition_type_code] = filter_params[:condition_type_code]
            params[:freq] = filter_params[:freq]
            params[:sub_entity_contribution_id] = filter_params[:sub_entity_contribution_id]
            params[:user_id] = filter_params[:user_id]
            params[:complete_status] = filter_params[:complete_status]
            params[:start_date] = filter_params[:start_date]
            params[:from_date] = filter_params[:from_date]
            params[:to_date] = filter_params[:to_date]

          end
        end

        if @condition_type_code.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "condition_type_code = '#{@condition_type_code}'"
        end

        if @sub_entity_contribution_id.present?
          search_arr << "sub_entity_contribution_id = '#{@sub_entity_contribution_id}'"
        end

        if @freq.present?
          search_arr << "freq = '#{@freq}'"
        end

        if @user_id.present?
          search_arr << "user_id = '#{@user_id}'"
        end

        if @complete_status.present?
          #search_arr << "service_label = '#{@serv_label}'"
          search_arr << "complete_status = '#{@complete_status}'"
        end

        if @from_date.present? && @to_date.present?
          f_start_date =  @from_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @to_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
        # $service_filter = ""
        filter_params = ""
      end


      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"

      @sub_entity_contrib_search = SubEntityContrib.where(sub_entity_code: params[:branch_code], del_status: false).order(contribution_name: :asc)
      @username_search = User.unscoped.user_join.where("ur.active_status is true AND main_code = '#{params[:main_code]}'").order(username: :asc)

      if params[:count] == "All"
        saved_size = @person_contrib_setups.exists? ? @person_contrib_setups.size : 0
        @person_contrib_setups = PersonContribSetup.contrib_join.where(the_search).paginate(:page => 1, :per_page => saved_size).order('person_contrib_setups.created_at desc')
      else
        @person_contrib_setups = PersonContribSetup.contrib_join.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('person_contrib_setups.created_at desc')
      end

  end

  # GET /person_contrib_setups/1 or /person_contrib_setups/1.json
  def show
  end

  # expecting a join to the contrib_type(for entity and divisions)
  def new
    @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :asc)
    @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :asc)
    @sub_entity_name_search = SubEntityInfo.where(assigned_code: params[:branch_code], active_status: true, del_status: false).order(sub_entity_name: :asc)

    # params[:freq_status] = frequency_status

    if current_user.super_admin? || current_user.user_admin?
      @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :asc)

    elsif current_user.merchant_admin?
      @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :asc)
      # @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :asc)

    elsif current_user.division_admin?
      @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :asc)

    elsif current_user.branch_admin?
      @contribution_search = SubEntityContrib.where(sub_entity_code: params[:branch_code], active_status: true).order(contribution_name: :asc)

    else
    end


    @person_contrib_setup = PersonContribSetup.new
  end

  # GET /person_contrib_setups/1/edit
  def edit
    # params[:main_code] = current_user.user_main_code
    @sub_entity_name_search = SubEntityInfo.where(assigned_code: params[:branch_code], active_status: true, del_status: false).order(sub_entity_name: :asc)
    @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :asc)
    @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :asc)

    if current_user.super_admin? || current_user.user_admin?
      @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :asc)

    elsif current_user.merchant_admin?
      # params[:main_code] = current_user.user_main_code
      @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :asc)
      @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :asc)

    elsif current_user.division_admin?
      # params[:div_code] = current_user.div_code
      @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :asc)
      @sub_entity_name_search = SubEntityInfo.where(entity_division_code: params[:div_code], active_status: true).order(sub_entity_name: :asc)

    elsif current_user.branch_admin?
      # params[:branch_code] = current_user.user_branch_code
      @contribution_search = SubEntityContrib.where(sub_entity_code: params[:branch_code], active_status: true).order(contribution_name: :asc)
      @sub_entity_name_search = SubEntityInfo.where(assigned_code: params[:branch_code], active_status: true).order(sub_entity_name: :asc)

    else
    end
    @person_contrib_setup.start_date = @person_contrib_setup.start_date.strftime('%Y-%m-%d') if @person_contrib_setup.start_date != nil
  end

  # POST /person_contrib_setups or /person_contrib_setups.json
  def create
    @person_contrib_setup = PersonContribSetup.new(person_contrib_setup_params)
    respond_to do |format|
      if @person_contrib_setup.valid?
        @person_contrib_setup.save(validate: false)
        person_contrib_setups_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Contribution was successfully created."
        format.js { render "/person_contrib_setups/person_contrib_setups_index" }
        format.html { redirect_to person_contrib_setups_path(id: @person_contrib_setup.id), notice: 'Contribution was successfully created.' }
        format.json { render :index, status: :created, location: @person_contrib_setup }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @person_contrib_setup.errors, status: :unprocessable_entity }
        @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :asc)


        if current_user.super_admin? || current_user.user_admin?
          @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :asc)

        elsif current_user.merchant_admin?
          @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :asc)

        elsif current_user.division_admin?
          @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :asc)

        elsif current_user.branch_admin?
          @contribution_search = SubEntityContrib.where(sub_entity_code: params[:branch_code], active_status: true).order(contribution_name: :asc)

        else
        end
      end
    end
  end

  # PATCH/PUT /person_contrib_setups/1 or /person_contrib_setups/1.json
  def update
    respond_to do |format|
      @person_contrib_setup = PersonContribSetup.where(active_status: true, id: params[:id]).order(created_at: :desc).first
      flash.now[:notice] = "Contribution was updated successfully."

      logger.info params[:person_contrib_setup].inspect
      @new_record = PersonContribSetup.new(person_contrib_setup_params)

      @new_record.person_assigned_code = @person_contrib_setup.person_assigned_code
      if @new_record.valid?
        @person_contrib_setup.active_status = false
        @person_contrib_setup.del_status = true
        @person_contrib_setup.save(validate: false)
        if @new_record.save
        else
          # PersonContribSetup.update_last_but_one("person_contrib_setups", @person_contrib_setup.person_assigned_code , prev_updated_at)
        end
        person_contrib_setups_index
        format.js { render "/person_contrib_setups/person_contrib_setups_index" }
        format.html { redirect_to person_contrib_setups_path, notice: 'Contribution was updated successfully.' }
        format.json { render :person_contrib_setup_index, status: :ok, location: @person_contrib_setup }
      else
        logger.info "Division Error Messages Edit :: #{@new_record.errors.messages.inspect}"

        format.html {render :edit}
        format.js { render :edit }
        format.json { render json: @person_contrib_setup.errors, status: :unprocessable_entity }

        @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :asc)
      end
    end
  end

  def contrib_update
    logger.info "Params:: #{params[:id_for_branch].inspect}"
    if params[:id_for_branch].empty?
      @church_update_contrib = [["", ""]].insert(0, ['Please select a Contribution', ""])
    else
      church_update_contrib = SubEntityContrib.where(sub_entity_code: params[:id_for_branch], active_status: true).order(contribution_name: :asc).map { |a| [a.contribution_name, a.id] }.insert(0, ['Please select a Contribution', ""])
      @church_update_contrib = church_update_contrib.empty? ? [["", ""]].insert(0, ['Please select a Contribution', ""]) : church_update_contrib
    end
    logger.info "For Sub Entity Info :: #{@church_update_contrib.inspect}"
  end

  # Contrib_status cascading
  def contrib_has_frequency
    logger.info "Params:: #{params[:id_for_sub_contrib].inspect}"
    if params[:id_for_sub_contrib].empty?
      @contrib_has_frequency = false
    else
      sub_entity_contrib = SubEntityContrib.where(del_status: false, id: params[:id_for_sub_contrib]).order(contribution_name: :asc).first

      contrib_has_frequency = ContribType.where(assigned_code: sub_entity_contrib.contribution_type_code, active_status: true).order(frequency: :asc).map { |a| a.frequency}

      @contrib_has_frequency = contrib_has_frequency.empty? ? false : contrib_has_frequency
      # @contrib_has_frequency = contrib_has_frequency.frequency
    end
    logger.info "For Contrib Type Frequency :: #{@contrib_has_frequency.inspect}"
  end
                                                                                                                                                                                                                                                                                private
    # Use callbacks to share common setup or constraints between actions.
    def set_person_contrib_setup
      @person_contrib_setup = PersonContribSetup.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def person_contrib_setup_params
      params.require(:person_contrib_setup).permit(:sub_entity_code, :person_assigned_code, :sub_entity_contribution_id, :freq, :start_date, :complete_status, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at, :entity_info_code, :entity_division_code)
    end
end
