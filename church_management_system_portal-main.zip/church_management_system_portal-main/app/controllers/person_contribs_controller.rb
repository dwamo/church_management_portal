class PersonContribsController < ApplicationController
  before_action :set_person_contrib, only: %i[ show edit update destroy ]

  # GET /person_contribs or /person_contribs.json
  def index
    @person_contribs = PersonContrib.all
  end

  # GET /person_contribs/1 or /person_contribs/1.json
  def show
  end

  # GET /person_contribs/new
  def new
    @person_contrib = PersonContrib.new
  end

  # GET /person_contribs/1/edit
  def edit
  end

  # POST /person_contribs or /person_contribs.json
  def create
    @person_contrib = PersonContrib.new(person_contrib_params)

    respond_to do |format|
      if @person_contrib.save
        format.html { redirect_to @person_contrib, notice: "Person contrib was successfully created." }
        format.json { render :show, status: :created, location: @person_contrib }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @person_contrib.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /person_contribs/1 or /person_contribs/1.json
  def update
    respond_to do |format|
      if @person_contrib.update(person_contrib_params)
        format.html { redirect_to @person_contrib, notice: "Person contrib was successfully updated." }
        format.json { render :show, status: :ok, location: @person_contrib }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @person_contrib.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /person_contribs/1 or /person_contribs/1.json
  def destroy
    @person_contrib.destroy
    respond_to do |format|
      format.html { redirect_to person_contribs_url, notice: "Person contrib was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_person_contrib
      @person_contrib = PersonContrib.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def person_contrib_params
      params.require(:person_contrib).permit(:person_assigned_code, :amount, :src, :person_contrib_setup_id, :sub_entity_contrib_id, :created_at, :updated_at)
    end
end
