class PersonDisabilityInfosController < ApplicationController
  before_action :set_person_disability_info, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /person_disability_infos or /person_disability_infos.json
  def index
    @person_disability_infos = PersonDisabilityInfo.all
  end

  # GET /person_disability_infos/1 or /person_disability_infos/1.json
  def show
  end

  # GET /person_disability_infos/new
  def new
    @job_cat_code_search = JobCat.where(active_status: true).order(job_cat_desc: :desc)
    @person_disability_info = PersonDisabilityInfo.new

  end

  # GET /person_disability_infos/1/edit
  def edit
    @job_cat_code_search = JobCat.where(active_status: true).order(job_cat_desc: :desc)

  end

  # POST /person_disability_infos or /person_disability_infos.json
  def create1
    @person_disability_info = PersonDisabilityInfo.new(person_disability_info_params)

    respond_to do |format|
      if @person_disability_info.save
        format.html { redirect_to @person_disability_info, notice: "Disability was successfully created." }
        format.json { render :show, status: :created, location: @person_disability_info }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @person_disability_info.errors, status: :unprocessable_entity }
      end
    end
  end

  def create
    @person_disability_info = PersonDisabilityInfo.new(person_disability_info_params)

    respond_to do |format|
      if @person_disability_info.valid?
        person_assigned_code = PersonDisabilityInfo.gen_contrib_code
        @person_disability_info.person_assigned_code = person_assigned_code
        @person_disability_info.save
        person_disability_infos_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Disability was successfully created."

        format.js { render "/person_disability_infos/person_disability_infos_index" }
        format.html { redirect_to entity_info_path(id: @person_disability_info.id), notice: 'Disability was successfully created.' }
        format.json { render :index, status: :created, location: @person_disability_info }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @person_disability_info.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      @person_disability_info = PersonDisabilityInfo.where(active_status: true, person_assigned_code: params[:id]).order(created_at: :desc).first
      flash.now[:notice] = "Disability updated successfully."
      prev_updated_at = @person_disability_info.updated_at

      logger.info params[:person_disability_info].inspect
      @new_record = PersonDisabilityInfo.new(person_disability_info_params)

      if @new_record.valid?
        @person_disability_info.active_status = false
        @person_disability_info.del_status = true
        @person_disability_info.save(validate: false)
        if @new_record.save
        else
          PersonDisabilityInfo.update_last_but_one("person_disability_infos", @person_disability_info.person_assigned_code , prev_updated_at)
        end
        index
        format.js { render "/person_disability_infos/person_disability_infos_index" }
        format.html { redirect_to person_disability_infos_path, notice: 'Disability updated successfully.' }
        format.json { render :person_disability_infos_index, status: :ok, location: @person_disability_info }
      else
        logger.info "Person Error Messages Edit :: #{@new_record.errors.messages.inspect}"

        format.html {render :edit}
        format.js { render :edit }
        format.json { render json: @person_disability_info.errors, status: :unprocessable_entity }
      end
    end
  end
  # DELETE /person_disability_infos/1 or /person_disability_infos/1.json
  def destroy
    @person_disability_info.destroy
    respond_to do |format|
      format.html { redirect_to person_disability_infos_url, notice: "Person disability info was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_person_disability_info
      @person_disability_info = PersonDisabilityInfo.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def person_disability_info_params
      params.require(:person_disability_info).permit(:person_person_assigned_code, :disability_id, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
