class PersonEmpInfosController < ApplicationController
  before_action :set_person_emp_info, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /person_emp_infos or /person_emp_infos.json
  def index
    @person_emp_infos = PersonEmpInfo.all
  end

  def person_emp_infos_index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @job_cat_desc_search = PersonEmpInfo.where(active_status: true).order(job_cat_desc: :asc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

    if params[:count] == "All"
      @person_emp_infos = PersonEmpInfo.where(active_status: true).order('created_at desc')
      saved_size = @person_emp_infos.exists? ? @person_emp_infos.size : 0
      @person_emp_infos = PersonEmpInfo.where(active_status: true).paginate(page: 1, per_page: saved_size).order("id desc")
    else

      the_search = ""
      search_arr = ["del_status = false"]

      if params[:filter_main].present? || params[:job_cat_desc].present? || params[:entity_alias].present? || params[:active_status].present? || params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?

        $merchant_filter = params[:filter_main]
        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @job_cat_desc_search = filter_params[:job_cat_desc]
          @entity_alias = filter_params[:entity_alias]
          @active_status = filter_params[:active_status]
          @username = filter_params[:user_id]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:job_cat_desc] = filter_params[:job_cat_desc]
          params[:entity_alias] = filter_params[:entity_alias]
          params[:active_status] = filter_params[:active_status]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        else

          if  params[:job_cat_desc].present? || params[:entity_alias].present? || params[:active_status].present?|| params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

            @job_cat_desc_search = params[:job_cat_desc]
            @active_status = params[:active_status]
            @username = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:job_cat_desc] = @job_cat_desc_search
            params[:active_status] = @active_status
            params[:user_id] = @username
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:job_cat_desc] = filter_params[:job_cat_desc]
            params[:active_status] = filter_params[:active_status]
            params[:user_id] = filter_params[:user_id]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          end
        end

        if @job_cat_desc_search.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "job_cat_desc = '#{@job_cat_desc_search}'"
        end
        if @active_status.present?
          search_arr << "active_status = '#{@active_status}'"
        end
        if @username.present?
          search_arr << "user_id = '#{@username}'"
        end

        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
      end


      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"


      @person_emp_infos = PersonEmpInfo.where(del_status: false).where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
  end

  # GET /person_emp_infos/1 or /person_emp_infos/1.json
  def show
  end

  # GET /person_emp_infos/new
  def new
    @person_emp_info = PersonEmpInfo.new
  end

  # GET /person_emp_infos/1/edit
  def edit
  end

  # POST /person_emp_infos or /person_emp_infos.json
  def create
    @person_emp_info = PersonEmpInfo.new(person_emp_info_params)

    respond_to do |format|
      if @person_emp_info.save
        format.html { redirect_to @person_emp_info, notice: "Person emp info was successfully created." }
        format.json { render :show, status: :created, location: @person_emp_info }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @person_emp_info.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /person_emp_infos/1 or /person_emp_infos/1.json
  def update
    respond_to do |format|
      if @person_emp_info.update(person_emp_info_params)
        format.html { redirect_to @person_emp_info, notice: "Person emp info was successfully updated." }
        format.json { render :show, status: :ok, location: @person_emp_info }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @person_emp_info.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /person_emp_infos/1 or /person_emp_infos/1.json
  def destroy
    @person_emp_info.destroy
    respond_to do |format|
      format.html { redirect_to person_emp_infos_url, notice: "Person emp info was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_person_emp_info
      @person_emp_info = PersonEmpInfo.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def person_emp_info_params
      params.require(:person_emp_info).permit(:person_assigned_code, :job_type_code, :job_title, :location_addr, :postal_addr, :emp_loc_addr, :emp_postal_addr, :emp_loc_region_code, :emp_loc_city_town_id, :contact_number, :contact_email, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
