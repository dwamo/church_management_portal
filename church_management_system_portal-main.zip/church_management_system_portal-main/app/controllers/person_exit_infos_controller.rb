class PersonExitInfosController < ApplicationController
  before_action :set_person_exit_info, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource

  # GET /person_exit_infos/new
  def index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.super_admin? || current_user.user_admin?
      @person_exit_infos = PersonExitInfo.all.paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @entity_name_search = EntityInfo.where(del_status: false).order(entity_name: :desc)
      @sub_entity_name_search = SubEntityInfo.where(del_status: false).order(sub_entity_name: :asc)
      @name_search = PersonInfo.where("del_status = false").select("concat_ws(' ', last_name, other_names, first_name ) as fullname, other_names, last_name, first_name, assigned_code").order('last_name desc')
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :asc)
      @exit_desc_search = PersonExitLov.where(del_status: false).order(exit_desc: :asc)

    else
      params[:main_code] = current_user.user_main_code
      @person_exit_infos = PersonExitInfo.where(entity_code: params[:main_code]).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @sub_entity_name_search = SubEntityInfo.where(entity_code: params[:main_code], del_status: false).order(sub_entity_name: :asc)
      @name_search = PersonInfo.where("del_status = false AND entity_info_code = '#{params[:main_code]}'").select("concat_ws(' ', last_name, other_names, first_name ) as fullname, other_names, last_name, first_name, assigned_code").order('last_name desc')
      @user_search = User.unscoped.user_join.where("ur.active_status = true AND ur.main_code = '#{params[:main_code]}'").order(username: :asc)
      @exit_desc_search = PersonExitLov.where(entity_code: params[:main_code], del_status: false).order(exit_desc: :asc)
    end
  end

  def person_exit_infos_index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @person_exit_info_search = PersonExitLov.where(del_status: false).order(exit_desc: :asc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :asc)

    if current_user.super_admin? || current_user.user_admin?
      @exit_desc_search = PersonExitLov.where(del_status: false).order(exit_desc: :asc)
      @entity_name_search = EntityInfo.where(del_status: false).order(entity_name: :asc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :asc)
      the_search = ""
      search_arr = [""]
    else
      params[:main_code] = current_user.user_main_code
      @user_search = User.unscoped.user_join.where("ur.active_status = true AND ur.main_code = '#{params[:main_code]}'").order(username: :asc)
      @exit_desc_search = PersonExitLov.where(entity_code: params[:main_code], active_status: true).order(exit_desc: :asc)

      search_arr = ["entity_code = '#{params[:main_code]}'"]
    end
    if params[:filter_main].present? || params[:exit_lov_id].present? || params[:entity_code].present? || params[:sub_entity_code].present? || params[:person_assigned_code].present? || params[:active_status].present? || params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

      filter_params = params[:filter_main]
      if params[:filter_main].present?
        @exit_lov_id = filter_params[:exit_lov_id]
        @entity_code = filter_params[:entity_code]
        @sub_entity_code = filter_params[:sub_entity_code]
        @person_assigned_code = filter_params[:person_assigned_code]
        @active_status = filter_params[:active_status]
        @username = filter_params[:user_id]
        @start_date = filter_params[:start_date]
        @end_date = filter_params[:end_date]

        params[:exit_lov_id] = filter_params[:exit_lov_id]
        params[:entity_code] = filter_params[:entity_code]
        params[:sub_entity_code] = filter_params[:sub_entity_code]
        params[:person_assigned_code] = filter_params[:person_assigned_code]
        params[:active_status] = filter_params[:active_status]
        params[:user_id] = filter_params[:user_id]
        params[:start_date] = filter_params[:start_date]
        params[:end_date] = filter_params[:end_date]

      else

        if params[:exit_lov_id].present? || params[:entity_code].present? || params[:sub_entity_code].present? || params[:active_status].present? || params[:person_assigned_code].present? || params[:user_id].present? || params[:start_date].present? || params[:end_date].present?
          @exit_lov_id = params[:exit_lov_id]
          @entity_code = params[:entity_code]
          @sub_entity_code = params[:sub_entity_code]
          @person_assigned_code = params[:person_assigned_code]
          @username = params[:user_id]
          @start_date = params[:start_date]
          @end_date = params[:end_date]

          params[:exit_lov_id] = @exit_lov_id
          params[:entity_code] = @entity_code
          params[:sub_entity_code] = @sub_entity_code
          params[:person_assigned_code] = @person_assigned_code
          params[:active_status] = @active_status
          params[:user_id] = @username
          params[:start_date] = @start_date
          params[:end_date] = @end_date

        else
          params[:exit_lov_id] = filter_params[:exit_lov_id]
          params[:entity_code] = filter_params[:entity_code]
          params[:sub_entity_code] = filter_params[:sub_entity_code]
          params[:person_assigned_code] = filter_params[:person_assigned_code]
          params[:active_status] = filter_params[:active_status]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        end
      end

      if @exit_lov_id.present?
        #search_arr << "customer_number LIKE '%#{@cust_num}%'"
        search_arr << "exit_lov_id = '#{@exit_lov_id}'"
      end
      if @entity_code.present?
        search_arr << "entity_code = '#{@entity_code}'"
      end
      if @sub_entity_code.present?
        search_arr << "sub_entity_code = '#{@sub_entity_code}'"
      end
      if @person_assigned_code.present?
        search_arr << "person_assigned_code = '#{@person_assigned_code}'"
      end
      if @active_status.present?
        search_arr << "active_status = '#{@active_status}'"
      end
      if @username.present?
        search_arr << "user_id = '#{@username}'"
      end
      if @start_date.present? && @end_date.present?
        f_start_date = @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
        f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
        if f_start_date <= f_end_date
          search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
        end
      end
    else
    end

    if current_user.super_admin? || current_user.user_admin?
      the_search = search_arr.join("")
    else
      the_search = search_arr.join(" AND ")
    end
    logger.info "The search array :: #{search_arr.inspect}"
    logger.info "The Search :: #{the_search.inspect}"

    if params[:count] == "All"
      @person_exit_infos = PersonExitInfo.order('created_at desc')
      saved_size = @person_exit_infos.exists? ? @person_exit_infos.size : 0
      @person_exit_infos = PersonExitInfo.where(the_search).paginate(page: 1, per_page: saved_size).order("created_at desc")
    else
      @person_exit_infos = PersonExitInfo.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
  end

  # GET /person_exit_infos/1/edit
  def edit
  end

  # POST /person_exit_infos or /person_exit_infos.json
  def create
    @person_exit_info = PersonExitInfo.new(person_exit_info_params)

    respond_to do |format|
      if @person_exit_info.save
        format.html { redirect_to person_exit_info_url(@person_exit_info), notice: "Person exit info was successfully created." }
        format.json { render :show, status: :created, location: @person_exit_info }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @person_exit_info.errors, status: :unprocessable_entity }
      end
    end
  end

  private

  # Use callbacks to share common setup or constraints between actions.
  def set_person_exit_info
    @person_exit_info = PersonExitInfo.find(params[:id])
  end

  # Only allow a list of trusted parameters through.
  def person_exit_info_params
    params.require(:person_exit_info).permit(:entity_code, :sub_entity_code, :person_assigned_code, :exit_lov_id, :integer, :cause, :comment, :active_status, :del_status)
  end
end
