class PersonExitLovsController < ApplicationController
  before_action :set_person_exit_lov, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  # GET /person_exit_lovs or /person_exit_lovs.json
  def index
      params[:count] ? params[:count] : params[:count] = 20
      params[:page] ? params[:page] : params[:page] = 1

    if current_user.super_admin? || current_user.user_admin?
      @person_exit_lovs = PersonExitLov.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @exit_desc_search = PersonExitLov.where(active_status: true).order(exit_desc: :desc)
      @entity_name_search = EntityInfo.where(del_status: false).order(entity_name: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

    elsif current_user.merchant_admin?
      params[:main_code] = current_user.user_main_code
      @person_exit_lovs = PersonExitLov.where(del_status: false, entity_code: params[:main_code]).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @user_search = User.unscoped.user_join.where("ur.active_status = true AND ur.main_code = '#{params[:main_code]}'").order(username: :desc)
      @exit_desc_search = PersonExitLov.where(entity_code: params[:main_code], active_status: true).order(exit_desc: :desc)

    end
  end

  def person_exit_lovs_index
      params[:count] ? params[:count] : params[:count] = 20
      params[:page] ? params[:page] : params[:page] = 1

      @person_exit_lov_search = PersonExitLov.where(active_status: true).order(exit_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

    if current_user.super_admin? || current_user.user_admin?
      @exit_desc_search = PersonExitLov.where(active_status: true).order(exit_desc: :desc)
      @entity_name_search = EntityInfo.where(del_status: false).order(entity_name: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)
      the_search = ""
      search_arr = ["del_status = false"]
    elsif current_user.merchant_admin?
      params[:main_code] = current_user.user_main_code
      @user_search = User.unscoped.user_join.where("ur.active_status = true AND ur.main_code = '#{params[:main_code]}'").order(username: :desc)
      @exit_desc_search = PersonExitLov.where(entity_code: params[:main_code], active_status: true).order(exit_desc: :desc)

      search_arr = ["del_status = false AND entity_code = '#{params[:main_code]}'"]
    end
    if params[:filter_main].present? || params[:exit_desc].present? || params[:entity_alias].present? || params[:active_status].present? || params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

      filter_params = params[:filter_main]
      if params[:filter_main].present?
        @exit_desc = filter_params[:exit_desc]
        @entity_alias = filter_params[:entity_alias]
        @active_status = filter_params[:active_status]
        @username = filter_params[:user_id]
        @start_date = filter_params[:start_date]
        @end_date = filter_params[:end_date]

        params[:exit_desc] = filter_params[:exit_desc]
        params[:entity_alias] = filter_params[:entity_alias]
        params[:active_status] = filter_params[:active_status]
        params[:user_id] = filter_params[:user_id]
        params[:start_date] = filter_params[:start_date]
        params[:end_date] = filter_params[:end_date]

      else

        if params[:exit_desc].present? || params[:entity_alias].present? || params[:active_status].present? || params[:user_id].present? || params[:start_date].present? || params[:end_date].present?
          @exit_desc = params[:exit_desc]
          @active_status = params[:active_status]
          @username = params[:user_id]
          @start_date = params[:start_date]
          @end_date = params[:end_date]

          params[:exit_desc] = @exit_desc
          params[:active_status] = @active_status
          params[:user_id] = @username
          params[:start_date] = @start_date
          params[:end_date] = @end_date

        else
          params[:exit_desc] = filter_params[:exit_desc]
          params[:active_status] = filter_params[:active_status]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        end
      end

      if @exit_desc.present?
        #search_arr << "customer_number LIKE '%#{@cust_num}%'"
        search_arr << "exit_desc = '#{@exit_desc}'"
      end
      if @active_status.present?
        search_arr << "active_status = '#{@active_status}'"
      end
      if @username.present?
        search_arr << "user_id = '#{@username}'"
      end

      if @start_date.present? && @end_date.present?
        f_start_date = @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
        f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
        if f_start_date <= f_end_date
          search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
        end
      end

    else
    end

    the_search = search_arr.join(" AND ")
    logger.info "The search array :: #{search_arr.inspect}"
    logger.info "The Search :: #{the_search.inspect}"

    if params[:count] == "All"
      @person_exit_lovs = PersonExitLov.order('created_at desc')
      saved_size = @person_exit_lovs.exists? ? @person_exit_lovs.size : 0
      @person_exit_lovs = PersonExitLov.where(the_search).paginate(page: 1, per_page: saved_size).order("created_at desc")
    else
      @person_exit_lovs = PersonExitLov.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
  end

  # GET /person_exit_lovs/new
  def new
    params[:main_code] = current_user.user_main_code
    @entity_info_search = EntityInfo.where(active_status: true, del_status: false).order(entity_name: :desc)
    @person_exit_lov = PersonExitLov.new
  end

  # GET /person_exit_lovs/1/edit
  def edit
    params[:main_code] = current_user.user_main_code
    @entity_info_search = EntityInfo.where(active_status: true, del_status: false).order(entity_name: :desc)
  end

  # POST /person_exit_lovs or /person_exit_lovs.json
  def create
    @person_exit_lov = PersonExitLov.new(person_exit_lov_params)

    respond_to do |format|
      if @person_exit_lov.valid?
        @person_exit_lov.save
        person_exit_lovs_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Reason was successfully created."

        format.js { render "/person_exit_lovs/person_exit_lovs_index" }
        format.html { redirect_to person_exit_lov_path(id: @person_exit_lov.id), notice: 'Job cat was successfully created.' }
        format.json { render :index, status: :created, location: @person_exit_lov }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @person_exit_lov.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      if @person_exit_lov.update(person_exit_lov_params)
        person_exit_lovs_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Reason was successfully updated."

        format.js { render "/person_exit_lovs/person_exit_lovs_index" }
        format.html { redirect_to person_exit_lovs_path(id: @person_exit_lov.id) }
        format.json { render :person_exit_lovs_index, status: :ok, location: @person_exit_lov }

      else
        format.js { render :edit }
        format.html { render :edit }
        format.json { render json: @person_exit_lov.errors, status: :unprocessable_entity }
      end
    end
  end

  private

  # Use callbacks to share common setup or constraints between actions.
  def set_person_exit_lov
    @person_exit_lov = PersonExitLov.find(params[:id])
  end

  # Only allow a list of trusted parameters through.
  def person_exit_lov_params
    params.require(:person_exit_lov).permit(:entity_code, :exit_desc, :comment, :active_status, :del_status, :user_id, :created_at)
  end
end
