class PersonGroupInfosController < ApplicationController
  before_action :set_person_group_info, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /person_group_infos or /person_group_infos.json
  def index
    @person_group_infos = PersonGroupInfo.all
  end

  # GET /person_group_infos/1 or /person_group_infos/1.json
  def show
  end

  # GET /person_group_infos/new
  def new
    @person_group_info = PersonGroupInfo.new
  end

  # GET /person_group_infos/1/edit
  def edit
  end

  # POST /person_group_infos or /person_group_infos.json
  def create
    @person_group_info = PersonGroupInfo.new(person_group_info_params)

    respond_to do |format|
      if @person_group_info.save
        format.html { redirect_to @person_group_info, notice: "Person group info was successfully created." }
        format.json { render :show, status: :created, location: @person_group_info }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @person_group_info.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /person_group_infos/1 or /person_group_infos/1.json
  def update
    respond_to do |format|
      if @person_group_info.update(person_group_info_params)
        format.html { redirect_to @person_group_info, notice: "Person group info was successfully updated." }
        format.json { render :show, status: :ok, location: @person_group_info }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @person_group_info.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /person_group_infos/1 or /person_group_infos/1.json
  def destroy
    @person_group_info.destroy
    respond_to do |format|
      format.html { redirect_to person_group_infos_url, notice: "Person group info was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_person_group_info
      @person_group_info = PersonGroupInfo.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def person_group_info_params
      params.require(:person_group_info).permit(:person_assigned_code, :sub_entity_code, :group_code, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
