class PersonImagesController < ApplicationController
  before_action :set_person_image, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /person_images or /person_images.json
  def index
    @person_images = PersonImage.all
  end

  # GET /person_images/1 or /person_images/1.json
  def show
  end

  # GET /person_images/new
  def new
    @person_image = PersonImage.new
  end

  # GET /person_images/1/edit
  def edit
  end

  # POST /person_images or /person_images.json
  def create
    @person_image = PersonImage.new(person_image_params)

    respond_to do |format|
      if @person_image.save
        format.html { redirect_to @person_image, notice: "Person image was successfully created." }
        format.json { render :show, status: :created, location: @person_image }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @person_image.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /person_images/1 or /person_images/1.json
  def update
    respond_to do |format|
      if @person_image.update(person_image_params)
        format.html { redirect_to @person_image, notice: "Person image was successfully updated." }
        format.json { render :show, status: :ok, location: @person_image }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @person_image.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /person_images/1 or /person_images/1.json
  def destroy
    @person_image.destroy
    respond_to do |format|
      format.html { redirect_to person_images_url, notice: "Person image was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_person_image
      @person_image = PersonImage.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def person_image_params
      params.require(:person_image).permit(:person_assigned_code, :image_path, :image_data, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
