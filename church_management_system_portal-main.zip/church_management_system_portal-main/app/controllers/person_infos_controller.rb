class PersonInfosController < ApplicationController
  require 'sms_endpoint'
  require 'church_core'
  include SmsEndPoint
  before_action :set_person_info, only: [:show, :edit, :update]
  before_action :load_permissions
  load_and_authorize_resource

  def index
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    params[:branch_code] = current_user.user_branch_code

    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @region_desc_search = RegionMaster.where(del_status: false).order(region_desc: :asc)
    @city_town_name_search = CityTownMaster.where(del_status: false).order(city_town_name: :asc)

    if current_user.super_admin? || current_user.user_admin?
      @person_infos = PersonInfo.persons_join.where("person_infos.del_status = false").paginate(:page => params[:page], :per_page => params[:count]).order('person_infos.created_at desc')
      @last_name_search = PersonInfo.persons_join.where("person_infos.del_status = false").order('person_infos.last_name asc')
      @first_name_search = PersonInfo.persons_join.where("person_infos.del_status = false").order('person_infos.first_name asc')
      @entity_info_search = EntityInfo.where("del_status = false").order('entity_name asc')
      @division_name_search = EntityDivision.where(del_status: false).order(division_name: :desc)
      @sub_division_desc_search = EntitySubDivision.where(del_status: false).order(sub_division_desc: :asc)
      @branch_search = SubEntityInfo.where("del_status = false").order('sub_entity_name asc')
      @user_search = User.unscoped.user_join.where("ur.del_status = false ").order(username: :asc)

    elsif current_user.merchant_admin?
      @person_infos = PersonInfo.persons_join.where("person_infos.del_status = false AND person_infos.entity_info_code = '#{params[:main_code]}'").paginate(:page => params[:page], :per_page => params[:count]).order('person_infos.created_at desc')
      @last_name_search = PersonInfo.persons_join.where("person_infos.del_status = false AND person_infos.entity_info_code = '#{params[:main_code]}'").order('person_infos.last_name asc')
      @first_name_search = PersonInfo.persons_join.where("person_infos.del_status = false AND person_infos.entity_info_code = '#{params[:main_code]}'").order('person_infos.first_name asc')
      @user_search = User.unscoped.user_join.where("ur.del_status = false AND ur.main_code = '#{params[:main_code]}'").order(username: :asc)
      @division_name_search = EntityDivision.where(entity_code: params[:main_code], del_status: false).order(division_name: :desc)
      # @sub_division_desc_search = EntitySubDivision.where(entity_division_code: params[:div_code], del_status: false).order(sub_division_desc: :asc)
      @branch_search = SubEntityInfo.where("del_status = false AND entity_code = '#{params[:main_code]}'").order('sub_entity_name asc')

    elsif current_user.division_admin?
      @person_infos = PersonInfo.persons_join.where("person_infos.del_status = false AND person_infos.entity_info_code = '#{params[:main_code]}'").paginate(:page => params[:page], :per_page => params[:count]).order('person_infos.created_at desc')
      @last_name_search = PersonInfo.persons_join.where("person_infos.del_status = false AND person_infos.entity_info_code = '#{params[:main_code]}'").order('person_infos.last_name asc')
      @first_name_search = PersonInfo.persons_join.where("person_infos.del_status = false AND person_infos.entity_info_code = '#{params[:main_code]}'").order('person_infos.first_name asc')
      @user_search = User.unscoped.user_join.where("ur.del_status = false AND ur.div_code = '#{params[:div_code]}'").order(username: :asc)
      @branch_search = SubEntityInfo.where("del_status = false AND entity_division_code = '#{params[:div_code]}'").order('sub_entity_name asc')

    elsif current_user.branch_admin?
      @person_infos = PersonInfo.persons_join.where("person_infos.del_status = false AND pse.sub_entity_code = '#{params[:branch_code]}'").paginate(:page => params[:page], :per_page => params[:count]).order('person_infos.created_at desc')
      @last_name_search = PersonInfo.persons_join.where("person_infos.del_status = false AND pse.sub_entity_code = '#{params[:branch_code]}'").order('person_infos.last_name asc')
      @first_name_search = PersonInfo.persons_join.where("person_infos.del_status = false AND pse.sub_entity_code = '#{params[:branch_code]}'").order('person_infos.first_name asc')
      @user_search = User.unscoped.user_join.where("ur.del_status = false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(username: :asc)
      @branch_search = SubEntityInfo.where("del_status = false AND assigned_code = '#{params[:branch_code]}'").order('sub_entity_name asc')

    else
    end
  end

  def person_infos_index
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    params[:branch_code] = current_user.user_branch_code

    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.super_admin? || current_user.user_admin?
      @last_name_search = PersonInfo.persons_join.where("person_infos.del_status = false").order('person_infos.last_name asc')
      @first_name_search = PersonInfo.persons_join.where("person_infos.del_status = false").order('person_infos.first_name asc')
      @entity_info_search = EntityInfo.where("del_status = false").order('entity_name asc')
      @division_name_search = EntityDivision.where(del_status: false).order(division_name: :desc)
      @sub_division_desc_search = EntitySubDivision.where(del_status: false).order(sub_division_desc: :asc)
      @branch_search = SubEntityInfo.where("del_status = false").order('sub_entity_name asc')
      @user_search = User.unscoped.user_join.where("ur.del_status = false ").order(username: :asc)

      the_search = ""
      search_arr = ["person_infos.del_status = false"]
    elsif current_user.merchant_admin?
      @last_name_search = PersonInfo.persons_join.where("person_infos.del_status = false AND person_infos.entity_info_code = '#{params[:main_code]}'").order('person_infos.last_name asc')
      @first_name_search = PersonInfo.persons_join.where("person_infos.del_status = false AND person_infos.entity_info_code = '#{params[:main_code]}'").order('person_infos.first_name asc')
      @user_search = User.unscoped.user_join.where("ur.del_status = false AND ur.main_code = '#{params[:main_code]}'").order(username: :asc)
      @division_name_search = EntityDivision.where(entity_code: params[:main_code], del_status: false).order(division_name: :desc)
      # @sub_division_desc_search = EntitySubDivision.where(entity_division_code: params[:div_code], del_status: false).order(sub_division_desc: :asc)
      @branch_search = SubEntityInfo.where("del_status = false AND entity_code = '#{params[:main_code]}'").order('sub_entity_name asc')

      the_search = ""
      search_arr = ["person_infos.entity_info_code = '#{params[:main_code]}' AND person_infos.del_status = false"]
    elsif current_user.division_admin?
      @last_name_search = PersonInfo.persons_join.where("person_infos.del_status = false AND person_infos.entity_info_code = '#{params[:main_code]}'").order('person_infos.last_name asc')
      @first_name_search = PersonInfo.persons_join.where("person_infos.del_status = false AND person_infos.entity_info_code = '#{params[:main_code]}'").order('person_infos.first_name asc')
      @user_search = User.unscoped.user_join.where("ur.del_status = false AND ur.div_code = '#{params[:div_code]}'").order(username: :asc)
      @branch_search = SubEntityInfo.where("del_status = false AND entity_division_code = '#{params[:div_code]}'").order('sub_entity_name asc')

      the_search = ""
      search_arr = ["person_infos.entity_info_code = '#{params[:main_code]}' AND person_infos.del_status = false"]
    elsif current_user.branch_admin?
      @last_name_search = PersonInfo.persons_join.where("person_infos.del_status = false AND pse.sub_entity_code = '#{params[:branch_code]}'").order('person_infos.last_name asc')
      @first_name_search = PersonInfo.persons_join.where("person_infos.del_status = false AND pse.sub_entity_code = '#{params[:branch_code]}'").order('person_infos.first_name asc')
      @user_search = User.unscoped.user_join.where("ur.del_status = false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(username: :asc)
      @branch_search = SubEntityInfo.where("del_status = false AND assigned_code = '#{params[:branch_code]}'").order('sub_entity_name asc')

      the_search = ""
      search_arr = ["pse.sub_entity_code = '#{params[:branch_code]}' AND person_infos.del_status = false"]
    else
    end

    if params[:filter_main].present? || params[:assigned_code].present? || params[:entity_info_code].present?|| params[:entity_sub_div_code].present? || params[:active_status].present? || params[:birth_date].present? || params[:gender].present? || params[:last_name].present? || params[:first_name].present? || params[:user_id].present? || params[:entity_division_code].present? || params[:sub_entity_code].present? || params[:start_date].present? || params[:end_date].present?

      filter_params = params[:filter_main]
      if params[:filter_main].present?
        @assigned_code = filter_params[:assigned_code]
        @entity_info_code = filter_params[:entity_info_code]
        @active_status = filter_params[:active_status]
        @birth_date = filter_params[:birth_date]
        @gender = filter_params[:gender]
        @last_name = filter_params[:last_name]
        @first_name = filter_params[:first_name]
        @username = filter_params[:user_id]
        @entity_division_code = filter_params[:entity_division_code]
        @entity_sub_div_code = filter_params[:entity_sub_div_code]
        @sub_entity_code = filter_params[:sub_entity_code]
        @start_date = filter_params[:start_date]
        @end_date = filter_params[:end_date]

        params[:assigned_code] = filter_params[:assigned_code]
        params[:entity_info_code] = filter_params[:entity_info_code]
        params[:active_status] = filter_params[:active_status]
        params[:birth_date] = filter_params[:birth_date]
        params[:gender] = filter_params[:gender]
        params[:last_name] = filter_params[:last_name]
        params[:first_name] = filter_params[:first_name]
        params[:user_id] = filter_params[:user_id]
        params[:entity_division_code] = filter_params[:entity_division_code]
        params[:entity_sub_div_code] = filter_params[:entity_sub_div_code]
        params[:sub_entity_code] = filter_params[:sub_entity_code]
        params[:start_date] = filter_params[:start_date]
        params[:end_date] = filter_params[:end_date]

      else

        if params[:assigned_code].present? || params[:entity_info_code].present? || params[:entity_sub_div_code].present? || params[:active_status].present? || params[:birth_date].present? || params[:gender].present? || params[:last_name].present? || params[:first_name].present? || params[:user_id].present? || params[:sub_entity_code].present? || params[:entity_division_code].present? || params[:start_date].present? || params[:end_date].present?

          @assigned_code = params[:assigned_code]
          @entity_info_code = params[:entity_info_code]
          @active_status = params[:active_status]
          @birth_date = params[:birth_date]
          @gender = params[:gender]
          @last_name = params[:last_name]
          @first_name = params[:first_name]
          @username = params[:user_id]
          @entity_division_code = params[:entity_division_code]
          @entity_sub_div_code = params[:entity_sub_div_code]
          @sub_entity_code = params[:sub_entity_code]
          @start_date = params[:start_date]
          @end_date = params[:end_date]

          params[:assigned_code] = @assigned_code
          params[:entity_info_code] = @entity_info_code
          params[:active_status] = @active_status
          params[:birth_date] = @birth_date
          params[:gender] = @gender
          params[:last_name] = @last_name
          params[:first_name] = @first_name
          params[:user_id] = @username
          params[:entity_division_code] = @entity_division_code
          params[:entity_sub_div_code] = @entity_sub_div_code
          params[:sub_entity_code] = @sub_entity_code
          params[:start_date] = @start_date
          params[:end_date] = @end_date

        else
          params[:assigned_code] = filter_params[:assigned_code]
          params[:entity_info_code] = filter_params[:entity_info_code]
          params[:active_status] = filter_params[:active_status]
          params[:birth_date] = filter_params[:birth_date]
          params[:gender] = filter_params[:gender]
          params[:last_name] = filter_params[:last_name]
          params[:first_name] = filter_params[:first_name]
          params[:user_id] = filter_params[:user_id]
          params[:entity_division_code] = filter_params[:entity_division_code]
          params[:entity_sub_div_code] = filter_params[:entity_sub_div_code]
          params[:sub_entity_code] = filter_params[:sub_entity_code]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        end
      end

      if @assigned_code.present?
        #search_arr << "customer_number LIKE '%#{@cust_num}%'"
        search_arr << "assigned_code = '#{@assigned_code}'"
      end

      if @active_status.present?
        search_arr << "active_status = '#{@active_status}'"
      end

      if @birth_date.present?
        search_arr << "birth_date = '#{@birth_date}'"
      end

      if @gender.present?
        search_arr << "gender = '#{@gender}'"
      end

      if @last_name.present?
        search_arr << "last_name = '#{@last_name}'"
      end

      if @first_name.present?
        search_arr << "first_name = '#{@first_name}'"
      end

      if @entity_info_code.present?
        search_arr << "entity_info_code = '#{@entity_info_code}'"
      end

      if @username.present?
        search_arr << "person_infos.user_id = '#{@username}'"
      end

      if @sub_entity_code.present?
        search_arr << "sei.assigned_code = '#{@sub_entity_code}'"
      end

      if @entity_division_code.present?
        search_arr << "edv.assigned_code = '#{@entity_division_code}'"
      end
      if @entity_sub_div_code.present?
        search_arr << "esd.assigned_code = '#{@entity_sub_div_code}'"
      end

      if @start_date.present? && @end_date.present?
        f_start_date = @start_date.to_date.strftime('%Y-%m-%d')
        f_end_date = @end_date.to_date.strftime('%Y-%m-%d')
        if f_start_date <= f_end_date
          search_arr << "person_infos.created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
        end
      end

    else
    end

    the_search = search_arr.join(" AND ")
    logger.info "The search array :: #{search_arr.inspect}"
    logger.info "The Search :: #{the_search.inspect}"

    if params[:count] == "All"
      saved_size = @person_infos.exists? ? @person_infos.size : 0
      @person_infos = PersonInfo.persons_join.where(the_search).paginate(:page => 1, :per_page => saved_size).order('person_infos.created_at desc')
    else
      @person_infos = PersonInfo.persons_join.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('person_infos.created_at desc')
    end

  end

  # Checks existence of records in db
  def person_check
    logger.info "Params :: #{params.inspect}"
    the_branch_code = current_user.user_branch_code.present? ? current_user.user_branch_code : params[:branchcode]

    @person_exists = PersonInfo.person_branch_join(params).first
    person_code = ""
    if @person_exists.present?
      @person_sub_entity = PersonSubEntityInfo.where(person_assigned_code: @person_exists.assigned_code).order("created_at desc").first
      logger.info "sub entity info :: #{@person_sub_entity.sub_entity_code.inspect}"
      logger.info "Church name :: #{the_branch_code.inspect}"
      if @person_sub_entity.sub_entity_code == the_branch_code
        resp_code = "001"
        resp_desc = "Sorry, this member already exists in the system."
      else
        person_code = @person_exists.assigned_code
        resp_code = "000"
        resp_desc = "Successful."
      end

    else
      resp_code = "000"
      resp_desc = "Successful"
    end
    render json: { resp_code: resp_code, resp_desc: resp_desc, person_code: person_code }
  end

  # GET /person_infos/1 or /person_infos/1.json
  def show
  end

  # GET /person_infos/new
  def new
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    params[:branch_code] = current_user.user_branch_code
    @entity_info_search = EntityInfo.where(del_status: false).order(entity_name: :asc)
    @job_cat_code_search = JobCat.where(active_status: true).order(job_cat_desc: :asc)

    @marital_status_search = MaritalStatusMaster.where(active_status: true).order(status_desc: :asc)
    @emp_status_search = EmpStatusMaster.where(active_status: true).order(emp_status_desc: :asc)
    @disability_search = DisabilityMaster.where(active_status: true).order(disability_desc: :asc)
    @region_search = RegionMaster.where(del_status: false).order(region_desc: :asc)
    @condition_search = PersonConditionType.where(active_status: true).order(condition_desc: :asc)

    if current_user.super_admin? || current_user.user_admin?
      @sub_entity_name_search = SubEntityInfo.where(active_status: true).order(sub_entity_name: :asc)
      @group_name_search = GroupMaster.where(active_status: true).order(group_name: :asc)
      @prsn_group_search = @group_name_search.map { |a| ["#{a.group_name}", "#{a.assigned_code}"] }.insert(0, ['Select the type of group', ""])
      @relation_person_search = PersonInfo.where("del_status = false").select("concat_ws(' ', last_name, other_names, first_name ) as fullname, other_names, last_name, first_name, assigned_code").order('last_name asc')

    elsif current_user.merchant_admin?
      @sub_entity_name_search = SubEntityInfo.where(entity_code: params[:main_code], active_status: true).order(sub_entity_name: :asc)
      @group_name_search = GroupMaster.where(entity_info_code: params[:main_code], active_status: true).order(group_name: :asc)
      @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :asc)
      @prsn_group_search = @group_name_search.map { |a| ["#{a.group_name}", "#{a.assigned_code}"] }.insert(0, ['Select the type of group', ""])
      @relation_person_search = PersonInfo.where("del_status = false AND entity_info_code = '#{params[:main_code]}'").select("concat_ws(' ', last_name, other_names, first_name ) as fullname, other_names, last_name, first_name, assigned_code").order('last_name asc')

    elsif current_user.division_admin?
      @sub_division_desc_search = EntitySubDivision.where(entity_division_code: params[:div_code], del_status: false).order(sub_division_desc: :asc)
      @sub_entity_name_search = SubEntityInfo.where(entity_division_code: params[:div_code], active_status: true).order(sub_entity_name: :asc)
      @group_name_search = GroupMaster.where(entity_info_code: params[:main_code], active_status: true).order(group_name: :asc)
      @prsn_group_search = @group_name_search.map { |a| ["#{a.group_name}", "#{a.assigned_code}"] }.insert(0, ['Select the type of group', ""])
      @relation_person_search = PersonInfo.where("del_status = false AND entity_info_code = '#{params[:main_code]}'").select("concat_ws(' ', last_name, other_names, first_name ) as fullname, other_names, last_name, first_name, assigned_code").order('last_name asc')

    elsif current_user.branch_admin?
      @sub_entity_name_search = SubEntityInfo.where(assigned_code: params[:branch_code], active_status: true).order(sub_entity_name: :asc)
      @group_name_search = GroupMaster.where(entity_info_code: params[:main_code], active_status: true).order(group_name: :asc)
      @prsn_group_search = @group_name_search.map { |a| ["#{a.group_name}", "#{a.assigned_code}"] }.insert(0, ['Select the type of group', ""])
      @relation_person_search = PersonInfo.where("del_status = false AND entity_info_code = '#{params[:main_code]}'").select("concat_ws(' ', last_name, other_names, first_name ) as fullname, other_names, last_name, first_name, assigned_code").order('last_name asc')

    else
    end
    # Populates Nested forms
    @relationship_search = RelationshipMaster.where(active_status: true).order(relationship_desc: :asc)
    @role_desc_search = PersonRoleMaster.where(del_status: false).order(role_desc: :asc)
    @relation_search = @relationship_search.map { |a| ["#{a.relationship_desc}", "#{a.assigned_code}"] }.insert(0, ['Select the type of relationship', ""])
    @rel_person_search = @relation_person_search.map { |a| ["#{a.fullname}", "#{a.assigned_code}"] }.insert(0, ['Select a member relation', ""])

    @prsn_role_search = @role_desc_search.map { |a| ["#{a.role_desc}", "#{a.assigned_code}"] }.insert(0, ['Select the type of role', ""])

    @person_info = PersonInfo.new
  end

  # GET /person_infos/1/edit
  def edit
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    params[:branch_code] = current_user.user_branch_code

    @entity_info_search = EntityInfo.where(del_status: false).order(entity_name: :asc)
    @job_cat_code_search = JobCat.where(del_status: false).order(job_cat_desc: :asc)
    @job_type_search = JobType.where(del_status: false).order(job_type_desc: :asc)
    @marital_status_search = MaritalStatusMaster.where(del_status: false).order(status_desc: :asc)
    @emp_status_search = EmpStatusMaster.where(del_status: false).order(emp_status_desc: :asc)
    @disability_search = DisabilityMaster.where(del_status: false).order(disability_desc: :asc)
    @region_search = RegionMaster.where(del_status: false).order(region_desc: :asc)
    @city_town_name_search = CityTownMaster.where(del_status: false).order(city_town_name: :asc)
    @role_desc_search = PersonRoleMaster.where(del_status: false).order(role_desc: :asc)


    if current_user.super_admin? || current_user.user_admin?
      @division_name_search = EntityDivision.where(del_status: false).order(division_name: :asc)
      @sub_entity_name_search = SubEntityInfo.where(active_status: true).order(sub_entity_name: :asc)
      @group_name_search = GroupMaster.where(active_status: true).order(group_name: :asc)
      @prsn_group_search = @group_name_search.map { |a| ["#{a.group_name}", "#{a.assigned_code}"] }.insert(0, ['Select the type of group', ""])

    elsif current_user.merchant_admin?
      @sub_entity_name_search = SubEntityInfo.where(entity_code: params[:main_code], active_status: true).order(sub_entity_name: :asc)
      @group_name_search = GroupMaster.where(entity_info_code: params[:main_code], active_status: true).order(group_name: :asc)
      @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :asc)
      @prsn_group_search = @group_name_search.map { |a| ["#{a.group_name}", "#{a.assigned_code}"] }.insert(0, ['Select the type of group', ""])

    elsif current_user.division_admin?
      @division_name_search = EntityDivision.where(assigned_code: params[:div_code], del_status: false).order(division_name: :asc)
      @sub_division_desc_search = EntitySubDivision.where(entity_division_code: params[:div_code], del_status: false).order(sub_division_desc: :asc)
      @sub_entity_name_search = SubEntityInfo.where(entity_division_code: params[:div_code], active_status: true).order(sub_entity_name: :asc)
      @group_name_search = GroupMaster.where(entity_info_code: params[:main_code], active_status: true).order(group_name: :asc)
      @prsn_group_search = @group_name_search.map { |a| ["#{a.group_name}", "#{a.assigned_code}"] }.insert(0, ['Select the type of group', ""])

    elsif current_user.branch_admin?
      @sub_entity_name_search = SubEntityInfo.where(assigned_code: params[:branch_code], active_status: true).order(sub_entity_name: :asc)
      @group_name_search = GroupMaster.where(entity_info_code: params[:main_code], active_status: true).order(group_name: :asc)
      @prsn_group_search = @group_name_search.map { |a| ["#{a.group_name}", "#{a.assigned_code}"] }.insert(0, ['Select the type of group', ""])

    else
    end

    @relationship_search = RelationshipMaster.where(del_status: false).order(relationship_desc: :asc)
    @group_name_search = GroupMaster.where(del_status: false).order(group_name: :asc)
    @relation_person_search = PersonInfo.where("del_status = false").select("concat_ws(' ', last_name, other_names, first_name ) as fullname, other_names, last_name, first_name, assigned_code").order('last_name asc')

    @person_info.job_title = @person_info.person_emp_infos&.first.job_title if @person_info.person_emp_infos&.first
    @person_info.job_type_code = @person_info.person_emp_infos&.first.job_type_code if @person_info.person_emp_infos&.first
    @person_info.emp_loc_region_code = @person_info.person_emp_infos&.first.emp_loc_region_code if @person_info.person_emp_infos&.first
    @person_info.emp_loc_city_town_id = @person_info.person_emp_infos&.first.emp_loc_city_town_id if @person_info.person_emp_infos&.first
    @person_info.location_addr = @person_info.person_emp_infos&.first.location_addr if @person_info.person_emp_infos&.first

    @person_info.emp_status_code = @person_info.person_extra_infos&.first.emp_status_code if @person_info.person_extra_infos&.first
    @person_info.marital_status_code = @person_info.person_extra_infos&.first.marital_status_code if @person_info.person_extra_infos&.first
    @person_info.contact_number = @person_info.person_contact_infos&.first.contact_number if @person_info.person_contact_infos&.first
    @person_info.res_addr = @person_info.person_contact_infos&.first.res_addr if @person_info.person_contact_infos&.first
    @person_info.contact_email = @person_info.person_contact_infos&.first.contact_email if @person_info.person_contact_infos&.first
    @person_info.res_region_code = @person_info.person_contact_infos&.first.res_region_code if @person_info.person_contact_infos&.first
    @person_info.res_city_town_id = @person_info.person_contact_infos&.first.res_city_town_id if @person_info.person_contact_infos&.first
    @disabilities = PersonDisabilityInfo.where(active_status: true, person_assigned_code: @person_info.assigned_code)
    if @disabilities.exists?
      disabilities = []
      @disabilities.each_with_index do |disability, index|
        disabilities << disability.disability_id
      end
    else
      disabilities = []
    end

    @relationships = PersonRelationInfo.where(active_status: true, del_status: false, person_assigned_code: @person_info.assigned_code)
    if @relationships.exists?
      relationships = []
      @relationships.each_with_index do |relationship, index|
      relationships << relationship.relationship_code
      end
    else
      relationships = []
    end

    @person_info.relationship_code = relationships
    # @person_info.relationship_code = @person_info.person_relation_infos&.first.relationship_code if @person_info.person_relation_infos&.first

    @person_info.physical_disability = disabilities
    @person_info.disability = @person_info.person_extra_infos&.first.disability if @person_info.person_extra_infos&.first
    @person_info.emp_status_code = @person_info.person_extra_infos&.first.emp_status_code if @person_info.person_extra_infos&.first
    @person_info.entity_info_code = @person_info.entity_info_code if @person_info.entity_info_code
    @person_info.entity_division_code = @person_info.entity_extra_infos&.first.entity_division_code if @person_info.entity_extra_infos&.first
    @person_info.sub_entity_code = @person_info.entity_extra_infos&.first.sub_entity_code if @person_info.entity_extra_infos&.first
    @person_info.person_role_code = @person_info.entity_extra_infos&.first.person_role_code if @person_info.entity_extra_infos&.first

    @person_info.relation_person_code = @person_info.person_relation_infos&.first.relation_person_code if @person_info.person_relation_infos&.first
    @person_info.group_code = @person_info.person_group_infos&.first.group_code if @person_info.person_group_infos.first
    @person_info.image_data = "#{@person_info.person_images.first.image_path if @person_info.person_images.first}"

    @person_info.birth_date = @person_info.birth_date.strftime('%Y-%m-%d') if @person_info.birth_date != nil
    @person_info.baptism_date = @person_info.person_extra_infos&.first.baptism_date.strftime('%Y-%m-%d') if @person_info.person_extra_infos.first&.baptism_date
    @person_info.confirmation_date = @person_info.person_extra_infos&.first.confirmation_date.strftime('%Y-%m-%d') if @person_info.person_extra_infos.first&.confirmation_date
    @person_info.day_born = @person_info.person_extra_infos&.first.day_born if @person_info.person_extra_infos&.first

    # Populates Nested forms
    @relationship_search = RelationshipMaster.where(active_status: true).order(relationship_desc: :asc)
    @relation_person_search = PersonInfo.where("del_status = false").select("concat_ws(' ', last_name, other_names, first_name ) as fullname, other_names, last_name, first_name, assigned_code").order('last_name asc')
    @role_desc_search = PersonRoleMaster.where(del_status: false).order(role_desc: :asc)
    @relation_search = @relationship_search.map { |a| ["#{a.relationship_desc}", "#{a.assigned_code}"] }.insert(0, ['Select the type of relationship', ""])
    @rel_person_search = @relation_person_search.map { |a| ["#{a.fullname}", "#{a.assigned_code}"] }.insert(0, ['Select a member relation', ""])

    @prsn_role_search = @role_desc_search.map { |a| ["#{a.role_desc}", "#{a.assigned_code}"] }.insert(0, ['Select the type of role', ""])

  end

  def create
    @person_info = PersonInfo.new(person_info_params)
    flash.now[:notice] = "Person info was successfully created."

    logger.info "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"
    logger.info "Relationship :: #{params[:for_relationship].inspect}"
    params[:for_relationship].each do |key, value|
      logger.info "Relationship #{key} :: #{value.inspect}"
    end

    respond_to do |format|
      if @person_info.valid?

        assigned_code = PersonInfo.gen_person_code
        @person_info.assigned_code = assigned_code
        entity_info_code = person_info_params[:entity_info_code].present? ? person_info_params[:entity_info_code] : nil
        entity_division_code = person_info_params[:entity_division_code].present? ? person_info_params[:entity_division_code] : nil
        sub_entity_code = person_info_params[:sub_entity_code].present? ? person_info_params[:sub_entity_code] : nil
        contact_number = person_info_params[:contact_number].present? ? person_info_params[:contact_number] : nil

        last_name = person_info_params[:last_name].present? ? person_info_params[:last_name].strip : nil
        first_name = person_info_params[:first_name].present? ? person_info_params[:first_name].strip : nil
        other_names = person_info_params[:other_names].present? ? person_info_params[:other_names].strip : nil
        birth_date = person_info_params[:birth_date].present? ? person_info_params[:birth_date] : nil
        user_id = person_info_params[:user_id].present? ? person_info_params[:user_id] : nil
        gender = person_info_params[:gender].present? ? person_info_params[:gender] : nil
        comment = person_info_params[:comment].present? ? person_info_params[:comment] : nil
        @person_info = PersonInfo.new(assigned_code: assigned_code, entity_info_code: entity_info_code, last_name: last_name, first_name: first_name, other_names: other_names, birth_date: birth_date, gender: gender, user_id: user_id, comment: comment)
        @person_info.save(validate: false)

        @person_sub_entity_info = PersonSubEntityInfo.new(person_assigned_code: assigned_code, sub_entity_code: sub_entity_code, user_id: user_id)
        @person_sub_entity_info.save(validate: false)

        if person_info_params[:p_code].present?
        else
          baptism_date = person_info_params[:baptism_date].present? ? person_info_params[:baptism_date] : nil
          confirmation_date = person_info_params[:confirmation_date].present? ? person_info_params[:confirmation_date] : nil
          marital_status_code = person_info_params[:marital_status_code].present? ? person_info_params[:marital_status_code] : nil
          emp_status_code = person_info_params[:emp_status_code].present? ? person_info_params[:emp_status_code] : nil
          disability = person_info_params[:disability].present? ? person_info_params[:disability] : nil
          day_born = person_info_params[:day_born].present? ? person_info_params[:day_born] : nil
          user_id = person_info_params[:user_id].present? ? person_info_params[:user_id] : nil
          @person_extra_info = PersonExtraInfo.new(person_assigned_code: assigned_code, marital_status_code: marital_status_code, emp_status_code: emp_status_code, disability: disability, day_born: day_born, baptism_date: baptism_date, confirmation_date: confirmation_date, user_id: user_id)
          @person_extra_info.save(validate: false)

          contact_email = person_info_params[:contact_email].present? ? person_info_params[:contact_email] : nil
          res_addr = person_info_params[:res_addr].present? ? person_info_params[:res_addr] : nil
          res_region_code = person_info_params[:res_region_code].present? ? person_info_params[:res_region_code] : nil
          res_city_town_id = person_info_params[:res_city_town_id].present? ? person_info_params[:res_city_town_id] : nil
          user_id = person_info_params[:user_id].present? ? person_info_params[:user_id] : nil
          @person_contact_info = PersonContactInfo.new(person_assigned_code: assigned_code, contact_number: contact_number, contact_email: contact_email, res_addr: res_addr, res_region_code: res_region_code, res_city_town_id: res_city_town_id, user_id: user_id)
          @person_contact_info.save(validate: false)

          job_type_code = person_info_params[:job_type_code].present? ? person_info_params[:job_type_code] : nil
          job_title = person_info_params[:job_title].present? ? person_info_params[:job_title] : nil
          postal_addr = person_info_params[:postal_addr].present? ? person_info_params[:postal_addr] : nil
          emp_loc_region_code = person_info_params[:emp_loc_region_code].present? ? person_info_params[:emp_loc_region_code] : nil
          emp_loc_city_town_id = person_info_params[:emp_loc_city_town_id].present? ? person_info_params[:emp_loc_city_town_id] : nil
          @person_emp_info = PersonEmpInfo.new(person_assigned_code: assigned_code, job_type_code: job_type_code, job_title: job_title, postal_addr: postal_addr, emp_loc_region_code: emp_loc_region_code, contact_number: contact_number, emp_loc_city_town_id: emp_loc_city_town_id, contact_email: contact_email, user_id: user_id)
          @person_emp_info.save(validate: false)

          if person_info_params.has_key?('physical_disability') && person_info_params[:physical_disability] != nil
            person_info_params[:physical_disability].each do |physical_disability|
              @person_disability_info = PersonDisabilityInfo.new(person_assigned_code: assigned_code, disability_id: physical_disability, user_id: user_id)
              @person_disability_info.save(validate: false)
            end
          end

          if params.has_key?('for_relationship')
            params[:for_relationship].each do |key, value|
              logger.info "Relationship #{key} :: #{value.inspect}"
              if value.has_key?('relationship_code') && value[:relationship_code].present? && value.has_key?('relation_person_code') && value[:relation_person_code].present?
                relationship_code = value[:relationship_code]
                relation_person_code = value[:relation_person_code]

                @person_relation_info = PersonRelationInfo.new(person_assigned_code: assigned_code, relation_person_code: relation_person_code, relationship_code: relationship_code, user_id: user_id)
                @person_relation_info.save(validate: false)
              end
            end
          end

          # more entity_extra_info fields
          if params.has_key?('for_roles')
            params[:for_roles].each do |key, value|
              logger.info "PersonRole #{key} :: #{value.inspect}"
              if value.has_key?('person_role_code') && value[:person_role_code].present?
                person_role_code = value[:person_role_code]

                @entity_extra_info = EntityExtraInfo.new(entity_code: entity_info_code, entity_division_code: entity_division_code, sub_entity_code: sub_entity_code, person_assigned_code: assigned_code, person_role_code: person_role_code, user_id: user_id)
                @entity_extra_info.save(validate: false)
              end
            end
          end

          # more person_group fields
          if params.has_key?('for_group')
            params[:for_group].each do |key, value|
              logger.info "PersonGroup #{key} :: #{value.inspect}"
              if value.has_key?('group_code') && value[:group_code].present?
                group_code = value[:group_code]

                @person_group_info = PersonGroupInfo.new(person_assigned_code: assigned_code, group_code: group_code, sub_entity_code: sub_entity_code, user_id: user_id)
                @person_group_info.save(validate: false)
              end
            end
          end

          if person_info_params.has_key?('image_data') && person_info_params[:image_data] != nil
            #Image uploads
            image_uploader = ChurchCore::ImageDataUploader.new
            image_data = person_info_params[:image_data].present? ? person_info_params[:image_data] : ""
            img_public_id = image_uploader.public_id(image_data)
            img_store_dir = image_uploader.store_dir
            logger.info "Image Data 1 :: #{image_data.original_filename.split(".").inspect}"

            tab_image_path = "#{person_info_params[:image_path]}#{img_store_dir}/"
            tab_image_data = image_uploader.filename(image_data, img_public_id)
            logger.info "===========================//////////////////================="
            logger.info "image data #{person_info_params[:image_data].inspect}"
            # logger.info "Image Path :: #{@person_info.image_path.inspect}"
            logger.info "Image Data :: #{@person_info.image_data.inspect}"

            logger.info "Cloudinary Saving =========================="
            @image_results = Cloudinary::Uploader.upload(image_data, :public_id => img_public_id)
            logger.info "The Image Data :: #{@image_results["secure_url"].inspect}"
            @person_images = PersonImage.new(image_path: @image_results["secure_url"], image_data: tab_image_data, person_assigned_code: assigned_code, user_id: user_id)
            @person_images.save(validate: false)
          else
          end
        end

        # Sending sms
        resp_code, resp_desc = PersonInfo.sending_sms(contact_number, assigned_code, entity_info_code)
        logger.info "@resp_code = #{resp_code.inspect}, @resp_desc =  #{resp_desc.inspect}"

        if resp_code == "000"
          # update the Person info
          flash.now[:notice] = resp_desc
          person_infos_index
          format.js { render "/person_infos/person_infos_index" }
          format.html { redirect_to person_info_path(@person_info), notice: "Member's info was successfully created." }
          format.json { render :person_infos_index, status: :created, location: @person_info }
        else
          flash.now[:notice] = resp_desc
          format.js { render :person_infos_index }

          person_infos_index
          format.js { render "/person_infos/person_infos_index" }
          format.html { redirect_to person_info_path(@person_info), notice: "Member's info was successfully created." }
          format.json { render :person_infos_index, status: :created, location: @person_info }
        end
      else

        @entity_info_search = EntityInfo.where(del_status: false).order(entity_name: :asc)
        @job_cat_code_search = JobCat.where(del_status: false).order(job_cat_desc: :asc)
        @job_type_search = JobType.where(del_status: false).order(job_type_desc: :asc)
        @marital_status_search = MaritalStatusMaster.where(del_status: false).order(status_desc: :asc)
        @emp_status_search = EmpStatusMaster.where(del_status: false).order(emp_status_desc: :asc)
        @disability_search = DisabilityMaster.where(del_status: false).order(disability_desc: :asc)

        @region_search = RegionMaster.where(del_status: false).order(region_desc: :asc)

        logger.info "Person Info Error Messages :: #{@person_info.errors.messages.inspect}"
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @person_info.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|

      @person_info = PersonInfo.where(active_status: true, assigned_code: params[:id]).order(created_at: :desc).first
      flash.now[:notice] = "Member's Info was updated successfully."

      logger.info params[:person_info].inspect
      @new_record = PersonInfo.new(person_info_params)

      @new_record.assigned_code = @person_info.assigned_code
      if @new_record.valid?
        @person_info.active_status = false
        @person_info.del_status = true
        @person_info.save(validate: false)
        if @new_record.save
          entity_info_code = person_info_params[:entity_info_code].present? ? person_info_params[:entity_info_code] : nil
          entity_division_code = person_info_params[:entity_division_code].present? ? person_info_params[:entity_division_code] : nil
          sub_entity_code = person_info_params[:sub_entity_code].present? ? person_info_params[:sub_entity_code] : nil

          marital_status_code = person_info_params[:marital_status_code].present? ? person_info_params[:marital_status_code] : nil
          emp_status_code = person_info_params[:emp_status_code].present? ? person_info_params[:emp_status_code] : nil
          day_born = person_info_params[:day_born].present? ? person_info_params[:day_born] : nil
          disability = person_info_params[:disability].present? ? person_info_params[:disability] : nil
          confirmation_date = person_info_params[:confirmation_date].present? ? person_info_params[:confirmation_date] : nil
          baptism_date = person_info_params[:baptism_date].present? ? person_info_params[:baptism_date] : nil

          contact_number = person_info_params[:contact_number].present? ? person_info_params[:contact_number] : nil
          contact_email = person_info_params[:contact_email].present? ? person_info_params[:contact_email] : nil
          res_addr = person_info_params[:res_addr].present? ? person_info_params[:res_addr] : nil
          res_region_code = person_info_params[:res_region_code].present? ? person_info_params[:res_region_code] : nil
          res_city_town_id = person_info_params[:res_city_town_id].present? ? person_info_params[:res_city_town_id] : nil
          job_type_code = person_info_params[:job_type_code].present? ? person_info_params[:job_type_code] : nil
          job_title = person_info_params[:job_title].present? ? person_info_params[:job_title] : nil
          postal_addr = person_info_params[:postal_addr].present? ? person_info_params[:postal_addr] : nil
          emp_loc_region_code = person_info_params[:emp_loc_region_code].present? ? person_info_params[:emp_loc_region_code] : nil
          emp_loc_city_town_id = person_info_params[:emp_loc_city_town_id].present? ? person_info_params[:emp_loc_city_town_id] : nil

          @person_extra_info = PersonExtraInfo.where(active_status: true, person_assigned_code: params[:id]).order(created_at: :desc).first
          if @person_extra_info
            if person_info_params[:marital_status_code] != @person_extra_info.marital_status_code || person_info_params[:emp_status_code] != @person_extra_info.emp_status_code || person_info_params[:disability] != @person_extra_info.disability || person_info_params[:day_born] != @person_extra_info.day_born || person_info_params[:baptism_date] != @person_extra_info.baptism_date || person_info_params[:confirmation_date] != @person_extra_info.confirmation_date
              @person_extra_info.active_status = false
              @person_extra_info.del_status = true
              @person_extra_info.save(validate: false)
              @person_extra_infos = PersonExtraInfo.new(person_assigned_code: params[:id], marital_status_code: marital_status_code, emp_status_code: emp_status_code, day_born: day_born, active_status: true, del_status: false, disability: disability, confirmation_date: confirmation_date, baptism_date: baptism_date, user_id: current_user.id)
              @person_extra_infos.save(validate: false)
            end
          else
            @person_extra_infos = PersonExtraInfo.new(person_assigned_code: params[:id], marital_status_code: marital_status_code, emp_status_code: emp_status_code, day_born: day_born, active_status: true, del_status: false, disability: disability, confirmation_date: confirmation_date, baptism_date: baptism_date, user_id: current_user.id)
            @person_extra_infos.save(validate: false)
          end

          @person_sub_entity_info = PersonSubEntityInfo.where(active_status: true, person_assigned_code: params[:id]).order(created_at: :desc).first
          if @person_sub_entity_info
            if person_info_params[:sub_entity_code] != @person_sub_entity_info.sub_entity_code
              @person_sub_entity_info.active_status = false
              @person_sub_entity_info.del_status = true
              @person_sub_entity_info.save(validate: false)
              @person_sub_entity_infos = PersonSubEntityInfo.new(person_assigned_code: params[:id], sub_entity_code: sub_entity_code, user_id: current_user.id)
              @person_sub_entity_infos.save(validate: false)
            end
          else
            @person_sub_entity_infos = PersonSubEntityInfo.new(person_assigned_code: params[:id], sub_entity_code: sub_entity_code, user_id: current_user.id)
            @person_sub_entity_infos.save(validate: false)
          end

          @person_contact_info = PersonContactInfo.where(active_status: true, person_assigned_code: params[:id]).order(created_at: :desc).first
          if @person_contact_info
            if person_info_params[:contact_number] != @person_contact_info.contact_number || person_info_params[:contact_email] != @person_contact_info.contact_email || person_info_params[:res_addr] != @person_contact_info.res_addr || person_info_params[:res_region_code] != @person_contact_info.res_region_code || person_info_params[:res_city_town_id] != @person_contact_info.res_city_town_id
              @person_contact_info.active_status = false
              @person_contact_info.del_status = true
              @person_contact_info.save(validate: false)
              @person_contact_infos = PersonContactInfo.new(person_assigned_code: params[:id], contact_number: contact_number, contact_email: contact_email, res_addr: res_addr, res_region_code: res_region_code, res_city_town_id: res_city_town_id, active_status: true, del_status: false, user_id: current_user.id)
              @person_contact_infos.save(validate: false)
            end
          else
            @person_contact_infos = PersonContactInfo.new(person_assigned_code: params[:id], contact_number: contact_number, contact_email: contact_email, res_addr: res_addr, postal_addr: postal_addr, res_region_code: res_region_code, res_city_town_id: res_city_town_id, active_status: true, del_status: false, user_id: current_user.id)
            @person_contact_infos.save(validate: false)
          end

          @person_emp_info = PersonEmpInfo.where(active_status: true, person_assigned_code: params[:id]).order(created_at: :desc).first
          if @person_emp_info
            if person_info_params[:job_type_code] != @person_emp_info.job_type_code || person_info_params[:job_title] != @person_emp_info.job_title || person_info_params[:postal_addr] != @person_emp_info.postal_addr || person_info_params[:emp_loc_region_code] != @person_emp_info.emp_loc_region_code || person_info_params[:emp_loc_city_town_id] != @person_emp_info.emp_loc_city_town_id
              @person_emp_info.active_status = false
              @person_emp_info.del_status = true
              @person_emp_info.save(validate: false)
              @person_emp_infos = PersonEmpInfo.new(person_assigned_code: params[:id], job_type_code: job_type_code, job_title: job_title, postal_addr: postal_addr, emp_loc_region_code: emp_loc_region_code, emp_loc_city_town_id: emp_loc_city_town_id, contact_number: contact_number, active_status: true, del_status: false, user_id: current_user.id)
              @person_emp_infos.save(validate: false)
            end
          else
            @person_emp_infos = PersonEmpInfo.new(person_assigned_code: params[:id], job_type_code: job_type_code, job_title: job_title, postal_addr: postal_addr, emp_loc_region_code: emp_loc_region_code, emp_loc_city_town_id: emp_loc_city_town_id, contact_number: contact_number, active_status: true, del_status: false, user_id: current_user.id)
            @person_emp_infos.save(validate: false)
          end

          @person_dis_info = PersonDisabilityInfo.where(active_status: true, person_assigned_code: params[:id]).order(created_at: :desc)
          @person_disability_info = @person_dis_info.first
          if @person_disability_info
            @person_dis_info.each do |person_dis_info|
              person_dis_info.active_status = false
              person_dis_info.del_status = true
              person_dis_info.save(validate: false)
            end
            if person_info_params.has_key?('physical_disability') && person_info_params[:physical_disability] != nil
              person_info_params[:physical_disability].each do |physical_disability|
                @person_disability_info = PersonDisabilityInfo.new(person_assigned_code: @person_info.assigned_code, disability_id: physical_disability, user_id: current_user.id)
                @person_disability_info.save(validate: false)
              end
            end

          else
            if person_info_params.has_key?('physical_disability') && person_info_params[:physical_disability] != nil
              person_info_params[:physical_disability].each do |physical_disability|
                @person_disability_info = PersonDisabilityInfo.new(person_assigned_code: @person_info.assigned_code, disability_id: physical_disability, user_id: current_user.id)
                @person_disability_info.save(validate: false)
              end
            end
          end

          @entity_extra = EntityExtraInfo.where(active_status: true, person_assigned_code: params[:id]).order(created_at: :desc)
          @entity_extra_info = @entity_extra.first

          if @entity_extra_info
            @entity_extra.each do |entity_extra|
              entity_extra.active_status = false
              entity_extra.del_status = true
              entity_extra.save(validate: false)
            end
            # more entity_extra_info fields
            if params.has_key?('for_roles')
              params[:for_roles].each do |key, value|
                # logger.info "PersonRole #{key} :: #{value.inspect}"
                if value.has_key?('person_role_code') && value[:person_role_code].present?
                  person_role_code = value[:person_role_code]
                  @entity_extra_info = EntityExtraInfo.new(entity_code: entity_info_code, entity_division_code: entity_division_code, sub_entity_code: sub_entity_code, person_assigned_code: @person_info.assigned_code, person_role_code: person_role_code, user_id: current_user.id)
                  @entity_extra_info.save(validate: false)
                end
              end
            end
          else
            if params.has_key?('for_roles')
              params[:for_roles].each do |key, value|
                # logger.info "PersonRole #{key} :: #{value.inspect}"
                if value.has_key?('person_role_code') && value[:person_role_code].present?
                  person_role_code = value[:person_role_code]
                  @entity_extra_info = EntityExtraInfo.new(entity_code: entity_info_code, entity_division_code: entity_division_code, sub_entity_code: sub_entity_code, person_assigned_code: @person_info.assigned_code, person_role_code: person_role_code, user_id: current_user.id)
                  @entity_extra_info.save(validate: false)
                end
              end
            end
          end

          @person_rel = PersonRelationInfo.where(active_status: true, person_assigned_code: params[:id]).order(created_at: :desc)
          @person_relation_info = @person_rel.first
          if @person_relation_info
            @person_rel.each do |person_rel_info|
              person_rel_info.active_status = false
              person_rel_info.del_status = true
              person_rel_info.save(validate: false)
            end
            if params.has_key?('for_relationship')
              params[:for_relationship].each do |key, value|
                if value.has_key?('relationship_code') && value[:relationship_code].present? && value.has_key?('relation_person_code') && value[:relation_person_code].present?
                  relationship_code = value[:relationship_code]
                  relation_person_code = value[:relation_person_code]
                  @person_relation_info = PersonRelationInfo.new(person_assigned_code: @person_info.assigned_code, relation_person_code: relation_person_code, relationship_code: relationship_code, user_id: current_user.id)
                  @person_relation_info.save(validate: false)
                end
              end
            end
          else
            if params.has_key?('for_relationship')
              params[:for_relationship].each do |key, value|
                if value.has_key?('relationship_code') && value[:relationship_code].present? && value.has_key?('relation_person_code') && value[:relation_person_code].present?
                  relationship_code = value[:relationship_code]
                  relation_person_code = value[:relation_person_code]

                  @person_relation_info = PersonRelationInfo.new(person_assigned_code: @person_info.assigned_code, relation_person_code: relation_person_code, relationship_code: relationship_code, user_id: current_user.id)
                  @person_relation_info.save(validate: false)
                end
              end
            end
          end

          @person_group = PersonGroupInfo.where(active_status: true).order(created_at: :desc)
          @person_group_info = @person_group.first

          if @person_group_info
            @person_group.each do |group_info|
              group_info.active_status = false
              group_info.del_status = true
              group_info.save(validate: false)
            end
            if params.has_key?('for_group')
              # more person_group fields
              params[:for_group].each do |key, value|
                logger.info "PersonGroup #{key} :: #{value.inspect}"
                if value.has_key?('group_code') && value[:group_code].present?
                  group_code = value[:group_code]

                  @person_group_info = PersonGroupInfo.new(person_assigned_code: @person_info.assigned_code, group_code: group_code, sub_entity_code: sub_entity_code, user_id: current_user.id)
                  @person_group_info.save(validate: false)
                end
              end
            end
          else
            if params.has_key?('for_group')
              # more person_group fields
              params[:for_group].each do |key, value|
                # logger.info "PersonGroup #{key} :: #{value.inspect}"
                if value.has_key?('group_code') && value[:group_code].present?
                  group_code = value[:group_code]

                  @person_group_info = PersonGroupInfo.new(person_assigned_code: @person_info.assigned_code, group_code: group_code, sub_entity_code: sub_entity_code, user_id: current_user.id)
                  @person_group_info.save(validate: false)
                end
              end
            end
          end

          @person_image = PersonImage.where(active_status: true, person_assigned_code: params[:id]).order(created_at: :desc).first

          if person_info_params[:image_data].present?
            #Image uploads (Variables)
            image_uploader = ChurchCore::ImageDataUploader.new
            image_data = person_info_params[:image_data].present? ? person_info_params[:image_data] : ""
            img_public_id = image_uploader.public_id(image_data)
            img_store_dir = image_uploader.store_dir
            logger.info "Image Data 1 :: #{image_data.original_filename.split(".").inspect}"

            tab_image_path = "#{person_info_params[:image_path]}#{img_store_dir}/"
            tab_image_data = image_uploader.filename(image_data, img_public_id)
            logger.info "===========================//////////////////================="
            logger.info "image data #{person_info_params[:image_data].inspect}"
            # logger.info "Image Path :: #{@person_info.image_path.inspect}"
            logger.info "Image Data :: #{@person_info.image_data.inspect}"

            logger.info "Cloudinary Saving =========================="
            @image_results = Cloudinary::Uploader.upload(image_data, :public_id => img_public_id)
            logger.info "The Image Data :: #{@image_results["secure_url"].inspect}"

            if @person_image

              if person_info_params[:image_data] != @person_image.image_data
                @person_image.active_status = false
                @person_image.del_status = true
                @person_image.save(validate: false)

                @person_images = PersonImage.new(person_assigned_code: params[:id], image_path: @image_results["secure_url"], image_data: tab_image_data, user_id: current_user.id)
                @person_images.save(validate: false)
              end
            else
              @person_images = PersonImage.new(person_assigned_code: params[:id], image_path: @image_results["secure_url"], image_data: tab_image_data, user_id: current_user.id)
              @person_images.save(validate: false)
            end
          else
          end
        else
        end
        person_infos_index
        format.js { render "/person_infos/person_infos_index" }
        format.html { redirect_to person_info_path(@person_info), notice: "Member's info was successfully updated." }
        format.json { render :person_infos_index, status: :created, location: @person_info }
      else

        logger.info "Division Error Messages Edit :: #{@new_record.errors.messages.inspect}"

        format.html { render :edit }
        format.js { render :edit }
        format.json { render json: @person_info.errors, status: :unprocessable_entity }
      end
    end
  end

  # Region-City cascading
  def person_update
    logger.info "Params:: #{params[:id_for_region].inspect}"
    if params[:id_for_region].empty?
      @region_update_city = [["", ""]].insert(0, ['Please select a City', ""])
    else
      region_update_city = CityTownMaster.where(region_code: params[:id_for_region], active_status: true).order(city_town_name: :asc).map { |a| [a.city_town_name, a.id] }.insert(0, ['Please select a City', ""])

      @region_update_city = region_update_city.empty? ? [["", ""]].insert(0, ['Please select a City', ""]) : region_update_city
    end
    logger.info "For City :: #{@region_update_city.inspect}"
  end

  def person_update1b
    logger.info "Params:: #{params[:id_for_region2].inspect}"
    if params[:id_for_region2].empty?
      @region_update_city = [["", ""]].insert(0, ['Please select a City', ""])
    else
      region_update_city = CityTownMaster.where(region_code: params[:id_for_region2], active_status: true).order(city_town_name: :asc).map { |a| [a.city_town_name, a.id] }.insert(0, ['Please select a City', ""])

      @region_update_city = region_update_city.empty? ? [["", ""]].insert(0, ['Please select a City', ""]) : region_update_city
    end
    logger.info "For City :: #{@region_update_city.inspect}"
  end

  # Job_category and job_type cascading
  def person_update2
    logger.info "Params:: #{params[:id_for_job_cat].inspect}"
    if params[:id_for_job_cat].empty?
      @job_cat_update_job_type = [["", ""]].insert(0, ['Please select a Job Type', ""])
    else
      job_cat_update_job_type = JobType.where(job_cat_code: params[:id_for_job_cat], active_status: true).order(job_type_desc: :asc).map { |a| [a.job_type_desc, a.id] }.insert(0, ['Please select a Job Type', ""])

      @job_cat_update_job_type = job_cat_update_job_type.empty? ? [["", ""]].insert(0, ['Please select a Job Type', ""]) : job_cat_update_job_type
    end
    logger.info "For Job Type :: #{@job_cat_update_job_type.inspect}"
  end

  # entity_info/entity_division/sub_division/branch cascading
  def person_update3
    logger.info "Params:: #{params[:id_for_entity_info].inspect}"
    if params[:id_for_entity_info].empty?
      @info_update_division = [["", ""]].insert(0, ['Please select a Division', ""])
    else
      info_update_division = EntityDivision.where(entity_code: params[:id_for_entity_info], active_status: true).order(division_name: :asc).map { |a| [a.division_name, a.id] }.insert(0, ['Please select a Division', ""])
      @info_update_division = info_update_division.empty? ? [["", ""]].insert(0, ['Please select a Division', ""]) : info_update_division
    end
    logger.info "For Entity Division :: #{@info_update_division.inspect}"
  end

  def person_update3b
    if params[:id_for_division].empty?
      @division_update_sub_division = [["", ""]].insert(0, ['Please select a Sub Division', ""])
    else
      division_update_sub_division = EntitySubDivision.where(entity_division_code: params[:id_for_division], active_status: true).order(sub_division_desc: :asc).map { |a| [a.sub_division_desc, a.id] }.insert(0, ['Please select a Sub Division', ""])
      @division_update_sub_division = division_update_sub_division.empty? ? [["", ""]].insert(0, ['Please select a Sub Division', ""]) : division_update_sub_division
    end
    logger.info "For Sub Division :: #{@division_update_sub_division.inspect}"
  end

  def person_update3c
    if params[:id_for_sub_div].empty?
      @sub_division_update_sub_entity = [["", ""]].insert(0, ['Please select a Branch', ""])
    else
      sub_division_update_sub_entity = SubEntityInfo.where(entity_sub_div_code: params[:id_for_sub_div], active_status: true).order(sub_entity_name: :asc).map { |a| [a.sub_entity_name, a.id] }.insert(0, ['Please select a Branch', ""])
      @sub_division_update_sub_entity = sub_division_update_sub_entity.empty? ? [["", ""]].insert(0, ['Please select a Branch', ""]) : sub_division_update_sub_entity
    end
    logger.info "For Branch :: #{@sub_division_update_sub_entity.inspect}"
  end

  def church_update_rel
    # @relation_person_search = PersonInfo.where("del_status = false").select("concat_ws(' ', last_name, other_names, first_name ) as fullname, other_names, last_name, first_name, assigned_code").order('last_name asc')

    logger.info "Params:: #{params[:id_for_entity_info].inspect}"
    if params[:id_for_entity_info].empty?
      @church_update_rel = [["", ""]].insert(0, ['Please select a Member', ""])
    else
      entity_update_member = PersonInfo.where(entity_info_code: params[:id_for_entity_info], active_status: true).select("concat_ws(' ', last_name, other_names, first_name ) as fullname, other_names, last_name, first_name, assigned_code").order(fullname: :asc).map { |a| [a.fullname, a.id] }.insert(0, ['Please select a Member', ""])
      @church_update_rel = entity_update_member.empty? ? [["", ""]].insert(0, ['Please select a Member', ""]) : entity_update_member
    end
    logger.info "For Person Info :: #{@church_update_rel.inspect}"
  end

  # DETAILS MODAL
  def person_detail_show
    @person_info = PersonInfo.where(assigned_code: (params[:person_id]), active_status: true).order('person_infos.created_at asc').first
  end

  def pic_modal
    @person_info = PersonInfo.where(assigned_code: params[:person_id], active_status: true).order('person_infos.created_at asc').first
  end

  def enable_form
      @person_info = PersonInfo.where(assigned_code: params[:person_id], del_status: false).order(created_at: :desc).first
    if current_user.super_admin? || current_user.user_admin?
      @person_info = PersonInfo.where(assigned_code: params[:person_id], del_status: false).order(created_at: :desc).first
      @exit_desc_search = PersonExitLov.where(active_status: true).order(exit_desc: :desc)
      @cause_search = PersonExitInfo.where(del_status: false).order(cause: :asc)
    end
    unless current_user.super_admin? || current_user.user_admin?
      @exit_desc_search = PersonExitLov.where(entity_code: params[:church_code], active_status: true).order(exit_desc: :asc)
      @cause_search = PersonExitInfo.where(del_status: false).order(cause: :asc)
    end
    @person_info.exit_lov_id = @person_info.person_exit_infos&.first.exit_lov_id if @person_info.person_exit_infos&.first
    @person_info.cause = @person_info.person_exit_infos&.first.cause if @person_info.person_exit_infos&.first
    @person_info.exit_comment = @person_info.person_exit_infos&.first.comment if @person_info.person_exit_infos&.first
  end

  def disable_form
      @person_info = PersonInfo.where(assigned_code: params[:person_id], del_status: false).order(created_at: :desc).first
    if current_user.super_admin? || current_user.user_admin?
      @exit_desc_search = PersonExitLov.where(active_status: true).order(exit_desc: :asc)
      @cause_search = PersonExitInfo.where(del_status: false).order(cause: :asc)
    end
    unless current_user.super_admin? || current_user.user_admin?
      @exit_desc_search = PersonExitLov.where(entity_code: params[:church_code], active_status: true).order(exit_desc: :asc)
      @cause_search = PersonExitInfo.where(del_status: false).order(cause: :asc)
    end
  end

  def enable_member
    sub_entity = PersonSubEntityInfo.where(person_assigned_code: params[:person_id]).where(del_status: false).order(created_at: :desc).last
    respond_to do |format|
      sub_entity.active_status = true
      if sub_entity.save(validate: false)
        # person_exit_info fields
        if person_info_params.has_key?('status') && person_info_params[:status] == "1"
          person_info = PersonInfo.where(assigned_code: params[:person_id]).where(del_status: false).order(created_at: :desc).first
          person_info.status = false
          person_info.save(validate: false)

          entity_code = person_info_params[:exit_church].present? ? person_info_params[:exit_church] : nil
          sub_entity_code = person_info_params[:exit_branch].present? ? person_info_params[:exit_branch] : nil
          person_assigned_code = person_info_params[:exit_assigned].present? ? person_info_params[:exit_assigned] : nil
          exit_lov_id = person_info_params[:exit_lov_id].present? ? person_info_params[:exit_lov_id] : nil
          cause = person_info_params[:cause].present? ? person_info_params[:cause] : nil
          exit_comment = person_info_params[:exit_comment].present? ? person_info_params[:exit_comment] : nil
          user_id = person_info_params[:user_id].present? ? person_info_params[:user_id] : nil

          @person_exit_info = PersonExitInfo.where(active_status: true, person_assigned_code: params[:person_id]).order(created_at: :desc).first
          if @person_exit_info
            if person_info_params[:cause] != @person_exit_info.cause || person_info_params[:exit_lov_id] != @person_exit_info.exit_lov_id || person_info_params[:sub_entity_code] != @person_exit_info.sub_entity_code || person_info_params[:entity_code] != @person_exit_info.entity_code
              @person_exit_info.active_status = false
              @person_exit_info.del_status = true
              @person_exit_info.save(validate: false)
              @person_exit_infos = PersonExitInfo.new(entity_code: entity_code, person_assigned_code: person_assigned_code, sub_entity_code: sub_entity_code, cause: cause, exit_lov_id: exit_lov_id, comment: exit_comment, user_id: user_id, return: true)
              @person_exit_infos.save(validate: false)
            end
          else
            @person_exit_info = PersonExitInfo.new(entity_code: entity_code, person_assigned_code: person_assigned_code, sub_entity_code: sub_entity_code, cause: cause, exit_lov_id: exit_lov_id, comment: exit_comment, user_id: user_id)
            @person_exit_info.save(validate: false)
          end
          person_infos_index
          flash.now[:notice] = "Member Enabled again."
          format.js { render "/person_infos/person_infos_index" }
          format.html { redirect_to person_info_path(@person_info), notice: "Member was enabled successfully." }
          format.json { render :person_infos_index, status: :created, location: @person_info }
        end
        person_infos_index
        flash.now[:notice] = "Member Enabled successfully."
        format.js { render "/person_infos/person_infos_index" }
        format.html { redirect_to person_info_path(@person_info), notice: "Member was enabled successfully." }
        format.json { render :person_infos_index, status: :created, location: @person_info }
      else
        person_infos_index
        flash.now[:notice] = "Member Enabled successfully."
        format.js { render :person_info_index }
        format.html { render :person_info_index }
        format.json { render json: @person_exit_lov.errors, status: :unprocessable_entity }
      end
    end
  end

  def disable_member
    sub_entity = PersonSubEntityInfo.where(person_assigned_code: params[:person_id]).where(del_status: false).order(created_at: :desc).last
    respond_to do |format|
      sub_entity.active_status = false
      if sub_entity.save(validate: false)
        # person_exit_info fields
        if person_info_params.has_key?('status') && person_info_params[:status] == "1"
          person_info = PersonInfo.where(assigned_code: params[:person_id]).where(del_status: false).order(created_at: :desc).first
          person_info.status = true
          person_info.save(validate: false)

          entity_code = person_info_params[:exit_church].present? ? person_info_params[:exit_church] : nil
          sub_entity_code = person_info_params[:exit_branch].present? ? person_info_params[:exit_branch] : nil
          person_assigned_code = person_info_params[:exit_assigned].present? ? person_info_params[:exit_assigned] : nil
          exit_lov_id = person_info_params[:exit_lov_id].present? ? person_info_params[:exit_lov_id] : nil
          cause = person_info_params[:cause].present? ? person_info_params[:cause] : nil
          exit_comment = person_info_params[:exit_comment].present? ? person_info_params[:exit_comment] : nil
          user_id = person_info_params[:user_id].present? ? person_info_params[:user_id] : nil

          @person_exit_info = PersonExitInfo.new(entity_code: entity_code, person_assigned_code: person_assigned_code, sub_entity_code: sub_entity_code, cause: cause, exit_lov_id: exit_lov_id, comment: exit_comment, user_id: user_id)
          @person_exit_info.save(validate: false)

          person_infos_index
          flash.now[:notice] = "Member Disabled Completely."
          format.js { render "/person_infos/person_infos_index" }
          format.html { redirect_to person_info_path(@person_info), notice: "Member was Disabled Completely." }
          format.json { render :person_infos_index, status: :created, location: @person_info }
        end
        person_infos_index
        flash.now[:notice] = "Member Disabled successfully."
        format.js { render "/person_infos/person_infos_index" }
        format.html { redirect_to person_info_path(@person_info), notice: "Member was Disabled successfully." }
        format.json { render :person_infos_index, status: :created, location: @person_info }
      else
        person_infos_index
        flash.now[:notice] = "Member Disabled successfully."
        format.js { render :person_info_index }
        format.html { render :person_info_index }
        format.json { render json: @person_exit_lov.errors, status: :unprocessable_entity }
      end
    end
  end

  private

  # Use callbacks to share common setup or constraints between actions.
  def set_person_info
    # @person_info = PersonInfo.find(params[:id])
    @person_info = PersonInfo.where(active_status: true, assigned_code: params[:id]).order(created_at: :asc).first
  end

  # Only allow a list of trusted parameters through.
  def person_info_params
    params.require(:person_info).permit(:assigned_code, :entity_info_code, :last_name, :first_name, :other_names,
                                        :birth_date, :gender, :comment, :active_status, :del_status, :status, :disability,
                                        :user_id, :created_at, :updated_at, :job_title, :job_type_code, :job_cat,
                                        :marital_status_code, :emp_status_code, :day_born, :p_code,
                                        :contact_number, :contact_email, :res_region_code, :res_city_town_id,
                                        :res_addr, :postal_addr, :person_role_code, :sub_entity_code, :entity_division_code, :entity_sub_div,
                                        :relation_person_code, :relation_last_name, :relation_first_name, :relation_other_names,
                                        :relationship_code, :emp_loc_city_town_id, :emp_loc_region_code, :emp_postal_addr,
                                        :emp_loc_addr, :location_addr, :group_code, :image_data, :condition_type_code, :start_date,
                                        :end_date, :facility_type, :facility_name, :baptism_date, :confirmation_date, :exit_lov_id, :cause, :exit_church, :exit_branch, :exit_comment, :exit_assigned, physical_disability: [])
  end
end
