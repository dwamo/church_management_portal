class PersonIssuesLogTrackersController < ApplicationController
  before_action :set_person_issues_log_tracker, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource

  # GET /person_issues_log_trackers or /person_issues_log_trackers.json
  def index
    params[:count] ? params[:count] : params[:count] = 6
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.super_admin? || current_user.user_admin?
      @person_issues_logs = PersonIssuesLog.paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

    elsif current_user.branch_admin?
      params[:branch_code] = current_user.user_branch_code
      @person_issues_logs = PersonIssuesLog.where("sub_entity_code = '#{params[:branch_code]}'").paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

    end

  end

  def person_issues_index
    if current_user.super_admin? || current_user.user_admin?

      if params[:count] == "All"
        @person_issues_logs = PersonIssuesLog.all
        saved_size = @person_issues_logs.exists? ? @person_issues_logs.size : 0
        @person_issues_logs = PersonIssuesLog.paginate(:page => 1, :per_page => saved_size).order('created_at desc')
      else
        @person_issues_logs = PersonIssuesLog.paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
      end

    elsif current_user.branch_admin?
      params[:branch_code] = current_user.user_branch_code
      if params[:count] == "All"
        @person_issues_logs = PersonIssuesLog.all
        saved_size = @person_issues_logs.exists? ? @person_issues_logs.size : 0
        @person_issues_logs = PersonIssuesLog.where("sub_entity_code = '#{params[:branch_code]}'").paginate(:page => 1, :per_page => saved_size).order('created_at desc')
      else
        @person_issues_logs = PersonIssuesLog.where("sub_entity_code = '#{params[:branch_code]}'").paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
      end

    end
  end
  # POST /person_issues_logs or /person_issues_logs.json
  def create_reply_person
    @person_issues_log_tracker = PersonIssuesLogTracker.new(person_issues_log_tracker_params)
    flash.now[:notice] = "Response successfully sent."

    respond_to do |format|
      if @person_issues_log_tracker.valid?
        user_id = person_issues_log_tracker_params[:user_id].present? ? person_issues_log_tracker_params[:user_id] : nil
        person_assigned_code = person_issues_log_tracker_params[:person_assigned_code].present? ? person_issues_log_tracker_params[:person_assigned_code] : nil
        person_issues_log_id = person_issues_log_tracker_params[:person_issues_log_id].present? ? person_issues_log_tracker_params[:person_issues_log_id] : nil
        comment = person_issues_log_tracker_params[:comment].present? ? person_issues_log_tracker_params[:comment] : nil
        @person_issues_log_tracker = PersonIssuesLogTracker.new(person_issues_log_id: person_issues_log_id, user_id: user_id, person_assigned_code: person_assigned_code, comment: comment)
        @person_issues_log_tracker.save(validate: false)

        person_issues_index
        format.js { render "/person_issues_log_trackers/person_issues_index" }
        format.html { redirect_to person_issues_logs_path, notice: 'Response successfully sent.' }
        format.json { render :person_issues_index, status: :created, location: @person_issues_log_tracker }
      else
        # Populates page with data from table
        @person_issues_log = PersonIssuesLog.find(params[:reply_id])
        logger.info "Person Error Messages :: #{@person_issues_log_tracker.errors.messages.inspect}"
        format.js { render :new_reply }
        format.html {render :new}
        format.json { render json: @person_issues_log_tracker.errors, status: :unprocessable_entity }
      end
    end
  end


  # GET /person_issues_log_trackers/1 or /person_issues_log_trackers/1.json
  def show
  end

  # GET /person_issues_log_trackers/new
  def new_reply
    @person_issues_log_tracker = PersonIssuesLogTracker.new

    @person_issues_log = PersonIssuesLog.find(params[:reply_id])
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_person_issues_log_tracker
      # @person_issues_log_tracker = PersonIssuesLogTracker.find(params[:id])

      @person_issues_log = PersonIssuesLog.where(active_status: true, assigned_code: params[:id]).order(created_at: :asc).first
    end

    # Only allow a list of trusted parameters through.
    def person_issues_log_tracker_params
      params.require(:person_issues_log_tracker).permit(:person_issues_log_id, :comment, :person_assigned_code, :sub_entity_code, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
