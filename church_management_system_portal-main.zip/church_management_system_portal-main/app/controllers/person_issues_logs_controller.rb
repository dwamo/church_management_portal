class PersonIssuesLogsController < ApplicationController
  before_action :set_person_issues_log, only: %i[ show edit update destroy ]

  # GET /person_issues_logs or /person_issues_logs.json
  def index
    # @person_issues_logs = PersonIssuesLog.all

  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_person_issues_log
      @person_issues_log = PersonIssuesLog.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def person_issues_log_params
      params.require(:person_issues_log).permit(:person_assigned_code, :comment, :sub_entity_code, :issues_log_type_id, :user_id)
    end
end
