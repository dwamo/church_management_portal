class PersonRelationInfosController < ApplicationController
  before_action :set_person_relation_info, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /person_relation_infos or /person_relation_infos.json
  def index
    @person_relation_infos = PersonRelationInfo.all
  end

  # GET /person_relation_infos/1 or /person_relation_infos/1.json
  def show
  end

  # GET /person_relation_infos/new
  def new
    @person_relation_info = PersonRelationInfo.new
  end

  # GET /person_relation_infos/1/edit
  def edit
  end

  # POST /person_relation_infos or /person_relation_infos.json
  def create
    @person_relation_info = PersonRelationInfo.new(person_relation_info_params)

    respond_to do |format|
      if @person_relation_info.save
        format.html { redirect_to @person_relation_info, notice: "Person relation info was successfully created." }
        format.json { render :show, status: :created, location: @person_relation_info }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @person_relation_info.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /person_relation_infos/1 or /person_relation_infos/1.json
  def update
    respond_to do |format|
      if @person_relation_info.update(person_relation_info_params)
        format.html { redirect_to @person_relation_info, notice: "Person relation info was successfully updated." }
        format.json { render :show, status: :ok, location: @person_relation_info }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @person_relation_info.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /person_relation_infos/1 or /person_relation_infos/1.json
  def destroy
    @person_relation_info.destroy
    respond_to do |format|
      format.html { redirect_to person_relation_infos_url, notice: "Person relation info was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_person_relation_info
      @person_relation_info = PersonRelationInfo.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def person_relation_info_params
      params.require(:person_relation_info).permit(:person_assigned_code, :relation_person_code, :relation_last_name, :relation_first_name, :relation_other_names, :relationship_code, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
