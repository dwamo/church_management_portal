class PersonRoleMastersController < ApplicationController
  before_action :set_person_role_master, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource

  def index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.super_admin? || current_user.user_admin?
      @person_role_masters = PersonRoleMaster.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @entity_name_search = EntityInfo.where(del_status: false).order(entity_name: :desc)
      @role_desc_search = PersonRoleMaster.where(active_status: true).order(role_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

    elsif current_user.merchant_admin?
      params[:main_code] = current_user.user_main_code

      @person_role_masters = PersonRoleMaster.where(entity_code: params[:main_code], del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @role_desc_search = PersonRoleMaster.where(entity_code: params[:main_code], active_status: true).order(role_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true AND ur.main_code = '#{params[:main_code]}'").order(username: :desc)
    end
  end

  def person_role_masters_index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    if current_user.super_admin? || current_user.user_admin?
      @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
      @role_desc_search = PersonRoleMaster.where(active_status: true).order(role_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)
      @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
      the_search = ""
      search_arr = ["active_status = true"]
    elsif current_user.merchant_admin?
      params[:main_code] = current_user.user_main_code

      @role_desc_search = PersonRoleMaster.where(entity_code: params[:main_code], active_status: true).order(role_desc: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true AND ur.main_code = '#{params[:main_code]}'").order(username: :desc)
      the_search = ""
      search_arr = ["entity_code = '#{params[:main_code]}' AND active_status = true"]
    end

    if params[:filter_main].present? || params[:assigned_code].present? || params[:entity_code].present? || params[:active_status].present? || params[:birth_date].present? || params[:gender].present? || params[:role_desc].present? || params[:first_name].present? || params[:user_id].present? || params[:start_date].present? || params[:end_date].present?
      filter_params = params[:filter_main]
      if params[:filter_main].present?
        @assigned_code = filter_params[:assigned_code]
        @entity_code = filter_params[:entity_code]
        @active_status = filter_params[:active_status]
        @role_desc = filter_params[:role_desc]
        @username = filter_params[:user_id]
        @start_date = filter_params[:start_date]
        @end_date = filter_params[:end_date]

        params[:assigned_code] = filter_params[:assigned_code]
        params[:entity_code] = filter_params[:entity_code]
        params[:active_status] = filter_params[:active_status]
        params[:role_desc] = filter_params[:role_desc]
        params[:user_id] = filter_params[:user_id]
        params[:start_date] = filter_params[:start_date]
        params[:end_date] = filter_params[:end_date]

      else

        if params[:assigned_code].present? || params[:entity_code].present? || params[:active_status].present? || params[:birth_date].present? || params[:gender].present? || params[:role_desc].present? || params[:first_name].present? || params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

          @assigned_code = params[:assigned_code]
          @entity_code = params[:entity_code]
          @active_status = params[:active_status]
          @role_desc = params[:role_desc]
          @username = params[:user_id]
          @start_date = params[:start_date]
          @end_date = params[:end_date]

          params[:assigned_code] = @assigned_code
          params[:entity_code] = @entity_code
          params[:active_status] = @active_status
          params[:role_desc] = @role_desc
          params[:user_id] = @susername
          params[:start_date] = @start_date
          params[:end_date] = @end_date

        else
          params[:assigned_code] = filter_params[:assigned_code]
          params[:entity_code] = filter_params[:entity_code]
          params[:active_status] = filter_params[:active_status]
          params[:role_desc] = filter_params[:role_desc]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        end
      end

      if @assigned_code.present?
        #search_arr << "customer_number LIKE '%#{@cust_num}%'"
        search_arr << "assigned_code = '#{@assigned_code}'"
      end

      if @entity_code.present?
        search_arr << "entity_code = '#{@entity_code}'"
      end

      if @active_status.present?
        search_arr << "active_status = '#{@active_status}'"
      end

      if @role_desc.present?
        search_arr << "role_desc = '#{@role_desc}'"
      end

      if @username.present?
        search_arr << "user_id = '#{@username}'"
      end

      if @start_date.present? && @end_date.present?
        f_start_date = @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
        f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
        if f_start_date <= f_end_date
          search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
        end
      end

    else
    end

    the_search = search_arr.join(" AND ")
    logger.info "The search array :: #{search_arr.inspect}"
    logger.info "The Search :: #{the_search.inspect}"
    if params[:count] == "All"
      @person_role_masters = PersonRoleMaster.order('created_at desc')
      saved_size = @person_role_masters.exists? ? @person_role_masters.size : 0
      @person_role_masters = PersonRoleMaster.where(the_search).paginate(page: 1, per_page: saved_size).order("id desc")
    else
      @person_role_masters = PersonRoleMaster.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
  end

  def show
  end

  def new
    params[:main_code] = current_user.user_main_code
    @entity_info_search = EntityInfo.where(del_status: false, active_status: true).order(entity_name: :desc)
    @person_role_master = PersonRoleMaster.new
  end

  def edit
    params[:main_code] = current_user.user_main_code
    @entity_info_search = EntityInfo.where(del_status: false).order(entity_name: :desc)
  end

  def create
    @person_role_master = PersonRoleMaster.new(person_role_master_params)

    respond_to do |format|
      if @person_role_master.valid?
        assigned_code = PersonRoleMaster.gen_person_role_code
        @person_role_master.assigned_code = assigned_code
        @person_role_master.save
        person_role_masters_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Person's role master was successfully created."

        format.js { render "/person_role_masters/person_role_masters_index" }
        format.html { redirect_to entity_info_path(id: @person_role_master.id), notice: 'Person role master was successfully created.' }
        format.json { render :index, status: :created, location: @person_role_master }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @person_role_master.errors, status: :unprocessable_entity }
      end
    end
  end

  def update
    respond_to do |format|
      @person_role_master = PersonRoleMaster.where(active_status: true, assigned_code: params[:id]).order(created_at: :desc).first
      flash.now[:notice] = "Person's role updated successfully."

      logger.info params[:person_role_master].inspect
      @new_record = PersonRoleMaster.new(person_role_master_params)

      @new_record.assigned_code = @person_role_master.assigned_code
      if @new_record.valid?
        @person_role_master.active_status = false
        @person_role_master.del_status = true
        @person_role_master.save(validate: false)
        if @new_record.save
        else
          # EntityDivision.update_last_but_one("person_role_masters", @person_role_master.entity_code , prev_updated_at)
        end
        person_role_masters_index
        format.js { render "/person_role_masters/person_role_masters_index" }
        format.html { redirect_to person_role_masters_path, notice: "Person's role updated successfully." }
        format.json { render :person_role_masters_index, status: :ok, location: @person_role_master }
      else
        logger.info "Person's role Error Messages Edit :: #{@new_record.errors.messages.inspect}"

        format.html { render :edit }
        format.js { render :edit }
        format.json { render json: @person_role_master.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    @person_role_master.destroy
    respond_to do |format|
      format.html { redirect_to person_role_masters_url, notice: "Person role was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private

  # Use callbacks to share common setup or constraints between actions.
  def set_person_role_master
    @person_role_master = PersonRoleMaster.find(params[:id])
  end

  # Only allow a list of trusted parameters through.
  def person_role_master_params
    params.require(:person_role_master).permit(:assigned_code, :entity_code, :role_desc, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
  end
end
