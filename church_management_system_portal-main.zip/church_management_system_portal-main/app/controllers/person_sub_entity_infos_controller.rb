class PersonSubEntityInfosController < ApplicationController
  before_action :set_person_sub_entity_info, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /person_sub_entity_infos or /person_sub_entity_infos.json
  def index
    @person_sub_entity_infos = PersonSubEntityInfo.all
  end

  # GET /person_sub_entity_infos/1 or /person_sub_entity_infos/1.json
  def show
  end

  # GET /person_sub_entity_infos/new
  def new
    @person_sub_entity_info = PersonSubEntityInfo.new
  end

  # GET /person_sub_entity_infos/1/edit
  def edit
  end

  # POST /person_sub_entity_infos or /person_sub_entity_infos.json
  def create
    @person_sub_entity_info = PersonSubEntityInfo.new(person_sub_entity_info_params)

    respond_to do |format|
      if @person_sub_entity_info.save
        format.html { redirect_to @person_sub_entity_info, notice: "Person sub entity info was successfully created." }
        format.json { render :show, status: :created, location: @person_sub_entity_info }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @person_sub_entity_info.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /person_sub_entity_infos/1 or /person_sub_entity_infos/1.json
  def update
    respond_to do |format|
      if @person_sub_entity_info.update(person_sub_entity_info_params)
        format.html { redirect_to @person_sub_entity_info, notice: "Person sub entity info was successfully updated." }
        format.json { render :show, status: :ok, location: @person_sub_entity_info }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @person_sub_entity_info.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /person_sub_entity_infos/1 or /person_sub_entity_infos/1.json
  def destroy
    @person_sub_entity_info.destroy
    respond_to do |format|
      format.html { redirect_to person_sub_entity_infos_url, notice: "Person sub entity info was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_person_sub_entity_info
      @person_sub_entity_info = PersonSubEntityInfo.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def person_sub_entity_info_params
      params.require(:person_sub_entity_info).permit(:person_assigned_code, :sub_entity_code, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
