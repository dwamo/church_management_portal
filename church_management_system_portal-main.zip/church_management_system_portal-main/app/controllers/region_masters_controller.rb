class RegionMastersController < ApplicationController
  before_action :set_region_master, only: [:show, :edit, :update, :destroy]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /region_masters or /region_masters.json
  def index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @region_masters = RegionMaster.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    @city_town_masters = CityTownMaster.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

    @region_desc_search = RegionMaster.where(del_status: false).order(region_desc: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)
    @city_town_name_search = CityTownMaster.where(del_status: false).order(city_town_name: :desc)
  end

  def region_masters_index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @region_desc_search = RegionMaster.where(del_status: false).order(region_desc: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

    if params[:count] == "All"
      @region_masters = RegionMaster.where(active_status: true).order('created_at desc')
      saved_size = @region_masters.exists? ? @region_masters.size : 0
      @region_masters = RegionMaster.where(active_status: true).paginate(page: 1, per_page: saved_size).order("id desc")
    else

      the_search = ""
      search_arr = ["del_status = false"]

      if params[:filter_main].present? || params[:region_desc].present? || params[:entity_alias].present? || params[:active_status].present? || params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?

        $merchant_filter = params[:filter_main]
        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @region_desc = filter_params[:region_desc]
          @entity_alias = filter_params[:entity_alias]
          @active_status = filter_params[:active_status]
          @username = filter_params[:user_id]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:region_desc] = filter_params[:region_desc]
          params[:entity_alias] = filter_params[:entity_alias]
          params[:active_status] = filter_params[:active_status]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        else

          if  params[:region_desc].present? || params[:entity_alias].present? || params[:active_status].present?|| params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

            @region_desc = params[:region_desc]
            @entity_alias = params[:entity_alias]
            @active_status = params[:active_status]
            @username = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:region_desc] = @region_desc
            params[:entity_alias] = @entity_alias
            params[:active_status] = @active_status
            params[:user_id] = @username
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:region_desc] = filter_params[:region_desc]
            params[:entity_alias] = filter_params[:entity_alias]
            params[:active_status] = filter_params[:active_status]
            params[:user_id] = filter_params[:user_id]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          end
        end

        if @region_desc.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "region_desc = '#{@region_desc}'"
        end

        if @entity_alias.present?
          search_arr << "entity_alias = '#{@entity_alias}'"
        end

        if @active_status.present?
          search_arr << "active_status = '#{@active_status}'"
        end

        if @username.present?
          search_arr << "user_id = '#{@username}'"
        end

        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
        $merchant_filter = ""
      end


      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"


      @region_masters = RegionMaster.where(del_status: false).where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
    
  end
  # GET /region_masters/1 or /region_masters/1.json
  def show
  end

  # GET /region_masters/new
  def new
    @region_master = RegionMaster.new
  end

  # GET /region_masters/1/edit
  def edit
  end

  # POST /region_masters or /region_masters.json
  def create
    @region_master = RegionMaster.new(region_master_params)

    respond_to do |format|
      if @region_master.valid?
        @region_master.save
        region_masters_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Region was successfully created."

        format.js { render "/region_masters/region_masters_index" }
        format.html { redirect_to region_masters_path(id: @region_master.id), notice: 'Region was successfully created.' }
        format.json { render :index, status: :created, location: @region_master }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @region_master.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /region_masters/1 or /region_masters/1.json
  def update
    respond_to do |format|
      if @region_master.update(region_master_params)
        region_masters_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Region was updated successfully."

        format.js { render "/region_masters/region_masters_index" }
        format.html { redirect_to region_masters_path(id: @region_master.id)}
        format.json { render :region_master_index, status: :ok, location: @region_master }

      else
        format.js { render :edit }
        format.html { render :edit }
        format.json { render json: @region_master.errors, status: :unprocessable_entity }
      end
    end
  end
  # DELETE /region_masters/1 or /region_masters/1.json
  def destroy
    @region_master.destroy
    respond_to do |format|
      format.html { redirect_to region_masters_url, notice: "Region master was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_region_master
      @region_master = RegionMaster.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def region_master_params
      params.require(:region_master).permit(:region_code, :region_desc, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
