class RelationshipMastersController < ApplicationController
  before_action :set_relationship_master, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource
  
  # GET /relationship_masters or /relationship_masters.json
  def index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @relationship_masters = RelationshipMaster.where(del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

    @relationship_search = RelationshipMaster.where(active_status: true).order(relationship_desc: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)
  end

  def relationship_masters_index
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1

    @relationship_search = RelationshipMaster.where(active_status: true).order(relationship_desc: :desc)
    @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

    if params[:count] == "All"
      @relationship_masters = RelationshipMaster.where(active_status: true).order('created_at desc')
      saved_size = @relationship_masters.exists? ? @relationship_masters.size : 0
      @relationship_masters = RelationshipMaster.where(active_status: true).paginate(page: 1, per_page: saved_size).order("id desc")
    else

      search_arr = ["active_status = true"]
      the_search = ""

      if params[:filter_main].present? || params[:assigned_code].present? || params[:active_status].present?|| params[:birth_date].present?|| params[:gender].present?|| params[:relationship_desc].present?|| params[:first_name].present? || params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?

        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @assigned_code = filter_params[:assigned_code]
          @active_status = filter_params[:active_status]
          @relationship_desc = filter_params[:relationship_desc]
          @username = filter_params[:user_id]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:assigned_code] = filter_params[:assigned_code]
          params[:active_status] = filter_params[:active_status]
          params[:relationship_desc] = filter_params[:relationship_desc]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        else

          if  params[:assigned_code].present? || params[:active_status].present?|| params[:birth_date].present?|| params[:gender].present?|| params[:relationship_desc].present?|| params[:first_name].present?|| params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

            @assigned_code = params[:assigned_code]
            @active_status = params[:active_status]
            @relationship_desc = params[:relationship_desc]
            @username = params[:user_id]
            @start_date = params[:start_date]
            @end_date = params[:end_date]

            params[:assigned_code] = @assigned_code
            params[:active_status] = @active_status
            params[:relationship_desc] = @relationship_desc
            params[:user_id] = @susername
            params[:start_date] = @start_date
            params[:end_date] = @end_date

          else
            params[:assigned_code] = filter_params[:assigned_code]
            params[:active_status] = filter_params[:active_status]
            params[:relationship_desc] = filter_params[:relationship_desc]
            params[:user_id] = filter_params[:user_id]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          end
        end

        if @assigned_code.present?
          #search_arr << "customer_number LIKE '%#{@cust_num}%'"
          search_arr << "assigned_code = '#{@assigned_code}'"
        end
        if @active_status.present?
          search_arr << "active_status = '#{@active_status}'"
        end

        if @relationship_desc.present?
          search_arr << "relationship_desc = '#{@relationship_desc}'"
        end

        if @username.present?
          search_arr << "user_id = '#{@username}'"
        end

        if @start_date.present? && @end_date.present?
          f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
          f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
          if f_start_date <= f_end_date
            search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          end
        end

      else
      end

      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"

      @relationship_masters = RelationshipMaster.where(del_status: false).where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
  end
  
  # GET /relationship_masters/1 or /relationship_masters/1.json
  def show
  end

  # GET /relationship_masters/new
  def new
    @relationship_master = RelationshipMaster.new
  end

  # GET /relationship_masters/1/edit
  def edit
  end

  # POST /relationship_masters or /relationship_masters.json
  def create
    @relationship_master = RelationshipMaster.new(relationship_master_params)

    respond_to do |format|
      if @relationship_master.valid?
        @relationship_master.save
        relationship_masters_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Relationship was successfully created."

        format.js { render "/relationship_masters/relationship_masters_index" }
        format.html { redirect_to relationship_masters_path(id: @relationship_master.id), notice: 'Relationship was successfully created.' }
        format.json { render :index, status: :created, location: @relationship_master }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @relationship_master.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /relationship_masters/1 or /relationship_masters/1.json
  def update
    respond_to do |format|
      if @relationship_master.update(relationship_master_params)
        relationship_masters_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Relationship was updated successfully."

        format.js { render "/relationship_masters/relationship_masters_index" }
        format.html { redirect_to relationship_masters_path(id: @relationship_master.id)}
        format.json { render :relationship_masters_index, status: :ok, location: @relationship_master }

      else
        format.js { render :edit }
        format.html { render :edit }
        format.json { render json: @relationship_master.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /relationship_masters/1 or /relationship_masters/1.json
  def destroy
    @relationship_master.destroy
    respond_to do |format|
      format.html { redirect_to relationship_masters_url, notice: "Relationship master was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_relationship_master
      @relationship_master = RelationshipMaster.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def relationship_master_params
      params.require(:relationship_master).permit(:assigned_code, :relationship_desc, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at)
    end
end
