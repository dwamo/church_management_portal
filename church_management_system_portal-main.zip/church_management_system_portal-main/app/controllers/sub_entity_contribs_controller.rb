class SubEntityContribsController < ApplicationController
  before_action :set_sub_entity_contrib, only: %i[ show edit update destroy ]
  before_action :load_permissions
  load_and_authorize_resource

  # GET /sub_entity_contribs or /sub_entity_contribs.json
  def sub_entity_contribs_index
      params[:count] ? params[:count] : params[:count] = 20
      params[:page] ? params[:page] : params[:page] = 1

      @contrib_types = ContribType.where(assigned_code: params[:contribution_type_code], del_status: false)
      @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)

      if current_user.super_admin? || current_user.user_admin?
        @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :desc)
        @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)

        the_search = ""
        search_arr = ["contribution_type_code = '#{params[:contribution_type_code]}' AND del_status = false"]

      elsif current_user.merchant_admin?
        params[:main_code] = current_user.user_main_code
        @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :desc)
        @user_search = User.unscoped.user_join.where("ur.active_status = true AND main_code = '#{params[:main_code]}'").order(username: :desc)

        the_search = ""
        search_arr = ["contribution_type_code = '#{params[:contribution_type_code]}' AND del_status = false"]

      elsif current_user.division_admin?
        params[:div_code] = current_user.div_code
        @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :desc)
        @user_search = User.unscoped.user_join.where("ur.active_status = true AND div_code = '#{params[:div_code]}'").order(username: :desc)

        the_search = ""
        search_arr = ["contribution_type_code = '#{params[:contribution_type_code]}' AND del_status = false"]

      elsif current_user.branch_admin?
        params[:branch_code] = current_user.user_branch_code
        @entity_info_search = EntityInfo.where(sub_entity_code: params[:branch_code], active_status: true).order(entity_name: :desc)

        the_search = ""
        search_arr = ["contribution_type_code = '#{params[:contribution_type_code]}' AND del_status = false AND sub_entity_code = '#{params[:branch_code]}'"]

      end

        if params[:filter_main].present? || params[:sub_entity_code].present? || params[:amount].present? || params[:active_status].present?|| params[:contribution_name].present?|| params[:user_id].present?|| params[:start_date].present? || params[:created_start].present? || params[:created_end].present? || params[:end_date].present?

          filter_params = params[:filter_main]
          if params[:filter_main].present?
            @sub_entity_code = filter_params[:sub_entity_code]
            @amount = filter_params[:amount]
            @active_status = filter_params[:active_status]
            @contribution_name = filter_params[:contribution_name]
            @username = filter_params[:user_id]
            @created_start = filter_params[:created_start]
            @created_end = filter_params[:created_end]
            @start_date = filter_params[:start_date]
            @end_date = filter_params[:end_date]

            params[:sub_entity_code] = filter_params[:sub_entity_code]
            params[:amount] = filter_params[:amount]
            params[:active_status] = filter_params[:active_status]
            params[:contribution_name] = filter_params[:contribution_name]
            params[:user_id] = filter_params[:user_id]
            params[:created_start] = filter_params[:created_start]
            params[:created_end] = filter_params[:created_end]
            params[:start_date] = filter_params[:start_date]
            params[:end_date] = filter_params[:end_date]

          else

            if  params[:sub_entity_code].present? || params[:amount].present? || params[:active_status].present? || params[:contribution_name].present?|| params[:user_id].present? || params[:start_date].present? || params[:created_start].present? || params[:created_end].present? || params[:end_date].present?

              @sub_entity_code = params[:sub_entity_code]
              @amount = params[:amount]
              @active_status = params[:active_status]
              @contribution_name = params[:contribution_name]
              @username = params[:user_id]
              @created_start = params[:created_start]
              @created_end = params[:created_end]
              @start_date = params[:start_date]
              @end_date = params[:end_date]

              params[:sub_entity_code] = @sub_entity_code
              params[:amount] = @amount
              params[:active_status] = @active_status
              params[:contribution_name] = @contribution_name
              params[:user_id] = @susername
              params[:created_start] = @created_start
              params[:created_end] = @created_end
              params[:start_date] = @start_date
              params[:end_date] = @end_date

            else
              params[:sub_entity_code] = filter_params[:sub_entity_code]
              params[:amount] = filter_params[:amount]
              params[:active_status] = filter_params[:active_status]
              params[:contribution_name] = filter_params[:contribution_name]
              params[:user_id] = filter_params[:user_id]
              params[:created_start] = filter_params[:created_start]
              params[:created_end] = filter_params[:created_end]
              params[:start_date] = filter_params[:start_date]
              params[:end_date] = filter_params[:end_date]

            end
          end

          if @sub_entity_code.present?
            #search_arr << "customer_number LIKE '%#{@cust_num}%'"
            search_arr << "sub_entity_code = '#{@sub_entity_code}'"
          end
          if @amount.present?
            #search_arr << "customer_number LIKE '%#{@cust_num}%'"
            search_arr << "amount = '#{@amount}'"
          end
          if @active_status.present?
            search_arr << "active_status = '#{@active_status}'"
          end
          if @contribution_name.present?
            search_arr << "contribution_name = '#{@contribution_name}'"
          end
          if @username.present?
            search_arr << "user_id = '#{@username}'"
            end
          if @start_date.present?
            search_arr << "start_date = '#{@start_date}'"
          end
          if @end_date.present?
            search_arr << "end_date = '#{@end_date}'"
          end
         if @created_start.present? && @created_end.present?
            f_start_date =  @created_start.to_date.strftime('%Y-%m-%d')
            f_end_date = @created_end.to_date.strftime('%Y-%m-%d')
            if f_start_date <= f_end_date
              search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
            end
          end
          # if @start_date.present? && @end_date.present?
          #   f_start_date =  @start_date.to_date.strftime('%Y-%m-%d')
          #   f_end_date = @end_date.to_date.strftime('%Y-%m-%d')
          #   if f_start_date <= f_end_date
          #     search_arr << "Contribution BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
          #   end
          # end
        else
        end

        the_search = search_arr.join(" AND ")
        logger.info "The search array :: #{search_arr.inspect}"
        logger.info "The Search :: #{the_search.inspect}"
      if params[:count] == "All"
        saved_size = @sub_entity_contribs.exists? ? @sub_entity_contribs.size : 0
        @sub_entity_contribs = SubEntityContrib.where(the_search).paginate(:page => 1, :per_page => saved_size).order('created_at desc')
      else
        @sub_entity_contribs = SubEntityContrib.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
      end
  end
  # GET /sub_entity_contribs/1 or /sub_entity_contribs/1.json
  def show
  end

  # GET /sub_entity_contribs/new
  def new
    # @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)

    if current_user.super_admin? || current_user.user_admin?
      @division_name_search = EntityDivision.where(entity_code: params[:church_code], active_status: true).order(division_name: :desc)
      @sub_entity_name_search = SubEntityInfo.where(del_status: false).order(sub_entity_name: :desc)
    elsif current_user.merchant_admin?
      params[:main_code] = current_user.user_main_code
      @sub_entity_name_search = SubEntityInfo.where(entity_code: params[:main_code], del_status: false).order(sub_entity_name: :desc)
      @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :desc)

    elsif current_user.division_admin?
      params[:div_code] = current_user.user_div_code
      @sub_entity_name_search = SubEntityInfo.where(entity_division_code: params[:div_code], active_status: true).order(sub_entity_name: :desc)
      @sub_division_desc_search = EntitySubDivision.where(entity_division_code: params[:div_code], del_status: false).order(sub_division_desc: :asc)

    elsif current_user.branch_admin?
      params[:branch_code] = current_user.user_branch_code
      @sub_entity_name_search = SubEntityInfo.where(assigned_code: params[:branch_code], del_status: false).order(sub_entity_name: :desc)
      @contribution_search = SubEntityContrib.where(sub_entity_code: params[:branch_code], active_status: true).order(contribution_name: :desc)
    else
    end

    @sub_entity_contrib = SubEntityContrib.new

  end

  # GET /sub_entity_contribs/1/edit
  def edit
    if current_user.super_admin? || current_user.user_admin?
      # @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
      @division_name_search = EntityDivision.where(entity_code: params[:church_code], active_status: true).order(division_name: :desc)
      @sub_entity_name_search = SubEntityInfo.where(entity_code: params[:church_code], del_status: false).order(sub_entity_name: :desc)
      @sub_division_desc_search = EntitySubDivision.where(del_status: false).order(sub_division_desc: :asc)
      @sub_entity_name_search = SubEntityInfo.where(del_status: false).order(sub_entity_name: :desc)


      @contribution_search = SubEntityContrib.where(active_status: true).order(contribution_name: :desc)
    elsif current_user.merchant_admin?
      params[:main_code] = current_user.user_main_code
      @sub_entity_name_search = SubEntityInfo.where(entity_code: params[:main_code], del_status: false).order(sub_entity_name: :desc)
      @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :desc)
      @sub_division_desc_search = EntitySubDivision.where(del_status: false).order(sub_division_desc: :asc)

    elsif current_user.division_admin?
      params[:div_code] = current_user.user_div_code
      @sub_entity_name_search = SubEntityInfo.where(entity_division_code: params[:div_code], active_status: true).order(sub_entity_name: :desc)
      @division_name_search = EntityDivision.where(assigned_code: params[:div_code], active_status: true).order(division_name: :desc)
      @sub_division_desc_search = EntitySubDivision.where(entity_division_code: params[:div_code], del_status: false).order(sub_division_desc: :asc)

    elsif current_user.branch_admin?
      params[:branch_code] = current_user.user_branch_code
      @sub_entity_name_search = SubEntityInfo.where(assigned_code: params[:branch_code], active_status: true).order(sub_entity_name: :desc)
      @sub_division_desc_search = EntitySubDivision.where(entity_division_code: params[:div_code], del_status: false).order(sub_division_desc: :asc)
      @contribution_search = SubEntityContrib.where(sub_entity_code: params[:branch_code], active_status: true).order(contribution_name: :desc)
    else
    end
    @sub_entity_contrib.start_date = @sub_entity_contrib.start_date.strftime('%Y-%m-%d') if @sub_entity_contrib.start_date != nil
    @sub_entity_contrib.end_date = @sub_entity_contrib.end_date.strftime('%Y-%m-%d') if @sub_entity_contrib.end_date != nil

  end

  # POST /sub_entity_contribs or /sub_entity_contribs.json
  def create
    @sub_entity_contrib = SubEntityContrib.new(sub_entity_contrib_params)
    # div_code = SubEntityContrib.gen_div_code
    respond_to do |format|
      if @sub_entity_contrib.valid?
        # @sub_entity_contrib.assigned_code = div_code
        @sub_entity_contrib.save(validate: false)
        sub_entity_contribs_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "Sub Entity Contrib was successfully created."
        format.js { render "/sub_entity_contribs/sub_entity_contribs_index" }
        format.html { redirect_to sub_entity_contribs_path(id: @sub_entity_contrib.id), notice: 'Sub Entity Contrib was successfully created.' }
        format.json { render :index, status: :created, location: @sub_entity_contrib }
      else
        format.js { render :new }
        format.html { render :new }
        format.json { render json: @sub_entity_contrib.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /sub_entity_contribs/1 or /sub_entity_contribs/1.json
  def update
    respond_to do |format|
      @sub_entity_contrib = SubEntityContrib.where(active_status: true, id: params[:id]).order(created_at: :desc).first
      flash.now[:notice] = "Sub Entity Contrib was updated successfully."

      logger.info params[:sub_entity_contrib].inspect
      @new_record = SubEntityContrib.new(sub_entity_contrib_params)

      # @new_record.assigned_code = @sub_entity_contrib.assigned_code
      if @new_record.valid?
        @sub_entity_contrib.active_status = false
        @sub_entity_contrib.del_status = true
        @sub_entity_contrib.save(validate: false)
        if @new_record.save
        else
          # SubEntityContrib.update_last_but_one("sub_entity_contribs", @sub_entity_contrib.entity_code , prev_updated_at)
        end
        sub_entity_contribs_index
        format.js { render "/sub_entity_contribs/sub_entity_contribs_index" }
        format.html { redirect_to sub_entity_contribs_path, notice: 'Sub Entity Contrib was updated successfully.' }
        format.json { render :sub_entity_contribs_index, status: :ok, location: @sub_entity_contrib }
      else
        logger.info "Division Error Messages Edit :: #{@new_record.errors.messages.inspect}"

        format.html {render :edit}
        format.js { render :edit }
        format.json { render json: @sub_entity_contrib.errors, status: :unprocessable_entity }

        if current_user.super_admin? || current_user.user_admin?
          @sub_entity_name_search = SubEntityInfo.where(del_status: false).order(sub_entity_name: :desc)
        elsif current_user.merchant_admin?
          @sub_entity_name_search = SubEntityInfo.where(entity_code: params[:contribution_code], del_status: false).order(sub_entity_name: :desc)
        elsif current_user.division_admin?
          @sub_entity_name_search = SubEntityInfo.where(entity_code: params[:main_code], del_status: false).order(sub_entity_name: :desc)
        else
        end
        @sub_entity_contrib.start_date = @sub_entity_contrib.start_date.strftime('%Y-%m-%d') if @sub_entity_contrib.start_date != nil
        @sub_entity_contrib.end_date = @sub_entity_contrib.end_date.strftime('%Y-%m-%d') if @sub_entity_contrib.end_date != nil
      end
    end
  end

  def contrib_update1
    logger.info "Params:: #{params[:id_for_entity_info].inspect}"
    if params[:id_for_entity_info].empty?
      @info_update_division = [["", ""]].insert(0, ['Please select a Division', ""])
    else
      info_update_division = EntityDivision.where(entity_code: params[:id_for_entity_info], active_status: true).order(division_name: :desc).map { |a| [a.division_name, a.id] }.insert(0, ['Please select a Division', ""])
      @info_update_division = info_update_division.empty? ? [["", ""]].insert(0, ['Please select a Division', ""]) : info_update_division
    end
    logger.info "For Entity Division :: #{@info_update_division.inspect}"
  end

  def contrib_update2
    if params[:id_for_division].empty?
      @division_update_sub_division = [["", ""]].insert(0, ['Please select a Sub Division', ""])
    else
      division_update_sub_division = EntitySubDivision.where(entity_division_code: params[:id_for_division], active_status: true).order(sub_division_desc: :desc).map { |a| [a.sub_division_desc, a.id] }.insert(0, ['Please select a Sub Division', ""])
      @division_update_sub_division = division_update_sub_division.empty? ? [["", ""]].insert(0, ['Please select a Sub Division', ""]) : division_update_sub_division
    end
    logger.info "For Sub Division :: #{@division_update_sub_division.inspect}"
  end

  def contrib_update3
    if params[:id_for_sub_div].empty?
      @sub_division_update_sub_entity = [["", ""]].insert(0, ['Please select a Branch', ""])
    else
      sub_division_update_sub_entity = SubEntityInfo.where(entity_sub_div_code: params[:id_for_sub_div], active_status: true).order(sub_entity_name: :desc).map { |a| [a.sub_entity_name, a.id] }.insert(0, ['Please select a Branch', ""])
      @sub_division_update_sub_entity = sub_division_update_sub_entity.empty? ? [["", ""]].insert(0, ['Please select a Branch', ""]) : sub_division_update_sub_entity
    end
    logger.info "For Branch :: #{@sub_division_update_sub_entity.inspect}"
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_sub_entity_contrib
      @sub_entity_contrib = SubEntityContrib.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def sub_entity_contrib_params
      params.require(:sub_entity_contrib).permit(:sub_entity_code, :contribution_type_code, :contribution_name, :contribution_alias, :amount, :start_date, :end_date, :comment, :active_status, :del_status, :user_id, :created_at, :updated_at, :entity_division_code, :entity_info_code, :entity_sub_div_code)
    end
end
