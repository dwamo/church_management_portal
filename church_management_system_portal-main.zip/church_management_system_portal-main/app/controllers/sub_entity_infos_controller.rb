class SubEntityInfosController < ApplicationController
  before_action :set_sub_entity_info, only: [ :show, :edit, :update, :destroy, :edit_sub_entity, :edit_sub_entity2, :admin_branch_update ]
  before_action :load_permissions
  load_and_authorize_resource

  # GET /sub_entity_infos or /sub_entity_infos.json
 def index
      params[:count] ? params[:count] : params[:count] = 20
      params[:page] ? params[:page] : params[:page] = 1
      params[:div_code] = current_user.user_div_code
      params[:main_code] = current_user.user_main_code

    if current_user.merchant_admin?
      @sub_entity_infos = SubEntityInfo.where(entity_code: params[:main_code], del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @sub_entity_name_search = SubEntityInfo.where(entity_code: params[:main_code], del_status: false).order(sub_entity_name: :desc)
      @sub_entity_alias_search = SubEntityInfo.where(entity_code: params[:main_code], del_status: false).order(sub_entity_alias: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true AND main_code = '#{params[:main_code]}'").order(username: :desc)

      @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :desc)

    elsif current_user.division_admin?
      @sub_entity_infos = SubEntityInfo.where(entity_division_code: params[:div_code], del_status: false).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')

      @sub_entity_name_search = SubEntityInfo.where(entity_division_code: params[:div_code], active_status: true).order(sub_entity_name: :desc)
      @sub_entity_alias_search = SubEntityInfo.where(entity_division_code: params[:div_code], active_status: true).order(sub_entity_alias: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true AND div_code = '#{params[:div_code]}'").order(username: :desc)
      @division_name_search = EntityDivision.where(assigned_code: params[:div_code], active_status: true).order(division_name: :desc)
    else
    end
  end

  def sub_entity_infos_index
      params[:count] ? params[:count] : params[:count] = 20
      params[:page] ? params[:page] : params[:page] = 1

      @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)

      @sub_entity_name_search = SubEntityInfo.where(del_status: false).order(sub_entity_name: :desc)
      @sub_entity_alias_search = SubEntityInfo.where(del_status: false).order(sub_entity_alias: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true ").order(username: :desc)
      @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :asc)

      search_arr = ["del_status = false AND active_status = true"]
      the_search = ""

      if params[:filter_main].present? || params[:assigned_code].present? || params[:entity_division_code].present? || params[:active_status].present?|| params[:sub_entity_name].present?|| params[:sub_entity_alias].present?|| params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?

        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @assigned_code = filter_params[:assigned_code]
          @entity_division_code = filter_params[:entity_division_code]
          @active_status = filter_params[:active_status]
          @sub_entity_name = filter_params[:sub_entity_name]
          @sub_entity_alias = filter_params[:sub_entity_alias]
          @username = filter_params[:user_id]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:assigned_code] = filter_params[:assigned_code]
          params[:entity_division_code] = filter_params[:entity_division_code]
          params[:active_status] = filter_params[:active_status]
          params[:sub_entity_name] = filter_params[:sub_entity_name]
          params[:sub_entity_alias] = filter_params[:sub_entity_alias]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        else

        if  params[:assigned_code].present? || params[:entity_division_code].present? || params[:active_status].present?|| params[:sub_entity_name].present?|| params[:sub_entity_alias].present? || params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

          @assigned_code = params[:assigned_code]
          @entity_division_code = params[:entity_division_code]
          @active_status = params[:active_status]
          @sub_entity_name = params[:sub_entity_name]
          @sub_entity_alias = params[:sub_entity_alias]
          @username = params[:user_id]
          @start_date = params[:start_date]
          @end_date = params[:end_date]

          params[:assigned_code] = @assigned_code
          params[:entity_division_code] = @entity_division_code
          params[:active_status] = @active_status
          params[:sub_entity_name] = @sub_entity_name
          params[:sub_entity_alias] = @sub_entity_alias
          params[:user_id] = @username
          params[:start_date] = @start_date
          params[:end_date] = @end_date

        else
          params[:assigned_code] = filter_params[:assigned_code]
          params[:entity_division_code] = filter_params[:entity_division_code]
          params[:active_status] = filter_params[:active_status]
          params[:sub_entity_name] = filter_params[:sub_entity_name]
          params[:sub_entity_alias] = filter_params[:sub_entity_alias]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        end
      end

      if @assigned_code.present?
        #search_arr << "customer_number LIKE '%#{@cust_num}%'"
        search_arr << "assigned_code = '#{@assigned_code}'"
      end
      if @entity_division_code.present?
        search_arr << "entity_division_code = '#{@entity_division_code}'"
      end
      if @active_status.present?
        search_arr << "active_status = '#{@active_status}'"
      end
      if @sub_entity_name.present?
        search_arr << "sub_entity_name = '#{@sub_entity_name}'"
      end
      if @sub_entity_alias.present?
        search_arr << "sub_entity_alias = '#{@sub_entity_alias}'"
      end
      if @username.present?
        search_arr << "user_id = '#{@username}'"
      end
      if @start_date.present? && @end_date.present?
        f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
        f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
        if f_start_date <= f_end_date
          search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
        end
      end

    else
    end

    the_search = search_arr.join(" AND ")
    logger.info "The search array :: #{search_arr.inspect}"
    logger.info "The Search :: #{the_search.inspect}"

    if params[:count] == "All"
      saved_size = @sub_entity_infos.exists? ? @sub_entity_infos.size : 0
      @sub_entity_infos = SubEntityInfo.where(the_search).paginate(:page => 1, :per_page => saved_size).order('created_at desc')
    else
    @sub_entity_infos = SubEntityInfo.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
  end


  def sub_entity_infos_index_div
    params[:count] ? params[:count] : params[:count] = 20
    params[:page] ? params[:page] : params[:page] = 1
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code

    if current_user.merchant_admin?
      @sub_entity_name_search = SubEntityInfo.where(entity_code: params[:main_code],active_status: true).order(sub_entity_name: :desc)
      @sub_entity_alias_search = SubEntityInfo.where(entity_code: params[:main_code], active_status: true).order(sub_entity_alias: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true AND main_code = '#{params[:main_code]}'").order(username: :desc)

    elsif current_user.division_admin?
      @sub_entity_name_search = SubEntityInfo.where(entity_division_code: params[:div_code], active_status: true).order(sub_entity_name: :desc)
      @sub_entity_alias_search = SubEntityInfo.where(entity_division_code: params[:div_code], active_status: true).order(sub_entity_alias: :desc)
      @user_search = User.unscoped.user_join.where("ur.active_status = true AND div_code = '#{params[:div_code]}'").order(username: :desc)

    else
    end

      if current_user.merchant_admin?
        search_arr = ["entity_code = '#{params[:main_code]}' AND active_status = true"]
      elsif current_user.division_admin?
        search_arr = ["entity_division_code = '#{params[:div_code]}' AND active_status = true"]
      end
      the_search = ""
      if params[:filter_main].present? || params[:assigned_code].present? || params[:entity_division_code].present? || params[:active_status].present?|| params[:sub_entity_name].present?|| params[:sub_entity_alias].present?|| params[:user_id].present?|| params[:start_date].present? || params[:end_date].present?
        filter_params = params[:filter_main]
        if params[:filter_main].present?
          @assigned_code = filter_params[:assigned_code]
          @entity_division_code = filter_params[:entity_division_code]
          @active_status = filter_params[:active_status]
          @sub_entity_name = filter_params[:sub_entity_name]
          @sub_entity_alias = filter_params[:sub_entity_alias]
          @username = filter_params[:user_id]
          @start_date = filter_params[:start_date]
          @end_date = filter_params[:end_date]

          params[:assigned_code] = filter_params[:assigned_code]
          params[:entity_division_code] = filter_params[:entity_division_code]
          params[:active_status] = filter_params[:active_status]
          params[:sub_entity_name] = filter_params[:sub_entity_name]
          params[:sub_entity_alias] = filter_params[:sub_entity_alias]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        else

        if  params[:assigned_code].present? || params[:entity_division_code].present? || params[:active_status].present?|| params[:sub_entity_name].present?|| params[:sub_entity_alias].present? || params[:user_id].present? || params[:start_date].present? || params[:end_date].present?

          @assigned_code = params[:assigned_code]
          @entity_division_code = params[:entity_division_code]
          @active_status = params[:active_status]
          @sub_entity_name = params[:sub_entity_name]
          @sub_entity_alias = params[:sub_entity_alias]
          @username = params[:user_id]
          @start_date = params[:start_date]
          @end_date = params[:end_date]

          params[:assigned_code] = @assigned_code
          params[:entity_division_code] = @entity_division_code
          params[:active_status] = @active_status
          params[:sub_entity_name] = @sub_entity_name
          params[:sub_entity_alias] = @sub_entity_alias
          params[:user_id] = @username
          params[:start_date] = @start_date
          params[:end_date] = @end_date

        else
          params[:assigned_code] = filter_params[:assigned_code]
          params[:entity_division_code] = filter_params[:entity_division_code]
          params[:active_status] = filter_params[:active_status]
          params[:sub_entity_name] = filter_params[:sub_entity_name]
          params[:sub_entity_alias] = filter_params[:sub_entity_alias]
          params[:user_id] = filter_params[:user_id]
          params[:start_date] = filter_params[:start_date]
          params[:end_date] = filter_params[:end_date]

        end
      end

      if @assigned_code.present?
        #search_arr << "customer_number LIKE '%#{@cust_num}%'"
        search_arr << "assigned_code = '#{@assigned_code}'"
      end
      if @entity_division_code.present?
        search_arr << "entity_division_code = '#{@entity_division_code}'"
      end
      if @active_status.present?
        search_arr << "active_status = '#{@active_status}'"
      end
      if @sub_entity_name.present?
        search_arr << "sub_entity_name = '#{@sub_entity_name}'"
      end
      if @sub_entity_alias.present?
        search_arr << "sub_entity_alias = '#{@sub_entity_alias}'"
      end
      if @username.present?
        search_arr << "user_id = '#{@username}'"
      end
      if @start_date.present? && @end_date.present?
        f_start_date =  @start_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@start_date, '%m/%d/%Y') # @start_date.to_date.strftime('%Y-%m-%d')
        f_end_date = @end_date.to_date.strftime('%Y-%m-%d') # Date.strptime(@end_date, '%m/%d/%Y') # @end_date.to_date.strftime('%Y-%m-%d')
        if f_start_date <= f_end_date
          search_arr << "created_at BETWEEN '#{f_start_date} 00:00:00' AND '#{f_end_date} 23:59:59'"
        end
      end

    else
    end

    the_search = search_arr.join(" AND ")
    logger.info "The search array :: #{search_arr.inspect}"
    logger.info "The Search :: #{the_search.inspect}"

    if params[:count] == "All"
      saved_size = @sub_entity_infos.exists? ? @sub_entity_infos.size : 0
      @sub_entity_infos = SubEntityInfo.where(the_search).paginate(:page => 1, :per_page => saved_size).order('created_at desc')
    else
      @sub_entity_infos = SubEntityInfo.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('created_at desc')
    end
  end
  # GET /sub_entity_infos/1 or /sub_entity_infos/1.json
  def show
  end

  # Super and user admin
  def new
    @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
    @sub_entity_info = SubEntityInfo.new
  end
  # Super and user admin
  def edit_sub_entity2
    @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
    @division_name_search = EntityDivision.where(del_status: false).order(division_name: :desc)
    @sub_division_desc_search = EntitySubDivision.where(del_status: false).order(sub_division_desc: :asc)

    @sub_entity_info = SubEntityInfo.where(assigned_code: params[:sub_info_id], active_status: true, del_status: false).first

  end
  #merchant Admin || division-admin
  def new_sub_entity
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :desc)
    @sub_division_desc_search = EntitySubDivision.where(entity_division_code: params[:div_code], del_status: false).order(sub_division_desc: :asc)

    @sub_entity_info = SubEntityInfo.new
  end
  def edit_sub_entity
    params[:div_code] = current_user.user_div_code
    params[:main_code] = current_user.user_main_code
    @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :desc)
    @sub_division_desc_search = EntitySubDivision.where(entity_division_code: params[:div_code], del_status: false).order(sub_division_desc: :asc)
    @sub_entity_name_search = SubEntityInfo.where(entity_division_code: params[:div_code], active_status: true).order(sub_entity_name: :asc)


    @sub_entity_info = SubEntityInfo.where(assigned_code: params[:sub_info_id], active_status: true, del_status: false).first

  end

  def create
    @sub_entity_info = SubEntityInfo.new(sub_entity_info_params)
    sub_entity_info = SubEntityInfo.gen_sub_entity_code

    if params[:for_main] == "for_main"
      respond_to do |format|
        if @sub_entity_info.valid?
          @sub_entity_info.assigned_code = sub_entity_info
          @sub_entity_info.save(validate: false)

          sub_entity_infos_index
          ##################### FLASH MESSAGE ######################################
          flash.now[:notice] = "Branch was successfully created."
          format.js { render "/sub_entity_infos/sub_entity_infos_index" }
          format.html { redirect_to sub_entity_infos_path(id: @sub_entity_info.id), notice: 'Branch was successfully created.' }
          format.json { render :index, status: :created, location: @sub_entity_info }
        else
          format.js { render :new }
          format.html { render :new }
          format.json { render json: @sub_entity_info.errors, status: :unprocessable_entity }

          params[:main_code] = current_user.user_main_code
          params[:div_code] = current_user.user_div_code
          @entity_info_search = EntityInfo.where(active_status: true).order(entity_name: :desc)
        end
      end
    else
      respond_to do |format|
        if @sub_entity_info.valid?
          @sub_entity_info.assigned_code = sub_entity_info
          @sub_entity_info.save(validate: false)
          sub_entity_infos_index_div
          ##################### FLASH MESSAGE ######################################
          flash.now[:notice] = "Branch was successfully created."
          format.js { render "/sub_entity_infos/sub_entity_infos_index_div" }
          format.html { redirect_to sub_entity_infos_path(id: @sub_entity_info.id), notice: 'Branch was successfully created.' }
          format.json { render :index, status: :created, location: @sub_entity_info }
        else
          format.js { render :new_sub_entity }
          format.html { render :new_sub_entity }
          format.json { render json: @sub_entity_info.errors, status: :unprocessable_entity }
          @division_name_search = EntityDivision.where(entity_code: params[:main_code], active_status: true).order(division_name: :asc)
        end
      end
      end
  end

 def update_sub_info
    respond_to do |format|
      @sub_entity_info = SubEntityInfo.where(active_status: true, assigned_code: params[:sub_info_id]).order(created_at: :desc).first
      flash.now[:notice] = "Branch was updated successfully."

      logger.info params[:sub_entity_info].inspect
      @new_record = SubEntityInfo.new(sub_entity_info_params)

      @new_record.assigned_code = @sub_entity_info.assigned_code
      if @new_record.valid?
        @sub_entity_info.active_status = false
        @sub_entity_info.del_status = true
        @sub_entity_info.save(validate: false)
        if @new_record.save
        else
        end
          if params[:for_main] == "for_main"
              sub_entity_infos_index
              format.js { render "/sub_entity_infos/sub_entity_infos_index" }
              format.html { redirect_to sub_entity_infos_path, notice: 'Branch updated successfully.' }
              format.json { render :sub_entity_infos_index, status: :ok, location: @sub_entity_info }
          else
            sub_entity_infos_index_div
            format.js { render "/sub_entity_infos/sub_entity_infos_index_div" }
            format.html { redirect_to sub_entity_infos_path, notice: 'Branch was updated successfully.' }
            format.json { render :sub_entity_infos_index, status: :ok, location: @sub_entity_info }
          end
      else
        logger.info "Branch Error Messages Edit :: #{@new_record.errors.messages.inspect}"

        format.html {render :edit}
        format.js { render :edit }
        format.json { render json: @sub_entity_info.errors, status: :unprocessable_entity }
      end
    end
  end

  def entity_update
    logger.info "Params:: #{params[:id_for_entity_info].inspect}"
    if params[:id_for_entity_info].empty?
      @info_update_division = [["", ""]].insert(0, ['Please select a Division', ""])
    else
      info_update_division = EntityDivision.where(entity_code: params[:id_for_entity_info], active_status: true).order(division_name: :desc).map { |a| [a.division_name, a.id] }.insert(0, ['Please select a Division', ""])
      @info_update_division = info_update_division.empty? ? [["", ""]].insert(0, ['Please select a Division', ""]) : info_update_division
    end
    logger.info "For Entity Division :: #{@info_update_division.inspect}"
  end

  def entity_update2
    if params[:id_for_division].empty?
      @divsion_update_sub_division = [["", ""]].insert(0, ['Please select a Sub Division', ""])
    else
      divsion_update_sub_division = EntitySubDivision.where(entity_division_code: params[:id_for_division], active_status: true).order(sub_division_desc: :desc).map { |a| [a.sub_division_desc, a.id] }.insert(0, ['Please select a Sub Division', ""])
      @divsion_update_sub_division = divsion_update_sub_division.empty? ? [["", ""]].insert(0, ['Please select a Sub Division', ""]) : divsion_update_sub_division
    end
    logger.info "For Sub division :: #{@divsion_update_sub_division.inspect}"
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_sub_entity_info
      # @sub_entity_info = SubEntityInfo.find(params[:id])

      @sub_entity_info = SubEntityInfo.where(active_status: true, assigned_code: params[:id]).order(created_at: :desc).first

    end

    # Only allow a list of trusted parameters through.
    def sub_entity_info_params
      params.require(:sub_entity_info).permit(:assigned_code,:entity_code,:entity_division_code,:sub_entity_name,:sub_entity_alias,:comment,:active_status,:del_status,:user_id,:created_at,:updated_at, :entity_sub_div_code)
    end
end
