class UsersController < ApplicationController
  before_action :set_user, only: [:show, :edit, :update, :destroy, :user_details_page]
  require 'church_core'
  # before_action :load_permissions
  # load_and_authorize_resource

  # GET /users or /users.json
  def index
      params[:main_code] = current_user.user_main_code
      params[:div_code] = current_user.user_div_code
      params[:branch_code] = current_user.user_branch_code

      params[:count] ? params[:count] : params[:count] = 20
      params[:page].present? ? page = params[:page].to_i : page = 1

    if current_user.super_admin?
      @users = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('SA','UA','MA')").paginate(:page => page, :per_page => params[:count]).order('users.created_at desc')

      @username_search = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('SA','UA','MA')").order(username: :desc)
      @othername_search = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('SA','UA','MA')").order(other_name: :desc)
      @lastname_search = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('SA','UA','MA')").order(lastname: :desc)
      @role_search = Role.where(active_status: true, unique_code: ['SA','UA','MA']).order(name: :desc)
      @email_search = User.unscoped.user_join.where("ur.del_status is false").order(email: :desc)
      @main_code_search = EntityInfo.where('del_status is true').order(entity_name: :desc)

    elsif current_user.user_admin?
      @users = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('UA','MA')").paginate(:page => page, :per_page => params[:count]).order('users.created_at desc')

      @username_search = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('UA','MA')").order(username: :desc)
      @othername_search = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('UA','MA')").order(other_name: :desc)
      @lastname_search = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('UA','MA')").order(lastname: :desc)
      @role_search = Role.where(active_status: true, unique_code: ['UA','MA']).order(name: :desc)
      @email_search = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('UA','MA')").order(email: :desc)
      @main_code_search = EntityInfo.where('del_status is true').order(entity_name: :desc)

    elsif current_user.merchant_admin?
      @users = User.unscoped.user_join.where("ur.active_status = true AND ur.main_code = '#{params[:main_code]}'").paginate(:page => page, :per_page => params[:count]).order('users.created_at desc')

      logger.info "User merged :: #{@users.inspect}"

      @username_search = User.unscoped.user_join.where("ur.del_status is false AND ur.main_code = '#{params[:main_code]}'").order(username: :desc)
      @othername_search = User.unscoped.user_join.where("ur.del_status is false AND ur.main_code = '#{params[:main_code]}'").order(other_name: :desc)
      @lastname_search = User.unscoped.user_join.where("ur.del_status is false AND ur.main_code = '#{params[:main_code]}'").order(lastname: :desc)
      @role_search = Role.where(unique_code: ['MA','DA']).order(name: :desc)
      @email_search = User.user_join.where("ur.del_status is false AND ur.main_code = '#{params[:main_code]}'").order(email: :desc)
      @division_code_search = EntityDivision.where(active_status: true, entity_code: params[:main_code]).order(division_name: :desc)

    elsif current_user.division_admin?
      @users = User.unscoped.user_join.where("ur.del_status is false AND ur.div_code = '#{params[:div_code]}'").paginate(:page => page, :per_page => params[:count]).order('users.created_at desc')

      @username_search = User.unscoped.user_join.where("ur.del_status is false AND ur.div_code = '#{params[:div_code]}'").order(username: :desc)
      @othername_search = User.unscoped.user_join.where("ur.del_status is false AND ur.div_code = '#{params[:div_code]}'").order(other_name: :desc)
      @lastname_search = User.unscoped.user_join.where("ur.del_status is false AND ur.div_code = '#{params[:div_code]}'").order(lastname: :desc)
      @role_search = Role.where(unique_code: ['MA','DA']).order(name: :desc)
      @email_search = User.unscoped.user_join.where("ur.del_status is false AND ur.div_code = '#{params[:div_code]}'").order(email: :desc)

    elsif current_user.branch_admin?
      @users = User.unscoped.user_join.where("ur.del_status is false AND ur.sub_entity_code = '#{params[:branch_code]}'").paginate(:page => page, :per_page => params[:count]).order('users.created_at desc')

      @username_search = User.unscoped.user_join.where("ur.del_status is false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(username: :desc)
      @othername_search = User.unscoped.user_join.where("ur.del_status is false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(other_name: :desc)
      @lastname_search = User.unscoped.user_join.where("ur.del_status is false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(lastname: :desc)
      @role_search = Role.where(unique_code: ['BA','BU']).order(name: :desc)
      @email_search = User.unscoped.user_join.where("ur.del_status is false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(email: :desc)

    else
      logger.info "=============== Please don't come here............"
    end

  end

  def users_index
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    params[:branch_code] = current_user.user_branch_code

      if current_user.super_admin?
        @username_search = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('SA','UA','MA')").order(username: :desc)
        @othername_search = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('SA','UA','MA')").order(other_name: :desc)
        @lastname_search = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('SA','UA','MA')").order(lastname: :desc)
        @role_search = Role.where(active_status: true, unique_code: ['SA','UA','MA']).order(name: :desc)
        @email_search = User.unscoped.user_join.where("ur.del_status is false").order(email: :desc)
        @main_code_search = EntityInfo.where('del_status is true').order(entity_name: :desc)

        search_arr = ["ur.active_status = true AND ur.role_code IN ('SA','UA','MA')"]
      elsif current_user.user_admin?
        @username_search = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('UA','MA')").order(username: :desc)
        @othername_search = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('UA','MA')").order(other_name: :desc)
        @lastname_search = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('UA','MA')").order(lastname: :desc)
        @role_search = Role.where(active_status: true, unique_code: ['UA','MA']).order(name: :desc)
        @email_search = User.unscoped.user_join.where("ur.active_status = true AND ur.role_code IN ('UA','MA')").order(email: :desc)
        @main_code_search = EntityInfo.where('del_status is true').order(entity_name: :desc)

        search_arr = ["ur.active_status = true AND ur.role_code IN ('UA','MA')"]
      elsif current_user.merchant_admin?
        @username_search = User.unscoped.user_join.where("ur.del_status is false AND ur.main_code = '#{params[:main_code]}'").order(username: :desc)
        @othername_search = User.unscoped.user_join.where("ur.del_status is false AND ur.main_code = '#{params[:main_code]}'").order(other_name: :desc)
        @lastname_search = User.unscoped.user_join.where("ur.del_status is false AND ur.main_code = '#{params[:main_code]}'").order(lastname: :desc)
        @role_search = Role.where(unique_code: ['MA','DA']).order(name: :desc)
        @email_search = User.user_join.where("ur.del_status is false AND ur.main_code = '#{params[:main_code]}'").order(email: :desc)
        @division_code_search = EntityDivision.where(active_status: true, entity_code: params[:main_code]).order(division_name: :desc)

        search_arr = ["ur.main_code = '#{params[:main_code]}' AND ur.del_status is false"]
      elsif current_user.division_admin?
        @username_search = User.unscoped.user_join.where("ur.del_status is false AND ur.div_code = '#{params[:div_code]}'").order(username: :desc)
        @othername_search = User.unscoped.user_join.where("ur.del_status is false AND ur.div_code = '#{params[:div_code]}'").order(other_name: :desc)
        @lastname_search = User.unscoped.user_join.where("ur.del_status is false AND ur.div_code = '#{params[:div_code]}'").order(lastname: :desc)
        @role_search = Role.where(unique_code: ['MA','DA']).order(name: :desc)
        @email_search = User.unscoped.user_join.where("ur.del_status is false AND ur.div_code = '#{params[:div_code]}'").order(email: :desc)

        search_arr = ["ur.div_code = '#{params[:div_code]}' AND ur.del_status is false"]
      elsif current_user.branch_admin?
        @username_search = User.unscoped.user_join.where("ur.del_status is false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(username: :desc)
        @othername_search = User.unscoped.user_join.where("ur.del_status is false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(other_name: :desc)
        @lastname_search = User.unscoped.user_join.where("ur.del_status is false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(lastname: :desc)
        @role_search = Role.where(unique_code: ['BA','BU']).order(name: :desc)
        @email_search = User.unscoped.user_join.where("ur.del_status is false AND ur.sub_entity_code = '#{params[:branch_code]}'").order(email: :desc)

        search_arr = ["ur.sub_entity_code = '#{params[:branch_code]}' AND ur.del_status is false"]
      end
      if params[:filter].present? || params[:lastname].present? || params[:active_status].present? || params[:username].present?|| params[:role_code].present? || params[:email].present? || params[:main_code].present?|| params[:div_code].present?|| params[:other_name].present?|| params[:sub_entity_code].present?
        filter_params = params[:filter]
        if params[:filter].present?
          @lastname = filter_params[:lastname]
          @active_status = filter_params[:active_status]
          @username = filter_params[:username]
          @role_code = filter_params[:role_code]
          @email = filter_params[:email]
          @main_code = filter_params[:main_code]
          @div_code = filter_params[:div_code]
          @sub_entity_code = filter_params[:sub_entity_code]
          @other_name = filter_params[:other_name]

          params[:lastname] = filter_params[:lastname]
          params[:active_status] = filter_params[:active_status]
          params[:username] = filter_params[:username]
          params[:role_code] = filter_params[:role_code]
          params[:email] = filter_params[:email]
          params[:main_code] = filter_params[:main_code]
          params[:div_code] = filter_params[:div_code]
          params[:sub_entity_code] = filter_params[:sub_entity_code]
          params[:other_name] = filter_params[:other_name]
        else

          if params[:filter].present? || params[:lastname].present? || params[:active_status].present? || params[:username].present?|| params[:role_code].present? || params[:email].present? || params[:main_code].present?|| params[:div_code].present?|| params[:other_name].present?|| params[:sub_entity_code].present?
            @lastname = params[:lastname]
            @active_status = params[:active_status]
            @username = params[:username]
            @role_code = params[:role_code]
            @email = params[:email]
            @main_code = params[:main_code]
            @div_code = params[:div_code]
            @sub_entity_code = params[:sub_entity_code]
            @other_name = params[:other_name]

            params[:lastname] = @lastname
            params[:active_status] = @active_status
            params[:assign_code] = @assign_code
            params[:email] = @email
            params[:main_code] = @main_code
            params[:div_code] = @div_code
            params[:sub_entity_code] = @sub_entity_code
            params[:other_name] = @other_name

          else
            params[:lastname] = filter_params[:lastname]
            params[:active_status] = filter_params[:active_status]
            params[:role_code] = filter_params[:role_code]
            params[:email] = filter_params[:email]
            params[:start_date] = filter_params[:start_date]
            params[:main_code] = filter_params[:main_code]
            params[:div_code] = filter_params[:div_code]
            params[:sub_entity_code] = filter_params[:sub_entity_code]
            params[:other_name] = filter_params[:other_name]
          end
        end
        if @lastname.present?
          search_arr << "lastname = '#{@lastname}'"
        end
        if @active_status.present?
          search_arr << "users.active_status = '#{@active_status}'"
        end
        if @username.present?
          search_arr << "username = '#{@username}'"
        end
        if @role_code.present?
          search_arr << "ur.role_code = '#{@role_code}'"
        end
        if @email.present?
          search_arr << "email = '#{@email}'"
        end
        if @main_code.present?
          search_arr << "main_code = '#{@main_code}'"
        end
        if @div_code.present?
          search_arr << "div_code = '#{@div_code}'"
          end
        if @sub_entity_code.present?
          search_arr << "sub_entity_code = '#{@sub_entity_code}'"
        end
        if @other_name.present?
          search_arr << "other_name = '#{@other_name}'"
        end
      else
        # $service_filter = ""
        filter_params = ""
      end
      the_search = search_arr.join(" AND ")
      logger.info "The search array :: #{search_arr.inspect}"
      logger.info "The Search :: #{the_search.inspect}"
      if params[:count] == "All"
        @users = User.user_join.where(the_search).order('users.created_at desc')
        saved_size = @users.exists? ? @users.size : 0
        @users = User.user_join.where(the_search).paginate(page: 1, per_page: saved_size).order("users.created_at desc")
      else
        @users = User.unscoped.user_join.where(the_search).paginate(:page => params[:page], :per_page => params[:count]).order('users.created_at desc')
      end
  end

  def formatPhoneNo(mobile_no)
    mobile_no_full=""
    msisdn=mobile_no[mobile_no.to_s.length-9..-1]
    if !msisdn.nil? then
      if msisdn.length.to_i==9 then
        ##return "#{CNTRY_CODE}#{msisdn}"
        return msisdn
      else
        return false
      end
    else
      false
    end
  end


  # GET /users/1 or /users/1.json
  def show
  end

  # GET /users/new
  def new
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    params[:branch_code] = current_user.user_branch_code

    @user = User.new
  end

  # GET /users/1/edit
  def edit
    params[:main_code] = current_user.user_main_code
    params[:div_code] = current_user.user_div_code
    params[:branch_code] = current_user.user_branch_code

    @user.role_code = @user.user_roles&.first.role_code if @user.user_roles&.first
  end

  # POST /users or /users.json
  def create
    @user = User.new(user_params)
    @roles = Role.where("ur.active_status is true AND")
    flash.now[:notice] = "User was successfully created."

    respond_to do |format|
      if @user.valid?
        role_code = user_params[:role_code].present? ? user_params[:role_code] : nil
        main_code = user_params[:main_code].present? ? user_params[:main_code] : nil
        div_code = user_params[:div_code].present? ? user_params[:div_code] : nil
        sub_entity_code = user_params[:sub_entity_code].present? ? user_params[:sub_entity_code] : nil
        @user.save
        @user_role = UserRole.new(user_id: @user.id, role_code: role_code, main_code: main_code, div_code: div_code, sub_entity_code: sub_entity_code)
        @user_role.save(validate: false)

        if user_params.has_key?('logo_data') &&  user_params[:logo_data] !=nil
          #Image uploads
          image_uploader = ChurchCore::ImageDataUploader.new
          logo_data = user_params[:logo_data].present? ? user_params[:logo_data] : ""
          img_public_id = image_uploader.public_id(logo_data)
          img_store_dir = image_uploader.store_dir
          logger.info "Image Data 1 :: #{logo_data.original_filename.split(".").inspect}"

          tab_logo_path = "#{user_params[:logo_path]}#{img_store_dir}/"
          tab_logo_data = image_uploader.filename(logo_data, img_public_id)
          logger.info "===========================//////////////////================="
          logger.info "image data #{user_params[:logo_data].inspect}"
          # logger.info "Image Path :: #{@user.logo_path.inspect}"
          logger.info "Image Data :: #{@user.logo_data.inspect}"

          logger.info "Cloudinary Saving =========================="
          @image_results = Cloudinary::Uploader.upload(logo_data, :public_id => img_public_id)
          logger.info "The Image Data :: #{@image_results["secure_url"].inspect}"
          @user_boards = UserBoard.new(logo_path: @image_results["secure_url"], logo_data: tab_logo_data, user_id: @user.id)
          @user_boards.save(validate: false)
        else
        end

        index
        format.js { render "/users/users_index" }
        format.html { redirect_to users_path, notice: 'User was successfully created.' }
        format.json { render :users_index, status: :created, location: @user }
      else
        params[:main_code] = current_user.user_main_code
        params[:div_code] = current_user.user_div_code
        params[:branch_code] = current_user.user_branch_code
        
        logger.info "Users Error Messages :: #{@user.errors.messages.inspect}"
        format.js { render :new }
        format.html {render :new}
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end


  def update
    if params[:user][:password].blank? && params[:user][:password_confirmation].blank?
      params[:user].delete(:password)
      params[:user].delete(:password_confirmation)
    end
    # @roles = Role.All
    respond_to do |format|
      @user = User.unscoped.find(params[:id])
      flash.now[:notice] = "User was updated successfully."

      logger.info params[:user].inspect

      if @user.update(user_params)
        @user_role = UserRole.where(active_status: true, user_id: @user.id).order(created_at: :desc).first
        if @user_role
          if user_params[:role_code] != @user_role.role_code || user_params[:main_code] != @user_role.main_code || user_params[:div_code] != @user_role.div_code || user_params[:sub_entity_code] != @user_role.sub_entity_code
            role_code = user_params[:role_code].present? ? user_params[:role_code] : nil
            main_code = user_params[:main_code].present? ? user_params[:main_code] : nil
            div_code = user_params[:div_code].present? ? user_params[:div_code] : nil
            sub_entity_code = user_params[:sub_entity_code].present? ? user_params[:sub_entity_code] : nil
            @user_role.active_status = false
            @user_role.del_status = true
            @user_role.save(validate: false)
            @user_roles = UserRole.new(user_id: @user.id, role_code: role_code, main_code: main_code, div_code: div_code, sub_entity_code: sub_entity_code)
            @user_roles.save(validate: false)
          end
        end
        
        @user_board = UserBoard.where(active_status: true, user_id: params[:id]).order(created_at: :desc).first
        if user_params[:logo_data].present?
          #Image uploads (Variables)
          image_uploader = ChurchCore::ImageDataUploader.new
          logo_data = user_params[:logo_data].present? ? user_params[:logo_data] : ""
          img_public_id = image_uploader.public_id(logo_data)
          img_store_dir = image_uploader.store_dir
          logger.info "Image Data 1 :: #{logo_data.original_filename.split(".").inspect}"

          tab_logo_path = "#{user_params[:logo_path]}#{img_store_dir}/"
          tab_logo_data = image_uploader.filename(logo_data, img_public_id)
          logger.info "===========================//////////////////================="
          logger.info "image data #{user_params[:logo_data].inspect}"
          # logger.info "Image Path :: #{@person_info.logo_path.inspect}"
          logger.info "Image Data :: #{@user.logo_data.inspect}"

          logger.info "Cloudinary Saving =========================="
          @image_results = Cloudinary::Uploader.upload(logo_data, :public_id => img_public_id)
          logger.info "The Image Data :: #{@image_results["secure_url"].inspect}"

          if @user_board
            if user_params[:logo_data] != @user_board.logo_data
              # logo_data = user_params[:logo_data].present? ? user_params[:logo_data] : nil
              @user_board.active_status = false
              @user_board.del_status = true
              @user_board.save(validate: false)

              @user_boards = UserBoard.new(user_id: @user.id, logo_path: @image_results["secure_url"], logo_data: tab_logo_data)
              @user_boards.save(validate: false)
            end
          else
            @user_boards = UserBoard.new(user_id: @user.id, logo_path: @image_results["secure_url"], logo_data: tab_logo_data)
            @user_boards.save(validate: false)
          end
        else
        end
        index
        format.js { render "/users/users_index" }
        format.html { redirect_to users_path, notice: 'User was successfully updated.' }
        format.json { render :users_index, status: :ok, location: @user }
      else
        logger.info "Users Error Messages Edit :: #{@user.errors.messages.inspect}"
        @user.role_code = params[:role_code]
        format.html {render :edit}
        format.js { render :edit }
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end

  def enable_user
    user = User.unscoped.where('id = ? ', params[:user_id]).order(created_at: :desc).first
    respond_to do |format|
      user.active_status = true
      if user.save(validate: false)
        users_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "User Enabled successfully."
        format.js {render layout: false}
      else
        users_index
        format.js {render layout: false}
      end
    end
  end

  def disable_user
    user = User.where(id: params[:user_id]).order(created_at: :desc).first
    respond_to do |format|
      user.active_status = false
      if user.save(validate: false)
        users_index
        ##################### FLASH MESSAGE ######################################
        flash.now[:notice] = "User Disabled successfully."
        format.js {render layout: false}
      else
        users_index
        format.js {render layout: false}
      end
    end
  end


  private
  # Use callbacks to share common setup or constraints between actions.
  def set_user
    @user = User.find(params[:id])
  end

  # Only allow a list of trusted parameters through.
  def user_params
    params.require(:user).permit(:lastname, :other_name, :username, :mobile_number, :password, :email, :current_password,
                                 :password_confirmation, :id, :role_code, :main_code, :div_code, :active_status,
                                 :del_status, :logo_data,:logo_path,:sub_entity_code)
  end
end
