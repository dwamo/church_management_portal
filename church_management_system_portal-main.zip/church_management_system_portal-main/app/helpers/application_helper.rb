module ApplicationHelper

  def encrypt_value(val)
    crypt = ActiveSupport::MessageEncryptor.new(Rails.application.secrets.secret_key_base[0..31])
    encrypted_data = crypt.encrypt_and_sign(val)
  end

  def decrypt_value(val)
    crypt = ActiveSupport::MessageEncryptor.new(Rails.application.secrets.secret_key_base[0..31])
    decrypted_back = crypt.decrypt_and_verify(val)
  end


end
