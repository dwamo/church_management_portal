module JobCatsHelper
end
