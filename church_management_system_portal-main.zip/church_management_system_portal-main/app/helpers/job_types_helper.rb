module JobTypesHelper
end
