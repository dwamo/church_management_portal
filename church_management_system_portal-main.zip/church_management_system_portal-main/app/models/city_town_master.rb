class CityTownMaster < ApplicationRecord
  belongs_to :region_master, -> {where active_status: true}, class_name: "RegionMaster", foreign_key: :region_code
  belongs_to :user, -> {where active_status: true}, class_name: "User", foreign_key: :user_id
  # belongs_to :person_contact_info, -> { where active_status: true }, class_name: "PersonContactInfo", foreign_key: :res_city_town_id

  has_many :person_contact_infos, -> { where active_status: true }, class_name: "PersonContactInfo", foreign_key: :res_city_town_id#, optional: true
  has_many :person_emp_infos, -> { where active_status: true }, class_name: "PersonEmpInfo", foreign_key: :emp_loc_city_town_id#, optional: true

  validates :city_town_name, presence: true




end
