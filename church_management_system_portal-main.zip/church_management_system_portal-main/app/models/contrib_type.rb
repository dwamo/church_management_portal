class ContribType < ApplicationRecord
  self.primary_key = :assigned_code

  belongs_to :user, -> {where active_status: true }, class_name: "User", foreign_key: :user_id
  belongs_to :entity_info, class_name: "EntityInfo", foreign_key: :entity_code

  validates :contribution_desc, presence: true
  validates :assigned_code, presence: true, :length => {:maximum => 4, :min => 2, message: "must be a maximum of 4 characters. eg. TIT for tithe"}

  validates_uniqueness_of :assigned_code, :message => "already taken"

end
