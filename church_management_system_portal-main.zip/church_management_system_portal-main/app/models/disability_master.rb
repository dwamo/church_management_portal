class DisabilityMaster < ApplicationRecord
  belongs_to :user, -> {where active_status: true}, class_name: "User", foreign_key: :user_id
  has_many :person_extra_infos, -> { where active_status: true }, class_name: "PersonExtraInfo", foreign_key: :physical_disability#, optional: true

  validates :disability_desc, presence: true


end
