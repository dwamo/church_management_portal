class EmpStatusMaster < ApplicationRecord
  self.primary_key = :assigned_code

  belongs_to :user, -> {where active_status: true}, class_name: "User", foreign_key: :user_id
  has_many :person_extra_infos, -> { where active_status: true }, class_name: "PersonExtraInfo", foreign_key: :emp_status_code

  validates :emp_status_desc, presence: true
  validates :assigned_code, presence: true
  validates_uniqueness_of :assigned_code, :message => "already exists"

end
