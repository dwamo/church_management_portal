class EntityDivision < ApplicationRecord
  self.primary_key = :assigned_code
  attr_accessor :entity_div_code

  belongs_to :entity_infos, -> {where del_status: false}, class_name: "EntityInfo", foreign_key: :entity_code#, optional: true
  belongs_to :user, -> {where del_status: false}, class_name: "User", foreign_key: :user_id
  has_many :entity_extra_infos, -> { where del_status: false }, class_name: "EntityExtraInfo", foreign_key: :entity_division_code
  has_many :entity_sub_divisions, -> { where del_status: false }, class_name: "EntitySubDivision", foreign_key: :entity_division_code

  validates :division_name, :length => {:minimum => 3,:maximum => 255, message: "should be a minimum of 3 characters and should not exceed 20 characters"}
  # validates :division_alias, presence: true
  

  def self.gen_div_code
    sql = "select nextval('entity_div_seq')"
    val = ActiveRecord::Base.connection.execute(sql)
    val = val.values[0][0]
    logger.info "For EntityDivision ID, #{val}"
    code = "%09d" % val
    "#{code}"
  end

  def self.update_last_but_one(table_name, entity_code, old_updated_at)
    sql = "UPDATE #{table_name} SET active_status = true, del_status = false, updated_at = '#{old_updated_at}' WHERE entity_code = '#{entity_code}' order by id desc limit 1"
    val = ActiveRecord::Base.connection.execute(sql)
  end


  def self.div_wallet_join
    joins("right join entity_wallet_configs ewc on ewc.entity_div_code = assigned_div_code").
        select("assigned_div_code, entity_code, division_name, division_type, contact_number,email, entity_divisions.comment,
entity_divisions.active_status, entity_divisions.del_status, entity_divisions.created_at, ewc.id AS entity_wallet_id, ewc.entity_div_code AS wallet_entity_div_code, ewc.client_key AS div_client_key, ewc.secret_key AS div_secret_key, ewc.service_id AS div_service_id, ewc.comment, ewc.active_status, ewc.del_status, ewc.user_id, ewc.created_at").where("entity_divisions.del_status = false and ewc.del_status = false")
  end
  
end
