class EntityExtraInfo < ApplicationRecord

  belongs_to :person_info, -> {where active_status: true}, class_name: "PersonInfo", foreign_key: :person_assigned_code
  belongs_to :emp_status_master, -> { where active_status: true }, class_name: "EmpStatusMaster", foreign_key: :emp_status_code
  belongs_to :entity_division, -> { where active_status: true }, class_name: "EntityDivision", foreign_key: :entity_division_code
  belongs_to :sub_entity_info, -> { where active_status: true }, class_name: "SubEntityInfo", foreign_key: :sub_entity_code
  belongs_to :person_role_master, -> { where active_status: true }, class_name: "PersonRoleMaster", foreign_key: :person_role_code



  





end
