class EntityInfo < ApplicationRecord
  self.primary_key = :assigned_code
  attr_accessor :motto, :logo_path, :logo_data  #from the entity_info_boards table

  has_many :entity_divisions, -> { where del_status: false }, class_name: "EntityDivision", foreign_key: :entity_code
  has_many :person_infos, -> { where del_status: false }, class_name: "PersonInfo", foreign_key: :person_assigned_code
  has_many :user_roles, -> { where del_status: false }, class_name: "UserRole", foreign_key: :main_code
  has_many :entity_info_boards, -> { where del_status: false }, class_name: "EntityInfoBoard", foreign_key: :entity_code
  has_many :person_infos, -> { where del_status: false }, class_name: "PersonInfo", foreign_key: :entity_info_code
  # has_many :users, -> { where active_status: true }, class_name: "User", foreign_key: :user_id
  # belongs_to :user_role, -> { where active_status: true }, class_name: "UserRole", foreign_key: :main_code
  belongs_to :user, -> { where del_status: false }, class_name: "User", foreign_key: :user_id

  validates :entity_name, presence: true
  # validate :logo_size_validation#, :if => "logo_data?"


  def logo_size_validation
    if logo_data.size > 1.megabytes
      errors.add(:base, "Image should be less than 1MB")
    end
  end

  def self.gen_info_code
    sql = "select nextval('entity_main_seq')"
    val = ActiveRecord::Base.connection.execute(sql)
    val = val.values[0][0]
    logger.info "For Info ID, #{val}"
    code = "%09d" % val
    "#{code}"
  end

  def self.info_boards_join
    joins("left join entity_info_boards eib on eib.entity_code = entity_infos.assigned_code").select("assigned_code, entity_name, entity_alias, comment, entity_infos.active_status AS info_status,entity_infos.del_status, user_id, entity_infos.created_at, eib.id AS entity_board_id, eib.motto AS info_motto,
         eib.logo_path AS info_logo_path, eib.logo_data AS info_logo_data, eib.active_status, eib.del_status").where("entity_infos.del_status = false")
  end


  
end
