class EntityInfoBoard < ApplicationRecord

  belongs_to :entity_info, -> { where active_status: true }, class_name: "EntityInfo", foreign_key: :entity_code


end
