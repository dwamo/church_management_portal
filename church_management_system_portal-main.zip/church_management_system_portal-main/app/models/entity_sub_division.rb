class EntitySubDivision < ApplicationRecord
  self.primary_key = :assigned_code
  attr_accessor :entity_info_code

  belongs_to :entity_division, -> {where active_status: true}, class_name: "EntityDivision", foreign_key: :entity_division_code
  belongs_to :user, -> {where active_status: true}, class_name: "User", foreign_key: :user_id

  validates :sub_division_desc, presence: true
  validates :entity_division_code, presence: true







  def self.gen_sub_division_code
    sql = "select nextval('entity_sub_divisions_seq')"
    val = ActiveRecord::Base.connection.execute(sql)
    val = val.values[0][0]
    logger.info "For EntitySubDivision ID, #{val}"
    code = "%09d" % val
    "#{code}"
  end
end
