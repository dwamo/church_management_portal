class GroupCat < ApplicationRecord
  self.primary_key = :assigned_code

  belongs_to :user, -> {where active_status: true}, class_name: "User", foreign_key: :user_id
  belongs_to :entity_info, -> { where active_status: true}, class_name: "EntityInfo", foreign_key: :entity_info_code







  def self.gen_group_code
    sql = "select nextval('group_seq')"
    val = ActiveRecord::Base.connection.execute(sql)
    val = val.values[0][0]
    logger.info "For Info ID, #{val}"
    code = "%03d" % val
    "#{code}"
  end



end
