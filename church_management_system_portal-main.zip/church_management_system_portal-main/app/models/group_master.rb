class GroupMaster < ApplicationRecord
  self.primary_key = :assigned_code

  belongs_to :user, -> { where active_status: true }, class_name: "User", foreign_key: :user_id
  belongs_to :group_cat, -> { where active_status: true }, class_name: "GroupCat", foreign_key: :group_cat_code
  has_many :person_group_infos, -> { where active_status: true }, class_name: "PersonGroupInfo", foreign_key: :group_code#, optional: true


  validates :group_name, presence: true
  # validates_uniqueness_of :job_type_desc, :message => "already exists"










  def self.group_master_code
    sql = "select nextval('group_master_seq')"
    val = ActiveRecord::Base.connection.execute(sql)
    val = val.values[0][0]
    logger.info "For Group Master Code, #{val}"
    code = "%03d" % val
    "#{code}"
  end
end
