class IssueLogType < ApplicationRecord
  self.table_name = :issues_log_type


end
