class JobCat < ApplicationRecord

  belongs_to :user, -> {where active_status: true}, class_name: "User", foreign_key: :user_id
  has_many :person_emp_infos, -> { where active_status: true }, class_name: "PersonEmpInfo", foreign_key: :job_title#, optional: true

  validates :job_cat_desc, :presence => true
  validates_uniqueness_of :job_cat_desc, :message => "already exists"



  def self.job_cats_code
    sql = "select nextval('job_cats_seq')"
    val = ActiveRecord::Base.connection.execute(sql)
    val = val.values[0][0]
    logger.info "For Category Code, #{val}"
    code = "%09d" % val
    "#{code}"
  end

end
