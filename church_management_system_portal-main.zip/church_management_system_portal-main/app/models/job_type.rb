class JobType < ApplicationRecord
  self.primary_key = :assigned_code

  # belongs_to :user, class_name: "User", foreign_key: :user_id
  belongs_to :job_cat, -> {where active_status: true}, class_name: "JobCat", foreign_key: :job_cat_code
  has_many :person_emp_infos, -> { where active_status: true }, class_name: "PersonEmpInfo", foreign_key: :job_type_code#, optional: true

  validates :job_type_desc, presence: true
  validates_uniqueness_of :job_type_desc, :message => "already exists"










  def self.job_type_code
    sql = "select nextval('job_types_seq')"
    val = ActiveRecord::Base.connection.execute(sql)
    val = val.values[0][0]
    logger.info "For Category Code, #{val}"
    code = "%09d" % val
    "#{code}"
  end
end
