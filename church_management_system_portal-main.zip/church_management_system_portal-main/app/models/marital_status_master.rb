class MaritalStatusMaster < ApplicationRecord
  self.primary_key = :assigned_code

  belongs_to :user, -> {where active_status: true}, class_name: "User", foreign_key: :user_id
  # belongs_to :entity_extra_infos, -> {where active_status: true}, class_name: "EntityExtraInfo", foreign_key: :marital_status_code

  validates :status_desc, presence: true
  validates_uniqueness_of :status_desc, :message => "already exists"



  has_many :person_extra_infos, -> { where active_status: true }, class_name: "PersonExtraInfo", foreign_key: :marital_status_code



end
