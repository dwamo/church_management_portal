class PaymentInfo < ApplicationRecord
  self.primary_key = :person_assigned_code
  belongs_to :person_info, -> { where active_status: true }, class_name: "PersonInfo", foreign_key: :person_assigned_code
  # belongs_to :sub_entity_contrib, -> { where active_status: true }, class_name: "SubEntityContrib", foreign_key: :id
  # belongs_to :payment_request, -> { where active_status: true }, class_name: "PaymentRequest", foreign_key: :id
  has_many :person_contact_infos, -> { where active_status: true }, class_name: "PersonContactInfo", foreign_key: :person_assigned_code
  has_many :person_images, -> { where active_status: true }, class_name: "PersonImage", foreign_key: :person_assigned_code
  has_many :sub_entity_contribs, -> { where active_status: true }, class_name: "SubEntityContrib", foreign_key: :id
  has_many :payment_requests, class_name: "PaymentRequest", foreign_key: :payment_info_id
  has_many :contrib_types, -> {where active_status: true}, through: :sub_entity_contribs, primary_key: :contribution_type_code





  def self.payment_info_join
    joins("left join sub_entity_contribs sec on sec.id = payment_infos.product_id
           left join payment_requests pr on pr.payment_info_id = payment_infos.id").select("payment_infos.id, person_assigned_code, mobile_number, payment_infos.amount, product_id, status, payment_infos.created_at, sec.contribution_name as cont_name, sec.sub_entity_code as branch_code, pr.processing_id as process_id, pr.reference as ref").where("payment_infos.status = true")

  end


end
