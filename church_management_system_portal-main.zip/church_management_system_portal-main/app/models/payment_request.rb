class PaymentRequest < ApplicationRecord
  belongs_to :payment_info, class_name: "PaymentInfo", foreign_key: :payment_info_id

end
