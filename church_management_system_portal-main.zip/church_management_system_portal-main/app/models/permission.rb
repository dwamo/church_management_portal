class Permission < ApplicationRecord
end
