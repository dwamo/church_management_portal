class PermissionsRole < ApplicationRecord
end
