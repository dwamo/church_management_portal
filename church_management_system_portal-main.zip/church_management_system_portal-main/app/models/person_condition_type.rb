class PersonConditionType < ApplicationRecord
  self.primary_key = :assigned_code
  
  belongs_to :user, -> {where active_status: true}, class_name: "User", foreign_key: :user_id
  has_many :care_giving_infos, -> { where active_status: true }, class_name: "CareGivingInfo", foreign_key: :condition_type_code

  validates :condition_desc, presence: true
  validates_uniqueness_of :condition_desc, :message => "already exists"

  def self.gen_condition_code
    sql = "select nextval('person_condition_seq')"
    val = ActiveRecord::Base.connection.execute(sql)
    val = val.values[0][0]
    logger.info "For Info ID, #{val}"
    code = "%03d" % val
    "#{code}"
  end


end
