class PersonContactInfo < ApplicationRecord

  belongs_to :person_info, -> { where active_status: true }, class_name: "PersonInfo", foreign_key: :person_assigned_code
  belongs_to :city_town_master, -> { where active_status: true }, class_name: "CityTownMaster", foreign_key: :res_city_town_id
  belongs_to :region_master, -> { where active_status: true }, class_name: "RegionMaster", foreign_key: :res_region_code

end
