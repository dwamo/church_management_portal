class PersonContrib < ApplicationRecord
end
