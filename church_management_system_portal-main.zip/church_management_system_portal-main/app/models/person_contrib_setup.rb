class PersonContribSetup < ApplicationRecord
  
  belongs_to :person_info, -> { where active_status: true }, class_name: "PersonInfo", foreign_key: :person_assigned_code
  belongs_to :sub_entity_info, -> { where active_status: true }, class_name: "SubEntityInfo", foreign_key: :sub_entity_code
  belongs_to :user, -> { where active_status: true }, class_name: "User", foreign_key: :user_id
  belongs_to :sub_entity_contrib, -> { where active_status: true }, class_name: "SubEntityContrib", foreign_key: :sub_entity_contribution_id

  validates :sub_entity_code, presence: true
  validates :sub_entity_contribution_id, presence: true
  # validates :complete_status, presence: true
  # validates :freq, presence: true
  # validates :start_date, presence: true

  # person_contrib_setup.sub_entity_contrib.contrib_type.frequency if person_contrib_setup.sub_entity_contrib.contrib_type


  def frequency_status
    frequency_status_obj = self.sub_entity_contrib.contrib_type.order(created_at: :desc)
    frequency_status_obj ? frequency_status_obj.frequency : ""
  end

  # Testing
  def user_branch_code
    user_role_branch_obj = self.user_roles&.order(created_at: :desc).first
    user_role_branch_obj ? user_role_branch_obj.sub_entity_code : ""
  end

  def self.contrib_join
    joins("left join sub_entity_contribs sec on sec.id = person_contrib_setups.sub_entity_contribution_id
           left join contrib_types cnt on sec.contribution_type_code = cnt.assigned_code").select("person_contrib_setups.id, person_contrib_setups.freq AS frequency, person_contrib_setups.start_date AS date_started, person_contrib_setups.complete_status AS status, person_contrib_setups.user_id AS users, person_contrib_setups.created_at AS date_created, sec.contribution_name AS name").where("person_contrib_setups.del_status = false AND sec.del_status = false AND cnt.del_status = false")
  end


end
