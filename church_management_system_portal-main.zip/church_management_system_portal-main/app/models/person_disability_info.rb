class PersonDisabilityInfo < ApplicationRecord
  belongs_to :person_info, -> { where active_status: true }, class_name: "PersonInfo", foreign_key: :person_assigned_code

  belongs_to :disability_master, -> { where active_status: true }, class_name: "DisabilityMaster", foreign_key: :disability_id#, optional: true


end
