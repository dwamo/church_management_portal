class PersonEmpInfo < ApplicationRecord
  # self.primary_key = :job_type_code

  belongs_to :person_info, -> { where active_status: true }, class_name: "PersonInfo", foreign_key: :person_assigned_code
  belongs_to :job_type, -> { where active_status: true }, class_name: "JobType", foreign_key: :job_type_code
  belongs_to :job_cat, -> { where active_status: true }, class_name: "JobCat", foreign_key: :job_title
  belongs_to :city_town_master, -> { where active_status: true }, class_name: "CityTownMaster", foreign_key: :emp_loc_city_town_id
  belongs_to :region_master, -> { where active_status: true }, class_name: "RegionMaster", foreign_key: :emp_loc_region_code

  
end
