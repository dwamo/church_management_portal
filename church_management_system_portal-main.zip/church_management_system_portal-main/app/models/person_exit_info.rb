class PersonExitInfo < ApplicationRecord
  belongs_to :person_info, -> { where del_status: false }, class_name: "PersonInfo", foreign_key: :person_assigned_code
  belongs_to :entity_info, -> { where del_status: false }, class_name: "EntityInfo", foreign_key: :entity_code
  belongs_to :sub_entity_info, -> { where del_status: false }, class_name: "SubEntityInfo", foreign_key: :sub_entity_code
  belongs_to :person_exit_lov, -> { where del_status: false }, class_name: "PersonExitLov", foreign_key: :exit_lov_id
  belongs_to :user, -> {where del_status: false}, class_name: "User", foreign_key: :user_id
  

end
