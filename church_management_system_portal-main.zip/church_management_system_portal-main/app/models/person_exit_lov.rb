class PersonExitLov < ApplicationRecord
  belongs_to :user, -> {where del_status: false}, class_name: "User", foreign_key: :user_id
  belongs_to :entity_info, -> { where del_status: false }, class_name: "EntityInfo", foreign_key: :entity_code#, optional: true


  validates :exit_desc, presence: true

end
