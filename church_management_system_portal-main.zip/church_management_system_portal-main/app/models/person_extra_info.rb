class PersonExtraInfo < ApplicationRecord

  belongs_to :person_info, -> { where active_status: true }, class_name: "PersonInfo", foreign_key: :person_assigned_code
  belongs_to :emp_status_master, -> { where active_status: true }, class_name: "EmpStatusMaster", foreign_key: :emp_status_code
  belongs_to :marital_status_master, -> { where active_status: true }, class_name: "MaritalStatusMaster", foreign_key: :marital_status_code#, optional: true
  belongs_to :disability_master, -> { where active_status: true }, class_name: "DisabilityMaster", foreign_key: :physical_disability#, optional: true






  def self.person_xtra_join
    joins("left join person_infos psi on psi.assigned_code = person_extra_infos.person_assigned_code
           left join emp_status_masters esm on esm.assigned_code = person_extra_infos.emp_status_code").where("psi.active_status = true")

  end

  def self.person_xtra_join2(emp = "")
    joins("left join person_infos psi on psi.assigned_code = person_extra_infos.person_assigned_code
           left join emp_status_masters esm on esm.assigned_code = person_extra_infos.emp_status_code").where("psi.active_status = true")

  end

end
