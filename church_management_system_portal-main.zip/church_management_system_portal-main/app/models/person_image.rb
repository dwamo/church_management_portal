class PersonImage < ApplicationRecord
  belongs_to :person_info, -> { where active_status: true }, class_name: "PersonInfo", foreign_key: :person_assigned_code
  # belongs_to :person_issues_log, class_name: "PersonIssuesLog", foreign_key: :person_assigned_code
  # belongs_to :payment_info, -> { where active_status: true }, class_name: "PaymentInfo", foreign_key: :person_assigned_code

end
