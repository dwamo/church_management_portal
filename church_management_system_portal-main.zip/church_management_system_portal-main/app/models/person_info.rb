class PersonInfo < ApplicationRecord
  self.primary_key = :assigned_code

  attr_accessor :job_type_code, :job_title, :div_code #from person_emp_infos table
  attr_accessor :person_assigned_code, :contact_number, :contact_email, :res_addr, :postal_addr, :res_region_code, :res_city_town_id,
                :marital_status_code, :emp_status_code, :physical_disability, :day_born,
                :location_addr, :emp_loc_addr, :emp_loc_city_town_id, :emp_loc_region_code,
                :emp_postal_addr, :confirmation_date, :baptism_date #from person_emp_infos #from person_contact_infos AND person_extra_infos
  attr_accessor :person_role_code, :sub_entity_code, :entity_division_code, :entity_sub_div, :relation_person_code, :relation_last_name,
                :relation_first_name, :relation_other_names, :relationship_code, :group_code,
                :image_data, :condition_type_code, :start_date, :end_date, :facility_type, :facility_name #from entity_extra_info table, person_sub_entity_infos, person_relation_infos, person_group_infos, person_images,care_giving_infos
  attr_accessor :p_code, :job_cat, :disability, :exit_lov_id, :cause, :exit_comment, :exit_church, :exit_branch, :exit_assigned
  
  belongs_to :user, -> { where active_status: true }, class_name: "User", foreign_key: :user_id
  belongs_to :entity_info, -> { where del_status: false }, class_name: "EntityInfo", foreign_key: :entity_info_code#, optional: true

  has_many :person_extra_infos, -> { where active_status: true }, class_name: "PersonExtraInfo", foreign_key: :person_assigned_code #, optional: true
  has_many :person_disability_infos, -> { where active_status: true }, class_name: "PersonDisabilityInfo", foreign_key: :person_assigned_code #, optional: true
  has_many :person_contact_infos, -> { where active_status: true }, class_name: "PersonContactInfo", foreign_key: :person_assigned_code
  # has_many :emp_status_masters, class_name: "EmpStatusMaster", foreign_key: :person_assigned_code
  has_many :entity_extra_infos, -> { where active_status: true }, class_name: "EntityExtraInfo", foreign_key: :person_assigned_code
  has_many :person_sub_entity_infos, -> { where del_status: false }, class_name: "PersonSubEntityInfo", foreign_key: :person_assigned_code
  has_many :person_relation_infos, -> { where active_status: true }, class_name: "PersonRelationInfo", foreign_key: :person_assigned_code
  has_many :person_group_infos, -> { where active_status: true }, class_name: "PersonGroupInfo", foreign_key: :person_assigned_code
  has_many :person_emp_infos, -> { where active_status: true }, class_name: "PersonEmpInfo", foreign_key: :person_assigned_code
  has_many :person_images, -> { where active_status: true }, class_name: "PersonImage", foreign_key: :person_assigned_code
  has_many :person_contrib_setups, -> { where active_status: true }, class_name: "PersonContribSetup", foreign_key: :person_assigned_code
  has_many :payment_infos, class_name: "PaymentInfo", foreign_key: :person_assigned_code
  has_many :person_exit_infos, -> { where del_status: false }, class_name: "PersonExitInfo", foreign_key: :person_assigned_code

  validates :last_name, presence: true
  validates :first_name, presence: true
  validates :birth_date, presence: true
  validates :gender, presence: true
  validates :res_addr, presence: true
  validates :entity_info_code, presence: true
  validates :entity_division_code, presence: true
  validates :sub_entity_code, presence: true
  validates :contact_number, presence: {message: " Cannot be empty."}, format: {with: /^\d+(,\d+)*$/, message: "Must be numbers only.", multiline: true}


  def self.to_csv(options = {})
    column_heads = %w{Division_name SMS_Processing_ID Contact_number Msg_body Delivery_status Date}
    CSV.generate(options) do |csv|
      csv << column_heads
      all.each do |sms_delivery_report_matview|
        @division_name = sms_delivery_report_matview.division_name
        @sms_processing_id = sms_delivery_report_matview.sms_processing_id
        @contact_number = sms_delivery_report_matview.contact_number
        @msg_body = sms_delivery_report_matview.msg_body
        # @vote= sms_delivery_report_matview.vote
        # @vote= sms_delivery_report_matview.vote
        @status = if sms_delivery_report_matview.delivery_status
                    "Delivered"
                  elsif sms_delivery_report_matview.delivery_status == false
                    "Pending"
                  else

                  end
        @created_at = sms_delivery_report_matview.created_at.strftime("%F %R")

        csv << [@division_name, @sms_processing_id, @contact_number, @msg_body, @status, @created_at]
      end
    end
  end

  def self.daily_query(division_code)
    @res = PersonExtraInfo.find_by_sql("select day_born, COUNT(day_born) from (select to_char(created_at, 'YYYY-MM-DD') as date,
       CASE WHEN day_born = 'MON' THEN 'Monday' WHEN day_born = 'TUE' = 'Tuesday' WHEN day_born = 'WED' THEN 'Wednesday'
       WHEN day_born = 'THU' = 'Thursday' WHEN day_born = 'FRI' THEN 'Friday' WHEN day_born = 'SAT' = 'Saturday' WHEN day_born = 'SUN' THEN 'Sunday'  ELSE 'Nil' END AS day_born from person_infos WHERE active_status = true ")

    @res = PersonInfo.find_by_sql("select delivery_state, COUNT(delivery_state), date from (select to_char(created_at, 'YYYY-MM-DD') as date, CASE WHEN delivery_status = true THEN 'delivered'
       WHEN delivery_status = false THEN 'undelivered' ELSE 'sent' END AS delivery_state from sms_delivery_report_matviews WHERE division_code = '#{division_code}') AS first_query
       group by date, delivery_state")
    @res
  end

  def self.pie_query_res(division_code)
    result = []
    @res = pie_chart_query_m(division_code)
    @res.each do |res|
      result << ["#{res.delivery_state}", res.count]
    end
    result
  end

  # function for sms
  def self.sending_sms(recipient_number, assigned_code, entity_info_code)
    resp_code = resp_desc = nil
    message_body = "Dear '#{assigned_code}' you are welcome to '#{entity_info_code}' Family.
    Global membership ID: XXXXX
    Local membership ID: YYYYY
    Thank you"

    # sender_id = "'#{entity_info_code[0..-5]}'"

    sender_id = "CH_name"
    logger.info "SENDING REQUEST TO API NOW"
    logger.info sender_id

    r_connection = SmsEndPoint::CoreConnect.new
    begin
      res = r_connection.connection.post do |req|
        req.url '/req_send_sms'
        req.body = JSON.generate(
          {
            sender_id: sender_id,
            recipient_number: recipient_number,
            message_body: message_body
          }
        )
        logger.info req.body
      end

      logger.info "Result from API: #{res.status}  #{res.body}"
      resp = JSON.parse(res.body)
      logger.info "Response Body :: #{resp.inspect}"
      resp_code = resp['resp_code']
      resp_desc = resp['resp_desc']
      if resp_code == '000'
        logger.info "+++++++++++ SUCCESS  +++++++++++++"
        # display resp_desc
      else
        logger.info "+++++++++++ FAILED  +++++++++++++"
        # display resp_desc
      end

    rescue JSON::ParserError => e
      logger.info "JSON Parser Error ==============="
      resp_code = "001"
      resp_desc = "Sorry, There was an issue. Kindly check and try again."

    rescue Faraday::SSLError
      logger.info "SSL Error ==============="
      resp_code = "002"
      resp_desc = "Sorry, There was an issue. Kindly check and try again."
    rescue Faraday::TimeoutError
      logger.info "Timeout Error ================="
      respond_to do |format|
        format.html { redirect_to person_infos_url, notice: "Sorry, There was a timeout issue. Kindly check and try again." }
        format.json { head :no_content }
      end
      # rescue Faraday::Error::ConnectionFailed => e
    rescue Faraday::ConnectionFailed => e
      logger.info "Connection Failed ================"
      logger.info "Error message :: #{e} ==================="
      resp_code = "003"
      resp_desc = "Sorry, There was a connection issue. Kindly check and try again."
    end

    return resp_code, resp_desc

  end

  def self.gen_person_code
    sql = "select nextval('person_info_seq')"
    val = ActiveRecord::Base.connection.execute(sql)
    val = val.values[0][0]
    logger.info "For Customer ID, #{val}"
    code = "%09d" % val
    "#{code}"
  end

  def self.update_last_but_one(table_name, assigned_code, old_updated_at)
    sql = "UPDATE #{table_name} SET active_status = true, del_status = false, updated_at = '#{old_updated_at}' WHERE assigned_code = '#{assigned_code}' order by id desc limit 1"
    val = ActiveRecord::Base.connection.execute(sql)
  end

  # def test_join
  #   joins("left join person_extra_infos pxi on pxi.person_assigned_code = person_infos.assigned_code AND pxi.active_status = true AND pxi.del_status = false").select extract(year from age(birth_date)) as age, id from person_infos where gender = '#{gender}'
  #   AND birth_date IS NOT NULL order by birth_date asc
  # end

  # def self.gender
  #   "SELECT SUM(CASE WHEN Gender = 'M' THEN 1 ELSE 0 END) as male_count, SUM(CASE WHEN gender = 'F' THEN 1 ELSE 0 END) as female_count FROM person_infos;"
  # end

  def self.person_branch_2
    joins("left join person_sub_entity_infos pse on pse.person_assigned_code = person_infos.assigned_code and pse.active_status = true
           left join person_extra_infos pxi on pxi.person_assigned_code = person_infos.assigned_code and pxi.active_status = true").where("pse.active_status = true AND person_infos.active_status = true")
  end

  def self.role_condition(conditions)
      "select case when age >= 0 and age <= 17 then '0 - 17' when age >= 18 and age <= 25 then '18 - 25' when age >= 26 and age <= 35 then '26 - 35' when age >= 36 and age <= 50 then '36 - 50' when age >= 51 and age <= 70 then '51 - 70' when age >= 71 and age <= 120 then '71 - 120' end as age_range, count(id) as member_number from (select extract(year from age(birth_date)) as age, person_infos.id from person_infos
 left join person_extra_infos pxi on pxi.person_assigned_code = person_infos.assigned_code
 left join person_sub_entity_infos psei on psei.person_assigned_code = person_infos.assigned_code AND pxi.active_status = true AND pxi.del_status = false where #{conditions} order by birth_date asc) as age_range_table group by age_range order by age_range;"
  end


  def self.gender_dist(current_user, gender = "")
    # conditions = ""
    role_conds = gender.present? ? ["gender = '#{gender}' AND birth_date IS NOT NULL AND person_infos.active_status = true AND psei.active_status = true"] : ["birth_date IS NOT NULL AND person_infos.active_status = true AND psei.active_status = true"]

    if current_user.super_admin? || current_user.user_admin?
      dynamic_role = ""
    elsif current_user.merchant_admin?
      dynamic_role = "person_infos.entity_info_code = '#{current_user.user_main_code}'"
    elsif current_user.branch_admin?
      dynamic_role = "psei.sub_entity_code = '#{current_user.user_branch_code}'"
    else
      dynamic_role = ""
    end
    role_conds << dynamic_role if dynamic_role.present?
    conditions = role_conds.join(" AND ")
    role_condition(conditions)
  end

  # For confirmation summary on the membership page
  def self.person_branch_join(params)
    joins("left join person_sub_entity_infos pse on pse.person_assigned_code = person_infos.assigned_code and pse.active_status = true")
      .select("person_infos.id, person_infos.last_name, person_infos.first_name, person_infos.birth_date, person_infos.assigned_code, pse.sub_entity_code").where("lower(last_name) = '#{params[:lastname].downcase}' and lower(first_name) = '#{params[:firstname].downcase}' and birth_date = '#{params[:dateofbirth]} 00:00:00' and entity_info_code = '#{params[:churchname]}' and person_infos.active_status = true and person_infos.del_status = false")
  end

  # For Index table
  def self.persons_join
    joins("left join person_extra_infos pxi on pxi.person_assigned_code = person_infos.assigned_code
           left join person_contact_infos pci on pci.person_assigned_code = person_infos.assigned_code
           left join person_sub_entity_infos pse on pse.person_assigned_code = person_infos.assigned_code
           left join sub_entity_infos sei on sei.assigned_code = pse.sub_entity_code
           left join entity_sub_divisions esd on esd.assigned_code = sei.entity_sub_div_code
           left join entity_divisions edv on edv.assigned_code = esd.entity_division_code
           left join entity_infos eis on eis.assigned_code = person_infos.entity_info_code
          ").select("person_infos.assigned_code, person_infos.last_name, person_infos.first_name, person_infos.other_names, person_infos.gender, person_infos.active_status AS person_status, person_infos.del_status, person_infos.status, person_infos.user_id, person_infos.created_at,person_infos.entity_info_code AS entity_code,pxi.id AS person_extra_id, pxi.marital_status_code AS marital_status_id, pxi.emp_status_code AS emp_status_id, pxi.disability AS physical_disability_id, pxi.day_born AS day_of_birth,pse.sub_entity_code AS branch_code, pse.active_status AS branch_status,eis.entity_name, edv.division_name AS div_name, esd.sub_division_desc AS sub_div, sei.sub_entity_name AS branch_name").where("person_infos.active_status = true AND person_infos.del_status = false AND pse.del_status = false AND pci.active_status = true AND pxi.del_status = false AND eis.del_status = false AND sei.del_status = false AND esd.del_status = false AND edv.del_status = false")
  end

end
