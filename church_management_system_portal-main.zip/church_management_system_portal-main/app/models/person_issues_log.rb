class PersonIssuesLog < ApplicationRecord
  # self.primary_key = :person_assigned_code
  self.table_name = :person_issues_log
  belongs_to :person_info, -> { where active_status: true }, class_name: "PersonInfo", foreign_key: :person_assigned_code
  belongs_to :sub_entity_info, -> { where active_status: true }, class_name: "SubEntityInfo", foreign_key: :sub_entity_code

  has_many :person_images, -> { where active_status: true }, class_name: "PersonImage", foreign_key: :person_assigned_code



end
