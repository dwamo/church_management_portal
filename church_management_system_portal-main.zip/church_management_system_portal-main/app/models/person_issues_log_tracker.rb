class PersonIssuesLogTracker < ApplicationRecord
  self.table_name = :person_issues_log_tracker
  belongs_to :person_issues_log, class_name: "PersonIssuesLog", foreign_key: :person_issues_log_id
  belongs_to :person_info, -> { where active_status: true }, class_name: "PersonInfo", foreign_key: :person_assigned_code
  belongs_to :user, -> { where active_status: true }, class_name: "User", foreign_key: :user_id

  validates :comment, presence: true


end
