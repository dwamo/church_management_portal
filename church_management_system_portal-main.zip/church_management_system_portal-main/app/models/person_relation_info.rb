class PersonRelationInfo < ApplicationRecord
  belongs_to :person_info, -> { where active_status: true }, class_name: "PersonInfo", foreign_key: :relation_person_code
  belongs_to :relationship_master, -> { where active_status: true }, class_name: "RelationshipMaster", foreign_key: :relationship_code
  # belongs_to :relationship_master, -> { where active_status: true }, class_name: "RelationshipMaster", foreign_key: :relation_person_code


end
