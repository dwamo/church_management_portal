class PersonRoleMaster < ApplicationRecord
  self.primary_key = :assigned_code
  belongs_to :user, -> {where active_status: true}, class_name: "User", foreign_key: :user_id
  belongs_to :entity_info, -> { where active_status: true }, class_name: "EntityInfo", foreign_key: :entity_code#, optional: true


  validates :role_desc, presence: true





  def self.gen_person_role_code
    sql = "select nextval('person_role_seq')"
    val = ActiveRecord::Base.connection.execute(sql)
    val = val.values[0][0]
    logger.info "For Person_role  ID, #{val}"
    code = "%09d" % val
    "#{code}"
  end
end
