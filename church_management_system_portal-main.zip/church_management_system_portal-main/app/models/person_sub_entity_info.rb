class PersonSubEntityInfo < ApplicationRecord

  belongs_to :sub_entity_info, -> { where del_status: false }, class_name: "SubEntityInfo", foreign_key: :sub_entity_code
  belongs_to :person_info, -> { where del_status: false }, class_name: "PersonInfo", foreign_key: :person_assigned_code

end
