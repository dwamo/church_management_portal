class RegionMaster < ApplicationRecord
  self.primary_key = :region_code

  has_many :city_town_masters, -> {where active_status: true}, class_name: "CityTownMaster", foreign_key: :region_code
  has_many :person_contact_infos, -> {where active_status: true}, class_name: "PersonContactInfo", foreign_key: :res_region_code#, optional: true
  has_many :person_emp_infos, -> {where active_status: true}, class_name: "PersonEmpInfo", foreign_key: :emp_loc_region_code#, optional: true
  belongs_to :user, -> {where active_status: true}, class_name: "User", foreign_key: :user_id

  validates :region_desc, presence: true





end
