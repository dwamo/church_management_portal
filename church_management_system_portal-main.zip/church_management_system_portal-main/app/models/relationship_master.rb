class RelationshipMaster < ApplicationRecord
  self.primary_key = :assigned_code
  belongs_to :user, -> {where active_status: true}, class_name: "User", foreign_key: :user_id
  has_many :person_relation_infos, -> { where active_status: true }, class_name: "PersonRelationInfo", foreign_key: :relationship_code#, optional: true

  validates :assigned_code, presence: true
  validates :relationship_desc, presence: true
  validates_uniqueness_of :assigned_code, :message => "already exists"







  

end
