class SubEntityContrib < ApplicationRecord
  attr_accessor :entity_division_code, :entity_info_code, :entity_sub_div_code

  belongs_to :user, class_name: "User", foreign_key: :user_id
  belongs_to :sub_entity_info, class_name: "SubEntityInfo", foreign_key: :sub_entity_code
  belongs_to :contrib_type, class_name: "ContribType", foreign_key: :contribution_type_code
  has_many :payment_infos, -> { where status: true }, class_name: "PaymentInfo", foreign_key: :product_id



  validates :amount, presence: {message: " Cannot be empty."}, numericality: { :greater_than_or_equal_to => 1 } #, format: {with: /^\+?(0|[1-9]\d*)$/, message: "Must be numbers only.", multiline: true}
  validates :sub_entity_code, presence: {message: " Cannot be empty."}
  validates :contribution_name, presence: {message: " Cannot be empty."}
  # validates :start_date, presence: {message: " Cannot be empty."}
  # validates :end_date, presence: {message: " Cannot be empty."}
  validates :contribution_type_code, presence: {message: " Cannot be empty."}

  











  

end
