class SubEntityInfo < ApplicationRecord
  self.primary_key = :assigned_code
  attr_accessor :entity_div
  
  belongs_to :entity_info, -> {where active_status: true}, class_name: "EntityInfo", foreign_key: :entity_code#, optional: true
  belongs_to :entity_sub_division, -> {where active_status: true}, class_name: "EntitySubDivision", foreign_key: :entity_sub_div_code
  belongs_to :user, -> {where active_status: true}, class_name: "User", foreign_key: :user_id
  has_many :person_sub_entity_infos, -> { where active_status: true }, class_name: "PersonSubEntityInfo", foreign_key: :sub_entity_code
  has_many :entity_extra_infos, -> { where active_status: true }, class_name: "EntityExtraInfo", foreign_key: :sub_entity_code

  validates :sub_entity_name, presence:true
  validates :sub_entity_alias, :length => {:minimum => 4,:maximum => 15, message: "should be a minimum of 4 characters and should not exceed 15 characters"}
  validates :entity_code, presence: true
  validates :entity_sub_div_code, presence: true



  def self.gen_sub_entity_code
    sql = "select nextval('sub_entity_infos_seq')"
    val = ActiveRecord::Base.connection.execute(sql)
    val = val.values[0][0]
    logger.info "For SubEntityInfo ID, #{val}"
    code = "%09d" % val
    "#{code}"
  end

end
