class User < ApplicationRecord
  attr_accessor :role_code, :main_code, :div_code, :logo_path, :logo_data, :sub_entity_code, :comment

  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable, :recoverable, :rememberable, :validatable, :timeoutable

  has_many :user_roles, -> { where active_status: true }, class_name: "UserRole", foreign_key: :user_id#, optional: true
  has_many :entity_info, -> {where active_status: true}, through: :user_roles, primary_key: :main_code
  has_many :entity_division, -> {where active_status: true}, through: :user_roles, primary_key: :div_code
  has_many :roles, -> { where active_status: true }, through: :user_roles, primary_key: :unique_code
  has_many :user_boards, -> { where active_status: true }, class_name: "UserBoard", foreign_key: :user_id

  # belongs_to :entity_info, -> { where active_status: true }, class_name: "EntityInfo", foreign_key: :main_code, optional: true
  # has_and_belongs_to_many :user_roles, foreign_key: :user_id



  default_scope {where(active_status: true)}
  validates_uniqueness_of :username, :message => "already taken"
  validates :username, presence: {message: "Cannot be empty"}, format: { with: /^[a-zA-Z0-9 .-]*$/, message: "should be letters only", multiline: true }
  validates :lastname, presence: {message: "Cannot be empty"}, format: { with: /^[a-zA-Z .-]*$/, message: "should be letters only", :multiline => true }
  validates :other_name, format: { with: /^[a-zA-Z .-]*$/, message: "should be letters only", :multiline => true }
  validates :email, format: { with: URI::MailTo::EMAIL_REGEXP }
  validates :role_code, presence: {message: "Select role"}
  validate :validate_entity_code
  validate :validate_div_code

  def validate_entity_code
    if self.roles&.first && self.roles&.first.unique_code == "MA"
      unless self.main_code.present?
        errors.add :main_code, " cannot be empty."
      end
    end
  end

  def validate_div_code
    if self.roles&.first && self.roles&.first.unique_code == "DA"
      unless self.div_code.present?
        errors.add :div_code, " cannot be empty."
      end
    end
  end

  def self.user_join
    joins("left join user_roles ur on ur.user_id = users.id  AND ur.del_status = false
           left join entity_infos eis on eis.assigned_code = ur.main_code AND eis.del_status = false
           left join entity_divisions edv on edv.assigned_code = ur.div_code AND edv.del_status = false
           left join sub_entity_infos sei on sei.assigned_code = ur.sub_entity_code AND sei.del_status = false
    ").select("users.id, users.email, users.lastname, users.other_name, users.username, users.mobile_number, users.active_status AS status, users.created_at, eis.entity_name AS church_name, edv.division_name AS div_name, sei.sub_entity_name AS branch_name")
      .where("users.del_status = false")
  end


  def super_admin?
    self.roles&.first.unique_code == "SA" if self.roles&.first
  end
  def user_admin?
    self.roles&.first.unique_code == "UA" if self.roles&.first
  end
  def merchant_admin?
    self.roles&.first.unique_code == "MA" if self.roles&.first
  end
  def division_admin?
    self.roles&.first.unique_code == "DA" if self.roles&.first
  end
  def branch_admin?
    self.roles&.first.unique_code == "BA" if self.roles&.first
  end
  def branch_user?
    self.roles&.first.unique_code == "BU" if self.roles&.first
  end

  def user_main_code
    user_role_obj = self.user_roles&.order(created_at: :desc).first
    user_role_obj ? user_role_obj.main_code : ""
  end

  def user_div_code
    user_role_div_obj = self.user_roles&.order(created_at: :desc).first
    user_role_div_obj ? user_role_div_obj.div_code : ""
  end

  def user_branch_code
      user_role_branch_obj = self.user_roles&.order(created_at: :desc).first
      user_role_branch_obj ? user_role_branch_obj.sub_entity_code : ""
  end


 def user_role_code
      user_role_branch_obj = self.user_roles&.order(created_at: :desc).first
      user_role_branch_obj ? user_role_branch_obj.role_code : ""
  end


end
