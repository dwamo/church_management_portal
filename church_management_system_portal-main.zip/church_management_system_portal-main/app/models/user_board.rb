class UserBoard < ApplicationRecord

  belongs_to :user, -> { where active_status: true }, class_name: "User", foreign_key: :user_id


end
