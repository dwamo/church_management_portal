require "cloudinary"

Cloudinary.config do |config|
  config.cloud_name = 'appsnmob'
  config.api_key = '461494615625846'
  config.api_secret = 'kEDJlg4uJOKU5pZ9nyXrz4qzOUU'
  config.secure = true
  config.cdn_subdomain = true
  
end
