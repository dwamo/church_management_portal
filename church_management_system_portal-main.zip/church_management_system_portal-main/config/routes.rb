Rails.application.routes.draw do
  # get 'home/index'
  devise_for :users#, :skip => [:registrations]
  devise_scope :user do
    get '/users/sign_up' => 'users#sign_in'
  end
  as :user do
    # get '/users/edit' => 'devise/registrations#edit', :as => 'edit_user_registration'
    # patch 'users' => 'devise/registrations#update', :as => 'user_registration'
  end

  get 'home/dashboard'
  root 'home#index'

  # USERS ROUTES
  get '/users' => 'users#index'
  get '/users/new' => 'users#new', :as => 'new_user'
  get '/users/:id/edit' => 'users#edit', :as => 'edit_user'
  get '/users/:id' => 'users#show', :as => 'user'
  get '/users/user_details_page' => 'users#user_details_page', :as => 'user_details_page'

  delete 'users/:id' => 'users#destroy'
  patch '/users/:id' => 'users#update', :as => 'update_user'
  get '/user_index' => 'users#users_index', :as => 'users_index'
  post 'create_user' => 'users#create'
  post '/users/channel_update', :as => 'general_channel_ajax_call'

  # ENABLE ROUTES
  get 'enable_user' => 'users#enable_user'
  get 'enable_sms_gateway' => 'sms_gateways#enable_sms_gateway'
  get 'enable_entity_info' => 'entity_infos#enable_entity_info'
  get 'enable_entity_div' => 'entity_divisions#enable_entity_div'
  get 'enable_division' => 'entity_divisions#enable_division'

  get '/person_infos/:person_id/enable_form' => 'person_infos#enable_form', :as => 'enable_form'
  patch 'person_infos/:person_id/enable_member' => 'person_infos#enable_member', :as=> 'enable_member'

  # DISABLE ROUTES
  get 'disable_user' => 'users#disable_user'
  get 'disable_sms_gateway' => 'sms_gateways#disable_sms_gateway'
  get 'disable_entity_info' => 'entity_infos#disable_entity_info'
  get 'disable_entity_div' => 'entity_divisions#disable_entity_div'
  get 'disable_division' => 'entity_divisions#disable_division'

  get '/person_infos/:person_id/disable_form' => 'person_infos#disable_form', :as => 'disable_form'
  patch 'person_infos/:person_id/disable_member' => 'person_infos#disable_member', :as=> 'disable_member'

  # DETAILS MODAL
  get 'person_detail_show/:person_id' => 'person_infos#person_detail_show', :as => 'person_detail_show'
  get 'person_exit_info_index/:person_id' => 'person_infos#person_exit_info_index', :as => 'person_exit_info_index'
  get 'entity_show/:entity_id' => 'entity_infos#entity_show', :as => 'entity_show'
  get 'payment_show/:pay_id' => 'payment_infos#payment_show', :as => 'payment_show'

  # SETUPS TAB(Index Pages)
  get '/entity_infos/entity_infos_index' => 'entity_infos#entity_infos_index', :as => 'entity_infos_index'
  get '/entity_divisions/entity_divisions_index' => 'entity_divisions#entity_division_index', :as => 'entity_division_index'
  get '/entity_divisions/entity_div_index' => 'entity_divisions#entity_div_index', :as => 'entity_div_index'
  get '/sub_entity_infos/sub_entity_infos_index' => 'sub_entity_infos#sub_entity_infos_index', :as => 'sub_entity_infos_index'
  get '/person_infos/person_infos_index' => 'person_infos#person_infos_index', :as => 'person_infos_index'
  get '/job_cats/job_cats_index' => 'job_cats#job_cats_index', :as => 'job_cats_index'
  get '/job_types/job_types_index' => 'job_types#job_types_index', :as => 'job_types_index'
  get '/person_emp_infos/person_emp_infos_index' => 'person_emp_infos#person_emp_infos_index', :as => 'person_emp_infos_index'
  get '/region_masters/region_masters_index' => 'region_masters#region_masters_index', :as => 'region_masters_index'
  get '/city_town_masters/city_town_masters_index' => 'city_town_masters#city_town_masters_index', :as => 'city_town_masters_index'
  get '/entity_sub_divisions/entity_sub_divisions_index' => 'entity_sub_divisions#entity_sub_divisions_index', :as => 'entity_sub_divisions_index'
  get '/person_role_masters/person_role_masters_index' => 'person_role_masters#person_role_masters_index', :as => 'person_role_masters_index'
  get '/contrib_types/contrib_types_index' => 'contrib_types#contrib_types_index', :as => 'contrib_types_index'

  get '/disability_masters/disability_masters_index' => 'disability_masters#disability_masters_index', :as => 'disability_masters_index'
  get '/marital_status_masters/marital_status_masters_index' => 'marital_status_masters#marital_status_masters_index', :as => 'marital_status_masters_index'
  get '/emp_status_masters/emp_status_masters_index' => 'emp_status_masters#emp_status_masters_index', :as => 'emp_status_masters_index'
  get '/person_condition_types/person_condition_types_index' => 'person_condition_types#person_condition_types_index', :as => 'person_condition_types_index'
  get '/sub_entity_infos/sub_entity_infos_index_div' => 'sub_entity_infos#sub_entity_infos_index_div', :as => 'sub_entity_infos_index_div'
  get '/relationship_masters/relationship_masters_index' => 'relationship_masters#relationship_masters_index', :as => 'relationship_masters_index'
  get '/group_cats/group_cats_index' => 'group_cats#group_cats_index', :as => 'group_cats_index'
  get '/group_masters/group_masters_index' => 'group_masters#group_masters_index', :as => 'group_masters_index'
  get '/sub_entity_contribs/sub_entity_contribs_index' => 'sub_entity_contribs#sub_entity_contribs_index', :as => 'sub_entity_contribs_index'
  get '/care_giving_infos/care_giving_infos_index' => 'care_giving_infos#care_giving_infos_index', :as => 'care_giving_infos_index'
  get '/person_contrib_setups/person_contrib_setups_index' => 'person_contrib_setups#person_contrib_setups_index', :as => 'person_contrib_setups_index'
  get '/entity_sub_divisions/entity_sub_div_main' => 'entity_sub_divisions#entity_sub_div_main', :as => 'entity_sub_div_main'
  get '/payment_infos/payment_infos_index' => 'payment_infos#payment_infos_index', :as => 'payment_infos_index'
  get '/person_issues_log_trackers/person_issues_index' => 'person_issues_log_trackers#person_issues_index', :as => 'person_issues_index'
  get '/home/home_index' => 'home#home_index', :as => 'home_index'
  get '/person_exit_lovs/person_exit_lovs_index' => 'person_exit_lovs#person_exit_lovs_index', :as => 'person_exit_lovs_index'
  get '/person_exit_infos/person_exit_infos_index' => 'person_exit_infos#person_exit_infos_index', :as => 'person_exit_infos_index'

  # NEW, CREATE AND UPDATE
  patch '/sub_entity_infos/:sub_info_id' => 'sub_entity_infos#update_sub_info', :as => 'update_sub_info'
  post 'create_entity_info' => 'entity_infos#create'
  post 'create_entity_div' => 'entity_divisions#create_entity_div'
  post 'create_reply_person' => 'person_issues_log_trackers#create_reply_person'

  get '/entity_divisions/new_entity_div' => 'entity_divisions#new_entity_div', :as => 'new_entity_div'
  get '/entity_sub_divisions/new_sub_div' => 'entity_sub_divisions#new_sub_div', :as => 'new_sub_div'
  get '/entity_divisions/:id/edit_entity_div' => 'entity_divisions#edit_entity_div', :as => 'edit_entity_div'
  get '/entity_sub_divisions/:id/edit_sub_div' => 'entity_sub_divisions#edit_sub_div', :as => 'edit_sub_div'
  get '/sub_entity_infos/new_sub_entity' => 'sub_entity_infos#new_sub_entity', :as => 'new_sub_entity'
  get '/sub_entity_infos/:sub_info_id/edit_sub_entity' => 'sub_entity_infos#edit_sub_entity', :as => 'edit_sub_entity'
  get '/sub_entity_infos/:sub_info_id/edit_sub_entity2' => 'sub_entity_infos#edit_sub_entity2', :as => 'edit_sub_entity2'
  get 'pic_modal/:person_id' => 'person_infos#pic_modal', :as => 'pic_modal'
  get '/person_issues_log_trackers/new_reply' => 'person_issues_log_trackers#new_reply', :as => 'new_reply'


  # AJAX ROUTES
  post '/person_infos/person_update', :as => 'person_infos_ajax_call'
  post '/person_infos/person_update1b', :as => 'person_infos_ajax_call1b'
  post '/person_infos/person_update2', :as => 'person_infos_ajax_call2'
  post '/person_infos/person_update3', :as => 'person_infos_ajax_call3'
  post '/person_infos/person_update3b', :as => 'person_infos_ajax_call3b'
  post '/person_infos/person_update3c', :as => 'person_infos_ajax_call3c'
  post '/person_infos/church_update_rel', :as => 'church_update_rel_ajax_call'
  post '/group_masters/group_update', :as => 'group_masters_ajax_call'
  post '/sub_entity_infos/entity_update', :as => 'entity_update_ajax'
  
  post '/sub_entity_infos/entity_update2', :as => 'entity_update_ajax2'
  post '/person_infos/person_check', :as => 'person_infos_exist_ajax_call'
  post '/sub_entity_contribs/contrib_update1', :as => 'person_contrib_ajax_call1'
  post '/sub_entity_contribs/contrib_update2', :as => 'person_contrib_ajax_call2'
  post '/sub_entity_contribs/contrib_update3', :as => 'person_contrib_ajax_call3'
  post '/entity_sub_divisions/entity_update', :as => 'entity_ajax_call'
  post '/person_contrib_setups/contrib_update', :as => 'contrib_ajax_call'
  post '/person_contrib_setups/contrib_has_frequency', :as => 'contrib_has_frequency_ajax_call'


  resources :person_exit_lovs
  resources :person_exit_infos
  resources :payment_requests

  resources :person_issues_log_trackers
  resources :person_issues_logs
  resources :issue_log_types
  resources :person_contribs
  resources :payment_infos
  resources :user_boards
  resources :sub_entity_contribs
  resources :care_giving_infos
  resources :person_images
  resources :group_masters
  resources :person_group_infos
  resources :group_cats
  resources :person_contrib_setups
  resources :person_relation_infos
  resources :relationship_masters
  resources :person_sub_entity_infos
  resources :person_condition_types
  resources :emp_status_masters
  resources :marital_status_masters
  resources :disability_masters
  resources :person_disability_infos
  resources :contrib_types
  resources :person_role_masters
  resources :person_extra_infos
  resources :city_town_masters
  resources :region_masters
  resources :person_contact_infos
  resources :entity_info_boards
  resources :entity_extra_infos
  resources :person_emp_infos
  resources :job_types
  resources :job_cats
  resources :person_infos
  resources :entity_sub_divisions
  resources :permissions_roles
  resources :permissions
  resources :entity_divisions
  resources :sub_entity_infos
  resources :entity_infos
  resources :user_roles
  # resources :users
  resources :roles

end
