class CreateUsers < ActiveRecord::Migration[6.1]
  def change
    create_table :users do |t|
      t.string :lastname
      t.string :other_name
      t.string :username
      t.string :mobile_number
      t.string :email
      t.boolean :active_status
      t.boolean :del_status
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps

      t.index ["lastname"], name: "users_lastname_idx"
      t.index ["other_name"], name: "users_other_name_idx"
      t.index ["username"], name: "users_username_idx"
      t.index ["mobile_number"], name: "users_mobile_number_idx"
      t.index ["email"], name: "users_email_idx"
      t.index ["active_status"], name: "users_active_status_idx"
      t.index ["del_status"], name: "users_del_status_idx"
      t.index ["created_at"], name: "users_created_at_idx"
      t.index ["updated_at"], name: "users_updated_at_idx"
      t.index ["encrypted_password"], name: "users_encrypted_password_idx"
      t.index ["reset_password_token"], name: "users_reset_password_token_idx"
      t.index ["reset_password_sent_at"], name: "users_reset_password_sent_at_idx"
      t.index ["remember_created_at"], name: "users_remember_created_at"
      t.index ["updated_at"], name: "users_updated_at_idx"
    end
  end
end
