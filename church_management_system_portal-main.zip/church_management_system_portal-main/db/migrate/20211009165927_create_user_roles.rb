class CreateUserRoles < ActiveRecord::Migration[6.1]
  def change
    create_table :user_roles do |t|
      t.integer :user_id
      t.string :role_code
      t.string :main_code
      t.string :div_code
      t.boolean :active_status
      t.boolean :del_status
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      t.index ["user_id"], name: "user_roles_user_id_idx"
      t.index ["role_code"], name: "user_roles_role_code_idx"
      t.index ["main_code"], name: "user_roles_main_code_idx"
      t.index ["div_code"], name: "user_roles_div_code_idx"
      t.index ["active_status"], name: "user_roles_active_status_idx"
      t.index ["del_status"], name: "user_roles_del_status_idx"
      t.index ["created_at"], name: "user_roles_created_at_idx"
      t.index ["updated_at"], name: "user_roles_updated_at_idx"

    end
  end
end
