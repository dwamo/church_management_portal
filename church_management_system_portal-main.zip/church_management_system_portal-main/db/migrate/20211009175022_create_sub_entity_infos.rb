class CreateSubEntityInfos < ActiveRecord::Migration[6.1]
  def change
    create_table :sub_entity_infos do |t|
      t.string :assigned_code
      t.string :entity_division_code
      t.string :sub_entity_name
      t.string :sub_entity_alias
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps

      t.index ["assigned_code"], name: "sub_entity_infos_assigned_code_idx"
      t.index ["entity_division_code"], name: "sub_entity_infos_entity_division_code_idx"
      t.index ["sub_entity_name"], name: "sub_entity_infos_sub_entity_name_idx"
      t.index ["sub_entity_alias"], name: "sub_entity_infos_sub_entity_alias_idx"
      t.index ["comment"], name: "sub_entity_infos_comment_idx"
      t.index ["active_status"], name: "sub_entity_infos_active_status_idx"
      t.index ["del_status"], name: "sub_entity_infos_del_status_idx"
      t.index ["user_id"], name: "sub_entity_infos_user_id_idx"
      t.index ["created_at"], name: "sub_entity_infos_created_at_idx"
      t.index ["updated_at"], name: "sub_entity_infos_updated_at_idx"

    end
  end
end
