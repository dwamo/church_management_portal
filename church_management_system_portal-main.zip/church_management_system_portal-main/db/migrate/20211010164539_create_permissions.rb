class CreatePermissions < ActiveRecord::Migration[6.1]
  def change
    create_table :permissions do |t|
      t.string :subject_class
      t.string :action
      t.string :name
      t.string :description
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps

      t.index ["subject_class"], name: "permissions_subject_class_idx"
      t.index ["action"], name: "permissions_action_idx"
      t.index ["name"], name: "permissions_name_idx"
      t.index ["description"], name: "permissions_description_idx"
      t.index ["created_at"], name: "permissions_created_at_idx"
      t.index ["updated_at"], name: "permissions_updated_at_idx"

    end
  end
end
