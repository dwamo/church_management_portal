class CreatePermissionsRoles < ActiveRecord::Migration[6.1]
  def change
    create_table :permissions_roles do |t|
      t.integer :permission_id
      t.integer :role_id
      t.string :role_code

      t.timestamps

      t.index ["permission_id"], name: "permissions_roles_permission_id_idx"
      t.index ["role_id"], name: "permissions_roles_role_id_idx"
      t.index ["role_code"], name: "permissions_roles_role_code_idx"
      t.index ["created_at"], name: "permissions_roles_created_at"
      t.index ["updated_at"], name: "permissions_roles_updated_at_idx"
    end
  end
end
