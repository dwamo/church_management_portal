class CreateEntityDivisions < ActiveRecord::Migration[6.1]
  def change
    create_table :entity_divisions do |t|
      t.string :assigned_code
      t.string :entity_code
      t.string :division_name
      t.string :division_alias
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps

      t.index ["assigned_code"], name: "entity_divisions_assigned_code_idx"
      t.index ["entity_code"], name: "entity_divisions_entity_code_idx"
      t.index ["division_name"], name: "entity_divisions_division_name_idx"
      t.index ["division_alias"], name: "entity_divisions_division_alias_idx"
      t.index ["active_status"], name: "entity_divisions_active_status_idx"
      t.index ["del_status"], name: "entity_divisions_del_status_idx"
      t.index ["user_id"], name: "entity_divisions_user_id_idx"
      t.index ["created_at"], name: "entity_divisions_created_at_idx"
      t.index ["updated_at"], name: "entity_divisions_updated_at_idx"

    end
  end
end
