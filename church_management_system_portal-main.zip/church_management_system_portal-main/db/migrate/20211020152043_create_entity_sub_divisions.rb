class CreateEntitySubDivisions < ActiveRecord::Migration[6.1]
  def change
    create_table :entity_sub_divisions do |t|
      t.string :entity_division_code
      t.string :sub_division_desc
      t.string :sub_division_alias
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps

      t.index ["entity_division_code"], name: "entity_sub_divisions_entity_division_code_idx"
      t.index ["sub_division_desc"], name: "entity_sub_divisions_sub_division_desc_idx"
      t.index ["sub_division_alias"], name: "entity_sub_divisions_sub_division_alias_idx"
      t.index ["comment"], name: "entity_sub_divisions_comment_idx"
      t.index ["active_status"], name: "entity_sub_divisions_active_status_idx"
      t.index ["del_status"], name: "entity_sub_divisions_del_status_idx"
      t.index ["user_id"], name: "entity_sub_divisions_user_id_idx"
      t.index ["created_at"], name: "entity_sub_divisions_created_at_idx"
      t.index ["updated_at"], name: "entity_sub_divisions_updated_at_idx"
    end
  end
end
