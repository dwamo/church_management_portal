class CreatePersonInfos < ActiveRecord::Migration[6.1]
  def change
    create_table :person_infos do |t|
      t.string :assigned_code
      t.string :entity_info_code
      t.string :last_name
      t.string :first_name
      t.string :other_names
      t.timestamp :birth_date
      t.string :gender
      t.boolean :status
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      t.index ["assigned_code"], name: "person_infos_assigned_code_idx"
      t.index ["entity_info_code"], name: "person_infos_entity_info_code_idx"
      t.index ["last_name"], name: "person_infos_last_name_idx"
      t.index ["first_name"], name: "person_infos_first_name_idx"
      t.index ["other_names"], name: "person_infos_other_names_idx"
      t.index ["birth_date"], name: "person_infos_birth_date_idx"
      t.index ["gender"], name: "person_infos_gender_idx"
      t.index ["status"], name: "person_infos_status_idx"
      t.index ["comment"], name: "person_infos_comment_idx"
      t.index ["active_status"], name: "person_infos_active_status_idx"
      t.index ["del_status"], name: "person_infos_del_status_idx"
      t.index ["user_id"], name: "person_infos_user_id_idx"
      t.index ["created_at"], name: "person_infos_created_at_idx"
      t.index ["updated_at"], name: "person_infos_updated_at_idx"
    end
  end
end
