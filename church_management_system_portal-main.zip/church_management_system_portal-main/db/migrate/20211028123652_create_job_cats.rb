class CreateJobCats < ActiveRecord::Migration[6.1]
  def change
    create_table :job_cats do |t|
      t.string :assigned_code
      t.string :job_cat_desc
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps

      t.index ["assigned_code"], name: "job_cats_assigned_code_idx"
      t.index ["job_cat_desc"], name: "job_cats_job_cat_desc_idx"
      t.index ["comment"], name: "job_cats_comment_idx"
      t.index ["active_status"], name: "job_cats_active_status_idx"
      t.index ["del_status"], name: "job_cats_del_status_idx"
      t.index ["user_id"], name: "job_cats_user_id_idx"
      t.index ["created_at"], name: "job_cats_created_at_idx"
      t.index ["updated_at"], name: "job_cats_updated_at_idx"

    end
  end
end
