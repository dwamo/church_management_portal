class CreateJobTypes < ActiveRecord::Migration[6.1]
  def change
    create_table :job_types do |t|
      t.string :assigned_code
      t.string :job_cat_code
      t.string :job_type_desc
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      # t.string :comment
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps

      t.index ["assigned_code"], name: "job_types_assigned_code_idx"
      t.index ["job_cat_code"], name: "job_types_job_cat_code_idx"
      t.index ["job_type_desc"], name: "job_types_job_type_desc_idx"
      t.index ["comment"], name: "job_types_comment_idx"
      t.index ["active_status"], name: "job_types_active_status_idx"
      t.index ["del_status"], name: "job_types_del_status_idx"
      t.index ["created_at"], name: "job_types_created_at_idx"
      t.index ["updated_at"], name: "job_types_updated_at_idx"
    end
  end
end
