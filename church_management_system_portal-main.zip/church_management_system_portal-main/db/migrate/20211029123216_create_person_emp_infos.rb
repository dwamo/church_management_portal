class CreatePersonEmpInfos < ActiveRecord::Migration[6.1]
  def change
    create_table :person_emp_infos do |t|
      t.string :person_assigned_code
      t.string :job_type_code
      t.string :job_title
      t.string :location_addr
      t.string :postal_addr
      t.string :emp_loc_addr
      t.string :emp_postal_addr
      t.string :emp_loc_region_code
      t.string :emp_loc_city_town_id
      t.string :contact_number
      t.string :contact_email
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps

      t.index ["person_assigned_code"], name: "person_emp_infos_person_assigned_code_idx"
      t.index ["job_type_code"], name: "person_emp_infos_job_type_code_idx"
      t.index ["job_title"], name: "person_emp_infos_job_title_idx"
      t.index ["location_addr"], name: "person_emp_infos_location_addr_idx"
      t.index ["postal_addr"], name: "person_emp_infos_postal_addr_idx"
      t.index ["emp_loc_addr"], name: "person_emp_infos_emp_loc_addr_idx"
      t.index ["emp_postal_addr"], name: "person_emp_infos_emp_postal_addr_idx"
      t.index ["emp_loc_region_code"], name: "person_emp_infos_emp_loc_region_code_idx"
      t.index ["emp_loc_city_town_id"], name: "person_emp_infos_emp_loc_city_town_id_idx"
      t.index ["contact_number"], name: "person_emp_infos_contact_number_idx"
      t.index ["contact_email"], name: "person_emp_infos_contact_email_idx"
      t.index ["comment"], name: "person_emp_infos_comment_idx"
      t.index ["active_status"], name: "person_emp_infos_active_status_idx"
      t.index ["del_status"], name: "person_emp_infos_del_status_idx"
      t.index ["user_id"], name: "person_emp_infos_user_id_idx"
      t.index ["created_at"], name: "person_emp_infos_created_at_idx"
      t.index ["updated_at"], name: "person_emp_infos_updated_at_idx"

    end
  end
end
