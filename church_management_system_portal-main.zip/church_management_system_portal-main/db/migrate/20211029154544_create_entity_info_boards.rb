class CreateEntityInfoBoards < ActiveRecord::Migration[6.1]
  def change
    create_table :entity_info_boards do |t|
      t.string :entity_code
      t.string :motto
      t.string :logo_path
      t.string :logo_data

      # t.timestamps

      t.index ["entity_code"], name: "entity_info_boards_entity_code_idx"
      t.index ["motto"], name: "entity_info_boards_motto_idx"
      t.index ["logo_path"], name: "entity_info_boards_logo_path_idx"
      t.index ["logo_data"], name: "entity_info_boards_logo_data_idx"

    end
  end
end
