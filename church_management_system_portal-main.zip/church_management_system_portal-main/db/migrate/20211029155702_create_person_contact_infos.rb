class CreatePersonContactInfos < ActiveRecord::Migration[6.1]
  def change
    create_table :person_contact_infos do |t|
      t.string :person_assigned_code
      t.string :contact_number
      t.string :contact_email
      t.string :res_addr
      t.string :postal_addr
      t.string :res_region_code
      t.string :res_city_town_id
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      t.index ["person_assigned_code"], name: "person_contact_infos_person_assigned_code_idx"
      t.index ["contact_number"], name: "person_contact_infos_contact_number_idx"
      t.index ["contact_email"], name: "person_contact_infos_contact_email_idx"
      t.index ["res_addr"], name: "person_contact_infos_res_addr_idx"
      t.index ["postal_addr"], name: "person_contact_infos_postal_addr_idx"
      t.index ["res_region_code"], name: "person_contact_infos_res_region_code_idx"
      t.index ["res_city_town_id"], name: "person_contact_infos_res_city_town_id_idx"
      t.index ["comment"], name: "person_contact_infos_comment_idx"
      t.index ["active_status"], name: "person_contact_infos_active_status_idx"
      t.index ["del_status"], name: "person_contact_infos_del_status_idx"
      t.index ["user_id"], name: "person_contact_infos_user_id_idx"
      t.index ["created_at"], name: "person_contact_infos_created_at_idx"
      t.index ["updated_at"], name: "person_contact_infos_updated_at_idx"

    end
  end
end
