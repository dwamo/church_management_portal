class CreateRegionMasters < ActiveRecord::Migration[6.1]
  def change
    create_table :region_masters do |t|
      t.string :region_code
      t.string :region_desc
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      t.index ["region_code"], name: "region_masters_region_code_idx"
      t.index ["region_desc"], name: "region_masters_region_desc_idx"
      t.index ["comment"], name: "region_masters_comment_idx"
      t.index ["active_status"], name: "region_masters_active_status_idx"
      t.index ["del_status"], name: "region_masters_del_status_idx"
      t.index ["user_id"], name: "region_masters_user_id_idx"
      t.index ["created_at"], name: "region_masters_created_at_idx"
      t.index ["updated_at"], name: "region_masters_updated_at_idx"

    end
  end
end
