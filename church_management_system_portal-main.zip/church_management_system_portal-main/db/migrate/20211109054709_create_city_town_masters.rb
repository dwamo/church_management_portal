class CreateCityTownMasters < ActiveRecord::Migration[6.1]
  def change
    create_table :city_town_masters do |t|
      t.string :region_code
      t.string :city_town_name
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps

      t.index ["city_town_name"], name: "city_town_masters_city_town_name_idx"
      t.index ["comment"], name: "city_town_masters_comment_idx"
      t.index ["active_status"], name: "city_town_masters_active_status_idx"
      t.index ["region_code"], name: "city_town_masters_region_code_idx"
      t.index ["del_status"], name: "city_town_masters_del_status_idx"
      t.index ["user_id"], name: "city_town_masters_user_id_idx"
      t.index ["created_at"], name: "city_town_masters_created_at_idx"
      t.index ["updated_at"], name: "city_town_masters_updated_at_idx"

    end
  end
end
