class CreatePersonExtraInfos < ActiveRecord::Migration[6.1]
  def change
    create_table :person_extra_infos do |t|
      t.string :person_assigned_code
      t.string :marital_status_code
      t.string :emp_status_code
      t.string :physical_disability
      t.string :day_born
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      t.index ["person_assigned_code"], name: "person_extra_infos_person_assigned_code_idx"
      t.index ["marital_status_code"], name: "person_extra_infos_marital_status_code_idx"
      t.index ["emp_status_code"], name: "person_extra_infos_emp_status_code_idx"
      t.index ["physical_disability"], name: "person_extra_infos_physical_disability_idx"
      t.index ["day_born"], name: "person_extra_infos_day_born_idx"
      t.index ["comment"], name: "person_extra_infos_comment_idx"
      t.index ["active_status"], name: "person_extra_infos_active_status_idx"
      t.index ["del_status"], name: "person_extra_infos_del_status_idx"
      t.index ["user_id"], name: "person_extra_infos_user_id_idx"
      t.index ["created_at"], name: "person_extra_infos_created_at_idx"
      t.index ["updated_at"], name: "person_extra_infos_updated_at_idx"

    end
  end
end
