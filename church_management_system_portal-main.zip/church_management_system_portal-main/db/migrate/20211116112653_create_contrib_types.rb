class CreateContribTypes < ActiveRecord::Migration[6.1]
  def change
    create_table :contrib_types do |t|
      t.string :assigned_code
      t.string :contribution_desc
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      t.index ["assigned_code"], name: "contrib_types_assigned_code_idx"
      t.index ["contribution_desc"], name: "contrib_types_contribution_desc_idx"
      t.index ["comment"], name: "contrib_types_comment_idx"
      t.index ["active_status"], name: "contrib_types_active_status_idx"
      t.index ["del_status"], name: "contrib_types_del_status_idx"
      t.index ["user_id"], name: "contrib_types_user_id_idx"
      t.index ["created_at"], name: "contrib_types_created_at_idx"
      t.index ["updated_at"], name: "contrib_types_updated_at_idx"

    end
  end
end
