class CreateMaritalStatusMasters < ActiveRecord::Migration[6.1]
  def change
    create_table :marital_status_masters do |t|
      t.string :assigned_code
      t.boolean :status_desc
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      t.index ["assigned_code"], name: "assigned_code_assigned_code_idx"
      t.index ["status_desc"], name: "assigned_code_status_desc_idx"
      t.index ["comment"], name: "assigned_code_comment_idx"
      t.index ["active_status"], name: "assigned_code_active_status_idx"
      t.index ["del_status"], name: "assigned_code_del_status_idx"
      t.index ["user_id"], name: "assigned_code_user_id_idx"
      t.index ["created_at"], name: "assigned_code_created_at_idx"
      t.index ["updated_at"], name: "assigned_code_updated_at_idx"

    end
  end
end
