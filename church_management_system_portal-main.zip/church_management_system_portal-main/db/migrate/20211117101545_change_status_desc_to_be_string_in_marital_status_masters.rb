class ChangeStatusDescToBeStringInMaritalStatusMasters < ActiveRecord::Migration[6.1]
  def change
  end
end
