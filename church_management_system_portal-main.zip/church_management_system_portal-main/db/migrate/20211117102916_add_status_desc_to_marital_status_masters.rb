class AddStatusDescToMaritalStatusMasters < ActiveRecord::Migration[6.1]
  def change
    add_column :marital_status_masters, :status_desc, :string
  end
end
