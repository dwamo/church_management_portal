class CreatePersonConditionTypes < ActiveRecord::Migration[6.1]
  def change
    create_table :person_condition_types do |t|
      t.string :assigned_code
      t.string :condition_desc
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps

      t.index ["assigned_code"], name: "person_condition_types_assigned_code_idx"
      t.index ["condition_desc"], name: "person_condition_types_condition_desc_idx"
      t.index ["active_status"], name: "person_condition_types_active_status_idx"
      t.index ["del_status"], name: "person_condition_types_del_status_idx"
      t.index ["user_id"], name: "person_condition_types_user_id_idx"
      t.index ["created_at"], name: "person_condition_types_created_at_idx"
      t.index ["updated_at"], name: "person_condition_types_updated_at_idx"

    end
  end
end
