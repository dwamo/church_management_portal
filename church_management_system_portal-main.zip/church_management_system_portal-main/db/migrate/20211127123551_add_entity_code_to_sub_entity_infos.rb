class AddEntityCodeToSubEntityInfos < ActiveRecord::Migration[6.1]
  def change
    add_column :sub_entity_infos, :entity_code, :string
  end
end
