class CreatePersonRelationInfos < ActiveRecord::Migration[6.1]
  def change
    create_table :person_relation_infos do |t|
      t.string :person_assigned_code
      t.string :relation_person_code
      t.string :relation_last_name
      t.string :relation_first_name
      t.string :relation_other_names
      t.string :relationship_code
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      t.index ["person_assigned_code"], name: "person_relation_infos_person_assigned_code_idx"
      t.index ["relation_person_code"], name: "person_relation_infos_relation_person_code_idx"
      t.index ["relation_last_name"], name: "person_relation_infos_relation_last_name_idx"
      t.index ["relation_first_name"], name: "person_relation_infos_relation_first_name_idx"
      t.index ["relation_other_names"], name: "person_relation_infos_relation_other_names_idx"
      t.index ["relationship_code"], name: "person_relation_infos_relationship_code_idx"
      t.index ["comment"], name: "person_relation_infos_comment_idx"
      t.index ["active_status"], name: "person_relation_infos_active_status_idx"
      t.index ["del_status"], name: "person_relation_infos_del_status_idx"
      t.index ["user_id"], name: "person_relation_infos_user_id_idx"
      t.index ["created_at"], name: "person_relation_infos_created_at_idx"
      t.index ["updated_at"], name: "person_relation_infos_updated_at_idx"

    end
  end
end
