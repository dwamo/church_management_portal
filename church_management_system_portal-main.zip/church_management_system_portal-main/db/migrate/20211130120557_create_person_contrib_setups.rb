class CreatePersonContribSetups < ActiveRecord::Migration[6.1]
  def change
    create_table :person_contrib_setups do |t|
      t.string :sub_entity_code
      t.string :person_assigned_code
      t.string :entity_contribution_id
      t.string :freq
      t.timestamp :start_date
      t.boolean :complete_status
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      t.index ["sub_entity_code"], name: "person_contrib_setups_sub_entity_code_idx"
      t.index ["person_assigned_code"], name: "person_contrib_setups_person_assigned_code_idx"
      t.index ["entity_contribution_id"], name: "person_contrib_setups_entity_contribution_id_idx"
      t.index ["freq"], name: "person_contrib_setups_freq_idx"
      t.index ["start_date"], name: "person_contrib_setups_start_date_idx"
      t.index ["complete_status"], name: "person_contrib_setups_complete_status_idx"
      t.index ["comment"], name: "person_contrib_setups_comment_idx"
      t.index ["active_status"], name: "person_contrib_setups_active_status_idx"
      t.index ["del_status"], name: "person_contrib_setups_del_status_idx"
      t.index ["user_id"], name: "person_contrib_setups_user_id_idx"
      t.index ["created_at"], name: "person_contrib_setups_created_at_idx"
      t.index ["updated_at"], name: "person_contrib_setups_updated_at_idx"

    end
  end
end
