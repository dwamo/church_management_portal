class CreateGroupCats < ActiveRecord::Migration[6.1]
  def change
    create_table :group_cats do |t|
      t.string :assigned_code
      t.string :entity_info_code
      t.string :group_cat_desc
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      t.index ["assigned_code"], name: "group_cats_assigned_code_idx"
      t.index ["entity_info_code"], name: "group_cats_entity_info_code_idx"
      t.index ["group_cat_desc"], name: "group_cats_group_cat_desc_idx"
      t.index ["comment"], name: "group_cats_comment_idx"
      t.index ["active_status"], name: "group_cats_active_status_idx"
      t.index ["del_status"], name: "group_cats_del_status_idx"
      t.index ["user_id"], name: "group_cats_user_id_idx"
      t.index ["created_at"], name: "group_cats_created_at_idx"
      t.index ["updated_at"], name: "group_cats_updated_at_idx"

    end
  end
end
