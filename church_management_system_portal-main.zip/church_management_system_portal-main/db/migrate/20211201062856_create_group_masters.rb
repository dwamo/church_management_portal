class CreateGroupMasters < ActiveRecord::Migration[6.1]
  def change
    create_table :group_masters do |t|
      t.string :assigned_code
      t.string :group_cat_code
      t.string :entity_info_code
      t.string :group_name
      t.string :group_alias
      t.string :comment
      t.boolean :active_status
      t.string :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      t.index ["assigned_code"], name: "group_masters_assigned_code_idx"
      t.index ["group_cat_code"], name: "group_masters_group_cat_code_idx"
      t.index ["entity_info_code"], name: "group_masters_entity_info_code_idx"
      t.index ["group_name"], name: "group_masters_group_name_idx"
      t.index ["group_alias"], name: "group_masters_group_alias_idx"
      t.index ["comment"], name: "group_masters_comment_idx"
      t.index ["active_status"], name: "group_masters_active_status_idx"
      t.index ["del_status"], name: "group_masters_del_status_idx"
      t.index ["user_id"], name: "group_masters_user_id_idx"
      t.index ["created_at"], name: "group_masters_created_at_idx"
      t.index ["updated_at"], name: "group_masters_updated_at_idx"

    end
  end
end
