class AddDelStatusToEntityInfoBoards < ActiveRecord::Migration[6.1]
  def change
    add_column :entity_info_boards, :del_status, :boolean

    t.index ["del_status"], name: "entity_info_boards_del_status_idx"
    
  end
end
