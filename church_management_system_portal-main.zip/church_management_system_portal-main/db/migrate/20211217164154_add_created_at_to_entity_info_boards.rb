class AddCreatedAtToEntityInfoBoards < ActiveRecord::Migration[6.1]
  def change
    add_column :entity_info_boards, :created_at, :timestamp


    t.index ["created_at"], name: "entity_info_boards_created_at_idx"
  end
end
