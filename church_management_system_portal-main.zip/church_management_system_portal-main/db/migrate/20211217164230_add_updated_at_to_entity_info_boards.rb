class AddUpdatedAtToEntityInfoBoards < ActiveRecord::Migration[6.1]
  def change
    add_column :entity_info_boards, :updated_at, :timestamp

    
    t.index ["updated_at"], name: "entity_info_boards_updated_at_idx"
  end
end
