class CreatePersonImages < ActiveRecord::Migration[6.1]
  def change
    create_table :person_images do |t|
      t.string :person_assigned_code
      t.string :image_path
      t.string :image_data
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      t.index ["person_assigned_code"], name: "person_images_person_assigned_code_idx"
      t.index ["image_path"], name: "person_images_image_path_idx"
      t.index ["image_data"], name: "person_images_image_data_idx"
      t.index ["comment"], name: "person_images_comment_idx"
      t.index ["active_status"], name: "person_images_active_status_idx"
      t.index ["del_status"], name: "person_images_del_status_idx"
      t.index ["user_id"], name: "person_images_user_id_idx"
      t.index ["created_at"], name: "person_images_created_at_idx"
      t.index ["updated_at"], name: "person_images_updated_at_idx"

    end
  end
end
