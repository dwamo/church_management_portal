class ChangePhysicalDisabilityToBeIntegerInPersonExtraInfos < ActiveRecord::Migration[6.1]
  def change
  end
end
