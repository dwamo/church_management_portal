class CreateCareGivingInfos < ActiveRecord::Migration[6.1]
  def change
    create_table :care_giving_infos do |t|
      t.string :person_assigned_code
      t.string :condition_type_code
      t.timestamp :start_date
      t.timestamp :end_date
      t.string :facility_type
      t.string :facility_name
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps

      t.index ["person_assigned_code"], name: "care_giving_infos_person_assigned_code_idx"
      t.index ["condition_type_code"], name: "care_giving_infos_condition_type_code_idx"
      t.index ["start_date"], name: "care_giving_infos_start_date_idx"
      t.index ["end_date"], name: "care_giving_infos_end_date_idx"
      t.index ["facility_type"], name: "care_giving_infos_facility_type_idx"
      t.index ["facility_name"], name: "care_giving_infos_facility_name_idx"
      t.index ["comment"], name: "care_giving_infos_comment_idx"
      t.index ["active_status"], name: "care_giving_infos_active_status_idx"
      t.index ["del_status"], name: "care_giving_infos_del_status_idx"
      t.index ["user_id"], name: "care_giving_infos_user_id_idx"
      t.index ["created_at"], name: "care_giving_infos_created_at_idx"
      t.index ["updated_at"], name: "care_giving_infos_updated_at_idx"
    end
  end
end
