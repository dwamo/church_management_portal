class CreateSubEntityContribs < ActiveRecord::Migration[6.1]
  def change
    create_table :sub_entity_contribs do |t|
      t.string :sub_entity_code
      t.string :contribution_type_code
      t.string :contribution_name
      t.string :contribution_alias
      t.integer :amount
      t.timestamp :start_date
      t.timestamp :end_date
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      t.index ["sub_entity_code"], name: "sub_entity_contribs_sub_entity_code_idx"
      t.index ["contribution_type_code"], name: "sub_entity_contribs_contribution_type_code_idx"
      t.index ["contribution_name"], name: "sub_entity_contribs_contribution_name_idx"
      t.index ["contribution_alias"], name: "sub_entity_contribs_contribution_alias_idx"
      t.index ["amount"], name: "sub_entity_contribs_amount_idx"
      t.index ["start_date"], name: "sub_entity_contribs_start_date_idx"
      t.index ["end_date"], name: "sub_entity_contribs_end_date_idx"
      t.index ["comment"], name: "sub_entity_contribs_comment_idx"
      t.index ["active_status"], name: "sub_entity_contribs_active_status_idx"
      t.index ["del_status"], name: "sub_entity_contribs_del_status_idx"
      t.index ["user_id"], name: "sub_entity_contribs_user_id_idx"
      t.index ["created_at"], name: "sub_entity_contribs_created_at_idx"
      t.index ["updated_at"], name: "sub_entity_contribs_updated_at_idx"

    end
  end
end
