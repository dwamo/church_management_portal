class CreateUserBoards < ActiveRecord::Migration[6.1]
  def change
    create_table :user_boards do |t|
      t.integer :user_id
      t.string :logo_path
      t.string :logo_data
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      t.index ["user_id"], name: "user_boards_user_id_idx"
      t.index ["logo_path"], name: "user_boards_logo_path_idx"
      t.index ["logo_data"], name: "user_boards_logo_data_idx"
      t.index ["comment"], name: "user_boards_comment_idx"
      t.index ["active_status"], name: "user_boards_active_status_idx"
      t.index ["del_status"], name: "user_boards_del_status_idx"
      t.index ["created_at"], name: "user_boards_created_at_idx"
      t.index ["updated_at"], name: "user_boards_updated_at_idx"

    end
  end
end
