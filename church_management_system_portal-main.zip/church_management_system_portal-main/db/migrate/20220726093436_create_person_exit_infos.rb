class CreatePersonExitInfos < ActiveRecord::Migration[6.1]
  def change
    create_table :person_exit_infos do |t|
      t.string :entity_code
      t.string :sub_entity_code
      t.string :person_assigned_code
      t.string :exit_lov_id
      t.string :integer
      t.string :cause
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status

      t.timestamps
    end
  end
end
