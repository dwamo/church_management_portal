class CreatePersonExitLovs < ActiveRecord::Migration[6.1]
  def change
    create_table :person_exit_lovs do |t|
      t.string :entity_code
      t.string :exit_desc
      t.string :comment
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at
      # t.timestamps
    end
  end
end
