class AddDisabilityBoolToPersonExtraInfos < ActiveRecord::Migration[6.1]
  def change
    add_column :person_extra_infos, :disability_bool, :boolean
  end
end
