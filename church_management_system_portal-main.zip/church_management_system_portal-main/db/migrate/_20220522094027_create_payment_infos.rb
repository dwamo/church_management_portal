class CreatePaymentInfos < ActiveRecord::Migration[6.1]
  def change
    create_table :payment_infos do |t|
      t.string :person_assigned_code
      t.string :product_id
      t.string :mobile_number
      t.string :amount
      t.boolean :status
      t.string :trans_type
      t.string :payment_mode
      t.string :reference
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      # t.index ["person_assigned_code"], name: "payment_infos_person_assigned_code_idx"
      # t.index ["product_id"], name: "payment_infos_product_id_idx"
      # t.index ["mobile_number"], name: "payment_infos_mobile_number_idx"
      # t.index ["amount"], name: "payment_infos_amount_idx"

    end
  end
end
