class CreatePersonContribs < ActiveRecord::Migration[6.1]
  def change
    create_table :person_contribs do |t|
      t.string :person_assigned_code
      t.string :amount
      t.string :src
      t.string :person_contrib_setup_id
      t.string :sub_entity_contrib_id
      t.timestamp :created_at
      t.timestamp :updated_at

      # t.timestamps
      # t.index ["person_assigned_code"], name: "person_contribs_person_assigned_code_idx"
      # t.index ["amount"], name: "person_contribs_amount_idx"
      # t.index ["src"], name: "person_contribs_src_idx"
      # t.index ["person_contrib_setup_id"], name: "person_contribs_person_contrib_setup_id_idx"
      # t.index ["sub_entity_contrib_id"], name: "person_contribs_sub_entity_contrib_id_idx"

    end
  end
end
