class CreatePaymentRequests < ActiveRecord::Migration[6.1]
  def change
    create_table :payment_requests do |t|
      t.string :pan
      t.integer :amount
      t.spring :trans_type
      t.string :nw
      t.integer :payment_info_id
      t.string :processing_id
      t.string :reference
      t.string :payment_mode
      t.boolean :processed
      t.timestamp :created_at
      t.timestamp :updated_at

      t.timestamps
    end
  end
end
