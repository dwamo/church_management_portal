class CreateIssueLogTypes < ActiveRecord::Migration[6.1]
  def change
    create_table :issue_log_types do |t|
      t.string :log_type_desc
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      t.timestamps
    end
  end
end
