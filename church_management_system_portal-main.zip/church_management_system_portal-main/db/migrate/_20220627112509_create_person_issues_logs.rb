class CreatePersonIssuesLogs < ActiveRecord::Migration[6.1]
  def change
    create_table :person_issues_logs do |t|
      t.string :person_assigned_code
      t.string :sub_entity_code
      t.string :issues_log_title
      t.string :issues_log_desc
      t.integer :issues_log_type_id
      t.timestamp :created_at
      t.timestamp :updated_at

      t.timestamps
    end
  end
end
