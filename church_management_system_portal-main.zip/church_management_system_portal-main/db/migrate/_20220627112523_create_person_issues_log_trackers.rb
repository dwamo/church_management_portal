class CreatePersonIssuesLogTrackers < ActiveRecord::Migration[6.1]
  def change
    create_table :person_issues_log_trackers do |t|
      t.integer :person_issues_log_id
      t.string :comment
      t.string :person_assigned_code
      t.boolean :active_status
      t.boolean :del_status
      t.integer :user_id
      t.timestamp :created_at
      t.timestamp :updated_at

      t.timestamps
    end
  end
end
