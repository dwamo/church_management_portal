# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 2022_07_26_093536) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "auth_req", id: :serial, force: :cascade do |t|
    t.string "mobile_number", limit: 20
    t.string "imei", limit: 50
    t.text "secret_code"
    t.string "ref_code", limit: 10
    t.string "src", limit: 10
    t.string "email", limit: 50
    t.string "device_type", limit: 10
    t.boolean "expired", default: false
    t.string "status", limit: 5
    t.string "requester"
    t.datetime "created_at", default: -> { "CURRENT_TIMESTAMP" }
    t.datetime "updated_at", default: -> { "CURRENT_TIMESTAMP" }
    t.index ["expired"], name: "auth_req_index_expired"
    t.index ["mobile_number"], name: "auth_req_index_mobile_number"
    t.index ["status"], name: "auth_req_index_status"
  end

  create_table "care_giving_infos", force: :cascade do |t|
    t.string "person_assigned_code"
    t.string "condition_type_code"
    t.datetime "start_date"
    t.datetime "end_date"
    t.string "facility_type"
    t.string "facility_name"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["condition_type_code"], name: "care_giving_infos_condition_type_code_idx"
    t.index ["created_at"], name: "care_giving_infos_created_at_idx"
    t.index ["end_date"], name: "care_giving_infos_end_date_idx"
    t.index ["facility_name"], name: "care_giving_infos_facility_name_idx"
    t.index ["facility_type"], name: "care_giving_infos_facility_type_idx"
    t.index ["person_assigned_code"], name: "care_giving_infos_person_assigned_code_idx"
    t.index ["start_date"], name: "care_giving_infos_start_date_idx"
    t.index ["updated_at"], name: "care_giving_infos_updated_at_idx"
    t.index ["user_id"], name: "care_giving_infos_user_id_idx"
  end

  create_table "city_town_masters", force: :cascade do |t|
    t.string "region_code"
    t.string "city_town_name"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["city_town_name"], name: "city_town_masters_city_town_name_idx"
    t.index ["created_at"], name: "city_town_masters_created_at_idx"
    t.index ["region_code"], name: "city_town_masters_region_code_idx"
    t.index ["updated_at"], name: "city_town_masters_updated_at_idx"
    t.index ["user_id"], name: "city_town_masters_user_id_idx"
  end

  create_table "contrib_types", force: :cascade do |t|
    t.string "assigned_code"
    t.string "contribution_desc"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string "entity_code"
    t.index ["assigned_code"], name: "contrib_types_assigned_code_idx"
    t.index ["contribution_desc"], name: "contrib_types_contribution_desc_idx"
    t.index ["created_at"], name: "contrib_types_created_at_idx"
    t.index ["updated_at"], name: "contrib_types_updated_at_idx"
    t.index ["user_id"], name: "contrib_types_user_id_idx"
  end

  create_table "disability_masters", force: :cascade do |t|
    t.string "disability_desc"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["created_at"], name: "disability_masters_created_at_idx"
    t.index ["disability_desc"], name: "disability_masters_disability_desc_idx"
    t.index ["updated_at"], name: "disability_masters_updated_at_idx"
    t.index ["user_id"], name: "disability_masters_user_id_idx"
  end

  create_table "emp_status_masters", force: :cascade do |t|
    t.string "assigned_code"
    t.string "emp_status_desc"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["assigned_code"], name: "emp_status_masters_assigned_code_idx"
    t.index ["created_at"], name: "emp_status_masters_created_at_idx"
    t.index ["emp_status_desc"], name: "emp_status_masters_emp_status_desc_idx"
    t.index ["updated_at"], name: "emp_status_masters_updated_at_idx"
    t.index ["user_id"], name: "emp_status_masters_user_id_idx"
  end

  create_table "entity_divisions", force: :cascade do |t|
    t.string "assigned_code"
    t.string "entity_code"
    t.string "division_name", limit: 255
    t.string "division_alias"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["assigned_code"], name: "entity_divisions_assigned_code_idx"
    t.index ["created_at"], name: "entity_divisions_created_at_idx"
    t.index ["division_alias"], name: "entity_divisions_division_alias_idx"
    t.index ["division_name"], name: "entity_divisions_division_name_idx"
    t.index ["entity_code"], name: "entity_divisions_entity_code_idx"
    t.index ["updated_at"], name: "entity_divisions_updated_at_idx"
    t.index ["user_id"], name: "entity_divisions_user_id_idx"
  end

  create_table "entity_extra_infos", force: :cascade do |t|
    t.string "entity_code"
    t.string "entity_division_code"
    t.string "sub_entity_code"
    t.string "person_assigned_code"
    t.string "person_role_code"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["created_at"], name: "entity_extra_infos_created_at_idx"
    t.index ["entity_code"], name: "entity_extra_infos_entity_code_idx"
    t.index ["entity_division_code"], name: "entity_extra_infos_entity_division_code_idx"
    t.index ["person_assigned_code"], name: "entity_extra_infos_person_assigned_code_idx"
    t.index ["person_role_code"], name: "entity_extra_infos_person_role_code_idx"
    t.index ["sub_entity_code"], name: "entity_extra_infos_sub_entity_code_idx"
    t.index ["updated_at"], name: "entity_extra_infos_updated_at_idx"
    t.index ["user_id"], name: "entity_extra_infos_user_id_idx"
  end

  create_table "entity_info_boards", force: :cascade do |t|
    t.string "entity_code"
    t.string "motto"
    t.string "logo_path"
    t.string "logo_data"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["entity_code"], name: "entity_info_boards_entity_code_idx"
    t.index ["logo_data"], name: "entity_info_boards_logo_data_idx"
    t.index ["logo_path"], name: "entity_info_boards_logo_path_idx"
    t.index ["motto"], name: "entity_info_boards_motto_idx"
  end

  create_table "entity_infos", force: :cascade do |t|
    t.string "assigned_code"
    t.string "entity_name"
    t.string "entity_alias"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["assigned_code"], name: "entity_infos_assigned_code_idx"
    t.index ["created_at"], name: "entity_infos_created_at_idx"
    t.index ["entity_alias"], name: "entity_infos_entity_alias_idx"
    t.index ["entity_name"], name: "entity_infos_entity_name_idx"
    t.index ["updated_at"], name: "entity_infos_updated_at_idx"
    t.index ["user_id"], name: "entity_infos_user_id_idx"
  end

  create_table "entity_sub_divisions", force: :cascade do |t|
    t.string "entity_division_code"
    t.string "sub_division_desc"
    t.string "sub_division_alias"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string "assigned_code"
    t.index ["created_at"], name: "entity_sub_divisions_created_at_idx"
    t.index ["entity_division_code"], name: "entity_sub_divisions_entity_division_code_idx"
    t.index ["sub_division_alias"], name: "entity_sub_divisions_sub_division_alias_idx"
    t.index ["sub_division_desc"], name: "entity_sub_divisions_sub_division_desc_idx"
    t.index ["updated_at"], name: "entity_sub_divisions_updated_at_idx"
    t.index ["user_id"], name: "entity_sub_divisions_user_id_idx"
  end

  create_table "group_cats", force: :cascade do |t|
    t.string "assigned_code"
    t.string "entity_info_code"
    t.string "group_cat_desc"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["assigned_code"], name: "group_cats_assigned_code_idx"
    t.index ["created_at"], name: "group_cats_created_at_idx"
    t.index ["entity_info_code"], name: "group_cats_entity_info_code_idx"
    t.index ["group_cat_desc"], name: "group_cats_group_cat_desc_idx"
    t.index ["updated_at"], name: "group_cats_updated_at_idx"
    t.index ["user_id"], name: "group_cats_user_id_idx"
  end

  create_table "group_masters", force: :cascade do |t|
    t.string "assigned_code"
    t.string "group_cat_code"
    t.string "entity_info_code"
    t.string "group_name"
    t.string "group_alias"
    t.string "comment"
    t.boolean "active_status", default: true
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean "del_status", default: false
    t.index ["assigned_code"], name: "group_masters_assigned_code_idx"
    t.index ["created_at"], name: "group_masters_created_at_idx"
    t.index ["entity_info_code"], name: "group_masters_entity_info_code_idx"
    t.index ["group_alias"], name: "group_masters_group_alias_idx"
    t.index ["group_cat_code"], name: "group_masters_group_cat_code_idx"
    t.index ["group_name"], name: "group_masters_group_name_idx"
    t.index ["user_id"], name: "group_masters_user_id_idx"
  end

  create_table "issues_log_type", id: :serial, force: :cascade do |t|
    t.string "log_type_desc", limit: 255
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.string "user_id"
    t.datetime "created_at", default: -> { "now()" }
    t.datetime "updated_at"
  end

  create_table "job_cats", force: :cascade do |t|
    t.string "assigned_code"
    t.string "job_cat_desc"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["assigned_code"], name: "job_cats_assigned_code_idx"
    t.index ["created_at"], name: "job_cats_created_at_idx"
    t.index ["job_cat_desc"], name: "job_cats_job_cat_desc_idx"
    t.index ["updated_at"], name: "job_cats_updated_at_idx"
    t.index ["user_id"], name: "job_cats_user_id_idx"
  end

  create_table "job_types", force: :cascade do |t|
    t.string "assigned_code"
    t.string "job_cat_code"
    t.string "job_type_desc"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["assigned_code"], name: "job_types_assigned_code_idx"
    t.index ["created_at"], name: "job_types_created_at_idx"
    t.index ["job_cat_code"], name: "job_types_job_cat_code_idx"
    t.index ["job_type_desc"], name: "job_types_job_type_desc_idx"
    t.index ["updated_at"], name: "job_types_updated_at_idx"
  end

  create_table "marital_status_masters", force: :cascade do |t|
    t.string "assigned_code"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string "status_desc"
  end

  create_table "payment_callbacks", id: false, force: :cascade do |t|
    t.string "trans_status"
    t.string "nw_trans_id"
    t.string "trans_ref"
    t.string "trans_msg"
    t.datetime "created_at", default: -> { "CURRENT_TIMESTAMP" }
  end

  create_table "payment_infos", id: :serial, force: :cascade do |t|
    t.string "mobile_number"
    t.decimal "amount", precision: 12, scale: 2
    t.boolean "status"
    t.string "trans_type"
    t.string "payment_mode"
    t.string "person_assigned_code"
    t.datetime "created_at", default: -> { "CURRENT_TIMESTAMP" }
    t.string "reference"
    t.integer "product_id"
  end

  create_table "payment_requests", id: :serial, force: :cascade do |t|
    t.string "pan", limit: 50, null: false
    t.decimal "amount", precision: 12, scale: 2, null: false
    t.string "trans_type", null: false
    t.string "nw", null: false
    t.serial "payment_info_id", null: false
    t.string "processing_id", null: false
    t.string "reference"
    t.string "payment_mode", null: false
    t.datetime "created_at", default: -> { "CURRENT_TIMESTAMP" }
    t.datetime "updated_at"
    t.boolean "processed"
  end

  create_table "permissions", force: :cascade do |t|
    t.string "subject_class"
    t.string "action"
    t.string "name"
    t.string "description"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["action"], name: "permissions_action_idx"
    t.index ["description"], name: "permissions_description_idx"
    t.index ["name"], name: "permissions_name_idx"
    t.index ["subject_class"], name: "permissions_subject_class_idx"
  end

  create_table "permissions_roles", force: :cascade do |t|
    t.integer "permission_id"
    t.integer "role_id"
    t.string "role_code"
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
    t.index ["created_at"], name: "permissions_roles_created_at"
    t.index ["permission_id"], name: "permissions_roles_permission_id_idx"
    t.index ["role_code"], name: "permissions_roles_role_code_idx"
    t.index ["role_id"], name: "permissions_roles_role_id_idx"
    t.index ["updated_at"], name: "permissions_roles_updated_at_idx"
  end

  create_table "person_condition_types", force: :cascade do |t|
    t.string "assigned_code"
    t.string "condition_desc"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["assigned_code"], name: "person_condition_types_assigned_code_idx"
    t.index ["condition_desc"], name: "person_condition_types_condition_desc_idx"
    t.index ["created_at"], name: "person_condition_types_created_at_idx"
    t.index ["updated_at"], name: "person_condition_types_updated_at_idx"
    t.index ["user_id"], name: "person_condition_types_user_id_idx"
  end

  create_table "person_contact_infos", force: :cascade do |t|
    t.string "person_assigned_code"
    t.string "contact_number"
    t.string "contact_email"
    t.string "res_addr"
    t.string "postal_addr"
    t.string "res_region_code"
    t.string "res_city_town_id"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["contact_email"], name: "person_contact_infos_contact_email_idx"
    t.index ["contact_number"], name: "person_contact_infos_contact_number_idx"
    t.index ["created_at"], name: "person_contact_infos_created_at_idx"
    t.index ["person_assigned_code"], name: "person_contact_infos_person_assigned_code_idx"
    t.index ["postal_addr"], name: "person_contact_infos_postal_addr_idx"
    t.index ["res_addr"], name: "person_contact_infos_res_addr_idx"
    t.index ["res_city_town_id"], name: "person_contact_infos_res_city_town_id_idx"
    t.index ["res_region_code"], name: "person_contact_infos_res_region_code_idx"
    t.index ["updated_at"], name: "person_contact_infos_updated_at_idx"
    t.index ["user_id"], name: "person_contact_infos_user_id_idx"
  end

  create_table "person_contrib_setups", force: :cascade do |t|
    t.string "sub_entity_code"
    t.string "person_assigned_code"
    t.string "sub_entity_contribution_id"
    t.string "freq"
    t.datetime "start_date"
    t.boolean "complete_status"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["complete_status"], name: "person_contrib_setups_complete_status_idx"
    t.index ["created_at"], name: "person_contrib_setups_created_at_idx"
    t.index ["freq"], name: "person_contrib_setups_freq_idx"
    t.index ["person_assigned_code"], name: "person_contrib_setups_person_assigned_code_idx"
    t.index ["start_date"], name: "person_contrib_setups_start_date_idx"
    t.index ["sub_entity_code"], name: "person_contrib_setups_sub_entity_code_idx"
    t.index ["sub_entity_contribution_id"], name: "person_contrib_setups_entity_contribution_id_idx"
    t.index ["updated_at"], name: "person_contrib_setups_updated_at_idx"
    t.index ["user_id"], name: "person_contrib_setups_user_id_idx"
  end

  create_table "person_contribs", id: false, force: :cascade do |t|
    t.string "person_assigned_code", limit: 10
    t.string "amount", limit: 50
    t.string "src"
    t.datetime "created_at", default: -> { "CURRENT_TIMESTAMP" }
    t.bigint "person_contrib_setup_id"
    t.bigint "sub_entity_contrib_id"
  end

  create_table "person_disability_infos", force: :cascade do |t|
    t.string "person_assigned_code"
    t.integer "disability_id"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["created_at"], name: "person_disability_infos_created_at_idx"
    t.index ["disability_id"], name: "person_disability_infos_disability_id_idx"
    t.index ["person_assigned_code"], name: "person_disability_infos_person_assigned_code_idx"
    t.index ["updated_at"], name: "person_disability_infos_updated_at_idx"
    t.index ["user_id"], name: "person_disability_infos_user_id_idx"
  end

  create_table "person_emp_infos", force: :cascade do |t|
    t.string "person_assigned_code"
    t.string "job_type_code"
    t.string "job_title"
    t.string "location_addr"
    t.string "postal_addr"
    t.string "emp_loc_addr"
    t.string "emp_postal_addr"
    t.string "emp_loc_region_code"
    t.string "emp_loc_city_town_id"
    t.string "contact_number"
    t.string "contact_email"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string "emp_name", limit: 255
    t.string "employer", limit: 255, default: "aNm", null: false
    t.index ["contact_email"], name: "person_emp_infos_contact_email_idx"
    t.index ["contact_number"], name: "person_emp_infos_contact_number_idx"
    t.index ["created_at"], name: "person_emp_infos_created_at_idx"
    t.index ["emp_loc_addr"], name: "person_emp_infos_emp_loc_addr_idx"
    t.index ["emp_loc_city_town_id"], name: "person_emp_infos_emp_loc_city_town_id_idx"
    t.index ["emp_loc_region_code"], name: "person_emp_infos_emp_loc_region_code_idx"
    t.index ["emp_postal_addr"], name: "person_emp_infos_emp_postal_addr_idx"
    t.index ["job_title"], name: "person_emp_infos_job_title_idx"
    t.index ["job_type_code"], name: "person_emp_infos_job_type_code_idx"
    t.index ["location_addr"], name: "person_emp_infos_location_addr_idx"
    t.index ["person_assigned_code"], name: "person_emp_infos_person_assigned_code_idx"
    t.index ["postal_addr"], name: "person_emp_infos_postal_addr_idx"
  end

  create_table "person_exit_infos", force: :cascade do |t|
    t.string "entity_code"
    t.string "sub_entity_code"
    t.string "person_assigned_code"
    t.string "exit_lov_id"
    t.string "integer"
    t.string "cause"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.datetime "created_at", precision: 6, null: false
    t.datetime "updated_at", precision: 6, null: false
  end

  create_table "person_exit_lovs", force: :cascade do |t|
    t.string "entity_code"
    t.string "exit_desc"
    t.string "comment"
    t.boolean "active_status"
    t.boolean "del_status"
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "person_extra_infos", force: :cascade do |t|
    t.string "person_assigned_code"
    t.string "marital_status_code"
    t.string "emp_status_code"
    t.string "day_born"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.datetime "baptism_date"
    t.datetime "confirmation_date"
    t.boolean "disability", default: false
    t.index ["created_at"], name: "person_extra_infos_created_at_idx"
    t.index ["day_born"], name: "person_extra_infos_day_born_idx"
    t.index ["emp_status_code"], name: "person_extra_infos_emp_status_code_idx"
    t.index ["marital_status_code"], name: "person_extra_infos_marital_status_code_idx"
    t.index ["person_assigned_code"], name: "person_extra_infos_person_assigned_code_idx"
    t.index ["updated_at"], name: "person_extra_infos_updated_at_idx"
    t.index ["user_id"], name: "person_extra_infos_user_id_idx"
  end

  create_table "person_group_infos", force: :cascade do |t|
    t.string "person_assigned_code"
    t.string "sub_entity_code"
    t.string "group_code"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["created_at"], name: "person_group_infos_created_at_idx"
    t.index ["group_code"], name: "person_group_infos_group_code_idx"
    t.index ["person_assigned_code"], name: "person_group_infos_person_assigned_code_idx"
    t.index ["sub_entity_code"], name: "person_group_infos_sub_entity_code_idx"
    t.index ["updated_at"], name: "person_group_infos_updated_at_idx"
    t.index ["user_id"], name: "person_group_infos_user_id_idx"
  end

  create_table "person_images", force: :cascade do |t|
    t.string "person_assigned_code"
    t.string "image_path"
    t.string "image_data"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["created_at"], name: "person_images_created_at_idx"
    t.index ["image_data"], name: "person_images_image_data_idx"
    t.index ["image_path"], name: "person_images_image_path_idx"
    t.index ["person_assigned_code"], name: "person_images_person_assigned_code_idx"
    t.index ["updated_at"], name: "person_images_updated_at_idx"
    t.index ["user_id"], name: "person_images_user_id_idx"
  end

  create_table "person_infos", force: :cascade do |t|
    t.string "assigned_code"
    t.string "entity_info_code"
    t.string "last_name"
    t.string "first_name"
    t.string "other_names"
    t.datetime "birth_date"
    t.string "gender"
    t.boolean "status", default: true
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["assigned_code"], name: "person_infos_assigned_code_idx"
    t.index ["birth_date"], name: "person_infos_birth_date_idx"
    t.index ["created_at"], name: "person_infos_created_at_idx"
    t.index ["entity_info_code"], name: "person_infos_entity_info_code_idx"
    t.index ["first_name"], name: "person_infos_first_name_idx"
    t.index ["gender"], name: "person_infos_gender_idx"
    t.index ["last_name"], name: "person_infos_last_name_idx"
    t.index ["other_names"], name: "person_infos_other_names_idx"
    t.index ["status"], name: "person_infos_status_idx"
    t.index ["user_id"], name: "person_infos_user_id_idx"
  end

  create_table "person_issues_log", id: :serial, force: :cascade do |t|
    t.string "person_assigned_code", null: false
    t.string "sub_entity_code", null: false
    t.string "issues_log_title", limit: 50, null: false
    t.string "issues_log_desc"
    t.datetime "created_at", default: -> { "now()" }
    t.integer "issues_log_type_id"
    t.datetime "updated_at"
  end

  create_table "person_issues_log_tracker", id: :serial, force: :cascade do |t|
    t.integer "person_issues_log_id", null: false
    t.text "comment"
    t.string "person_assigned_code", null: false
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.string "user_id"
    t.datetime "created_at", default: -> { "now()" }
    t.datetime "updated_at"
  end

  create_table "person_relation_infos", force: :cascade do |t|
    t.string "person_assigned_code"
    t.string "relation_person_code"
    t.string "relation_last_name"
    t.string "relation_first_name"
    t.string "relation_other_names"
    t.string "relationship_code"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["created_at"], name: "person_relation_infos_created_at_idx"
    t.index ["person_assigned_code"], name: "person_relation_infos_person_assigned_code_idx"
    t.index ["relation_first_name"], name: "person_relation_infos_relation_first_name_idx"
    t.index ["relation_last_name"], name: "person_relation_infos_relation_last_name_idx"
    t.index ["relation_other_names"], name: "person_relation_infos_relation_other_names_idx"
    t.index ["relation_person_code"], name: "person_relation_infos_relation_person_code_idx"
    t.index ["relationship_code"], name: "person_relation_infos_relationship_code_idx"
    t.index ["updated_at"], name: "person_relation_infos_updated_at_idx"
    t.index ["user_id"], name: "person_relation_infos_user_id_idx"
  end

  create_table "person_role_masters", force: :cascade do |t|
    t.string "assigned_code"
    t.string "entity_code"
    t.string "role_desc"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["assigned_code"], name: "person_role_masters_assigned_code_idx"
    t.index ["created_at"], name: "person_role_masters_created_at_idx"
    t.index ["entity_code"], name: "person_role_masters_entity_code_idx"
    t.index ["role_desc"], name: "person_role_masters_role_desc_idx"
    t.index ["updated_at"], name: "person_role_masters_updated_at_idx"
    t.index ["user_id"], name: "person_role_masters_user_id_idx"
  end

  create_table "person_ss_profile", id: false, force: :cascade do |t|
    t.serial "id", null: false
    t.string "person_assigned_code", limit: 20
    t.text "password"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.datetime "created_at", default: -> { "CURRENT_TIMESTAMP" }, null: false
    t.datetime "updated_at"
  end

  create_table "person_sub_entity_infos", force: :cascade do |t|
    t.string "person_assigned_code"
    t.string "sub_entity_code"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.boolean "status", default: true
    t.index ["created_at"], name: "person_sub_entity_infos_created_at_idx"
    t.index ["person_assigned_code"], name: "person_sub_entity_infos_person_assigned_code_idx"
    t.index ["sub_entity_code"], name: "person_sub_entity_infos_sub_entity_code_idx"
    t.index ["updated_at"], name: "person_sub_entity_infos_updated_at_idx"
    t.index ["user_id"], name: "person_sub_entity_infos_user_id_idx"
  end

  create_table "pod", id: :serial, force: :cascade do |t|
    t.string "mode"
    t.string "nw", null: false
    t.boolean "is_primary"
    t.boolean "del_status", default: false
    t.boolean "active_status", default: true
    t.string "person_assigned_code"
    t.string "pan"
    t.datetime "created_at", default: -> { "CURRENT_TIMESTAMP" }
    t.datetime "updated_at", default: -> { "CURRENT_TIMESTAMP" }
  end

  create_table "region_masters", force: :cascade do |t|
    t.string "region_code"
    t.string "region_desc"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["created_at"], name: "region_masters_created_at_idx"
    t.index ["region_code"], name: "region_masters_region_code_idx"
    t.index ["region_desc"], name: "region_masters_region_desc_idx"
    t.index ["updated_at"], name: "region_masters_updated_at_idx"
    t.index ["user_id"], name: "region_masters_user_id_idx"
  end

  create_table "relationship_masters", force: :cascade do |t|
    t.string "assigned_code"
    t.string "relationship_desc"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["assigned_code"], name: "relationship_masters_assigned_code_idx"
    t.index ["created_at"], name: "relationship_masters_created_at_idx"
    t.index ["relationship_desc"], name: "relationship_masters_relationship_desc_idx"
    t.index ["updated_at"], name: "relationship_masters_updated_at_idx"
    t.index ["user_id"], name: "relationship_masters_user_id_idx"
  end

  create_table "roles", force: :cascade do |t|
    t.string "name"
    t.string "unique_code"
    t.boolean "active_status"
    t.boolean "del_status"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "sub_entity_contribs", force: :cascade do |t|
    t.string "sub_entity_code"
    t.string "contribution_type_code"
    t.string "contribution_name"
    t.string "contribution_alias"
    t.integer "amount"
    t.datetime "start_date"
    t.datetime "end_date"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["amount"], name: "sub_entity_contribs_amount_idx"
    t.index ["contribution_alias"], name: "sub_entity_contribs_contribution_alias_idx"
    t.index ["contribution_name"], name: "sub_entity_contribs_contribution_name_idx"
    t.index ["contribution_type_code"], name: "sub_entity_contribs_contribution_type_code_idx"
    t.index ["created_at"], name: "sub_entity_contribs_created_at_idx"
    t.index ["end_date"], name: "sub_entity_contribs_end_date_idx"
    t.index ["start_date"], name: "sub_entity_contribs_start_date_idx"
    t.index ["sub_entity_code"], name: "sub_entity_contribs_sub_entity_code_idx"
    t.index ["updated_at"], name: "sub_entity_contribs_updated_at_idx"
    t.index ["user_id"], name: "sub_entity_contribs_user_id_idx"
  end

  create_table "sub_entity_infos", force: :cascade do |t|
    t.string "assigned_code"
    t.string "entity_division_code"
    t.string "sub_entity_name"
    t.string "sub_entity_alias"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.integer "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string "entity_code"
    t.string "entity_sub_div_code"
    t.index ["assigned_code"], name: "sub_entity_infos_assigned_code_idx"
    t.index ["created_at"], name: "sub_entity_infos_created_at_idx"
    t.index ["entity_division_code"], name: "sub_entity_infos_entity_division_code_idx"
    t.index ["sub_entity_alias"], name: "sub_entity_infos_sub_entity_alias_idx"
    t.index ["sub_entity_name"], name: "sub_entity_infos_sub_entity_name_idx"
    t.index ["updated_at"], name: "sub_entity_infos_updated_at_idx"
    t.index ["user_id"], name: "sub_entity_infos_user_id_idx"
  end

  create_table "user_boards", force: :cascade do |t|
    t.integer "user_id"
    t.string "logo_path"
    t.string "logo_data"
    t.string "comment"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.index ["active_status"], name: "user_boards_active_status_idx"
    t.index ["comment"], name: "user_boards_comment_idx"
    t.index ["created_at"], name: "user_boards_created_at_idx"
    t.index ["del_status"], name: "user_boards_del_status_idx"
    t.index ["logo_data"], name: "user_boards_logo_data_idx"
    t.index ["logo_path"], name: "user_boards_logo_path_idx"
    t.index ["updated_at"], name: "user_boards_updated_at_idx"
    t.index ["user_id"], name: "user_boards_user_id_idx"
  end

  create_table "user_roles", force: :cascade do |t|
    t.integer "user_id"
    t.string "role_code"
    t.string "main_code"
    t.string "div_code"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string "sub_entity_code"
    t.index ["created_at"], name: "user_roles_created_at_idx"
    t.index ["div_code"], name: "user_roles_div_code_idx"
    t.index ["main_code"], name: "user_roles_main_code_idx"
    t.index ["role_code"], name: "user_roles_role_code_idx"
    t.index ["updated_at"], name: "user_roles_updated_at_idx"
    t.index ["user_id"], name: "user_roles_user_id_idx"
  end

  create_table "users", force: :cascade do |t|
    t.string "lastname"
    t.string "other_name"
    t.string "username"
    t.string "mobile_number"
    t.string "email"
    t.boolean "active_status", default: true
    t.boolean "del_status", default: false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.index ["created_at"], name: "users_created_at_idx"
    t.index ["email"], name: "index_users_on_email", unique: true
    t.index ["email"], name: "users_email_idx"
    t.index ["lastname"], name: "users_lastname_idx"
    t.index ["mobile_number"], name: "users_mobile_number_idx"
    t.index ["other_name"], name: "users_other_name_idx"
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
    t.index ["updated_at"], name: "users_updated_at_idx"
    t.index ["username"], name: "users_username_idx"
  end

end
