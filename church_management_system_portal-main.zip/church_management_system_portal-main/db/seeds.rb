#the highest role with all the permissions.
# Role.create(name: 'Super Admin')
# Role.create(name: 'Staff')

Permission.create(action: 'manage', subject_class:'all')

# create a user and assign the super admin role to him
User.create(username: "Isaac", email: "isaac@appsnmobilesolutions.com", password: "test1234", password_confirmation: "test1234", role_id: Role.find_by_name('Admin').id)
#
# User.create(name: "Neo", email: "neo@matrix.com", password: "the_one", password_confirmation: "the_one", role_id: Role.find_by_name('Staff').id)
