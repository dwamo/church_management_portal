require "test_helper"

class CareGivingInfosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @care_giving_info = care_giving_infos(:one)
  end

  test "should get index" do
    get care_giving_infos_url
    assert_response :success
  end

  test "should get new" do
    get new_care_giving_info_url
    assert_response :success
  end

  test "should create care_giving_info" do
    assert_difference('CareGivingInfo.count') do
      post care_giving_infos_url, params: { care_giving_info: { active_status: @care_giving_info.active_status, comment: @care_giving_info.comment, condition_type_code: @care_giving_info.condition_type_code, created_at: @care_giving_info.created_at, del_status: @care_giving_info.del_status, end_date: @care_giving_info.end_date, facility_name: @care_giving_info.facility_name, facility_type: @care_giving_info.facility_type, person_assigned_code: @care_giving_info.person_assigned_code, start_date: @care_giving_info.start_date, updated_at: @care_giving_info.updated_at, user_id: @care_giving_info.user_id } }
    end

    assert_redirected_to care_giving_info_url(CareGivingInfo.last)
  end

  test "should show care_giving_info" do
    get care_giving_info_url(@care_giving_info)
    assert_response :success
  end

  test "should get edit" do
    get edit_care_giving_info_url(@care_giving_info)
    assert_response :success
  end

  test "should update care_giving_info" do
    patch care_giving_info_url(@care_giving_info), params: { care_giving_info: { active_status: @care_giving_info.active_status, comment: @care_giving_info.comment, condition_type_code: @care_giving_info.condition_type_code, created_at: @care_giving_info.created_at, del_status: @care_giving_info.del_status, end_date: @care_giving_info.end_date, facility_name: @care_giving_info.facility_name, facility_type: @care_giving_info.facility_type, person_assigned_code: @care_giving_info.person_assigned_code, start_date: @care_giving_info.start_date, updated_at: @care_giving_info.updated_at, user_id: @care_giving_info.user_id } }
    assert_redirected_to care_giving_info_url(@care_giving_info)
  end

  test "should destroy care_giving_info" do
    assert_difference('CareGivingInfo.count', -1) do
      delete care_giving_info_url(@care_giving_info)
    end

    assert_redirected_to care_giving_infos_url
  end
end
