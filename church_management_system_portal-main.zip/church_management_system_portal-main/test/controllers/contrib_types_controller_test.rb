require "test_helper"

class ContribTypesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @contrib_type = contrib_types(:one)
  end

  test "should get index" do
    get contrib_types_url
    assert_response :success
  end

  test "should get new" do
    get new_contrib_type_url
    assert_response :success
  end

  test "should create contrib_type" do
    assert_difference('ContribType.count') do
      post contrib_types_url, params: { contrib_type: { active_status: @contrib_type.active_status, assigned_code: @contrib_type.assigned_code, comment: @contrib_type.comment, contribution_desc: @contrib_type.contribution_desc, created_at: @contrib_type.created_at, del_status: @contrib_type.del_status, updated_at: @contrib_type.updated_at, user_id: @contrib_type.user_id } }
    end

    assert_redirected_to contrib_type_url(ContribType.last)
  end

  test "should show contrib_type" do
    get contrib_type_url(@contrib_type)
    assert_response :success
  end

  test "should get edit" do
    get edit_contrib_type_url(@contrib_type)
    assert_response :success
  end

  test "should update contrib_type" do
    patch contrib_type_url(@contrib_type), params: { contrib_type: { active_status: @contrib_type.active_status, assigned_code: @contrib_type.assigned_code, comment: @contrib_type.comment, contribution_desc: @contrib_type.contribution_desc, created_at: @contrib_type.created_at, del_status: @contrib_type.del_status, updated_at: @contrib_type.updated_at, user_id: @contrib_type.user_id } }
    assert_redirected_to contrib_type_url(@contrib_type)
  end

  test "should destroy contrib_type" do
    assert_difference('ContribType.count', -1) do
      delete contrib_type_url(@contrib_type)
    end

    assert_redirected_to contrib_types_url
  end
end
