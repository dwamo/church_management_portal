require "test_helper"

class DisabilityMastersControllerTest < ActionDispatch::IntegrationTest
  setup do
    @disability_master = disability_masters(:one)
  end

  test "should get index" do
    get disability_masters_url
    assert_response :success
  end

  test "should get new" do
    get new_disability_master_url
    assert_response :success
  end

  test "should create disability_master" do
    assert_difference('DisabilityMaster.count') do
      post disability_masters_url, params: { disability_master: { active_status: @disability_master.active_status, comment: @disability_master.comment, created_at: @disability_master.created_at, del_status: @disability_master.del_status, disability_desc: @disability_master.disability_desc, updated_at: @disability_master.updated_at, user_id: @disability_master.user_id } }
    end

    assert_redirected_to disability_master_url(DisabilityMaster.last)
  end

  test "should show disability_master" do
    get disability_master_url(@disability_master)
    assert_response :success
  end

  test "should get edit" do
    get edit_disability_master_url(@disability_master)
    assert_response :success
  end

  test "should update disability_master" do
    patch disability_master_url(@disability_master), params: { disability_master: { active_status: @disability_master.active_status, comment: @disability_master.comment, created_at: @disability_master.created_at, del_status: @disability_master.del_status, disability_desc: @disability_master.disability_desc, updated_at: @disability_master.updated_at, user_id: @disability_master.user_id } }
    assert_redirected_to disability_master_url(@disability_master)
  end

  test "should destroy disability_master" do
    assert_difference('DisabilityMaster.count', -1) do
      delete disability_master_url(@disability_master)
    end

    assert_redirected_to disability_masters_url
  end
end
