require "test_helper"

class EmpStatusMastersControllerTest < ActionDispatch::IntegrationTest
  setup do
    @emp_status_master = emp_status_masters(:one)
  end

  test "should get index" do
    get emp_status_masters_url
    assert_response :success
  end

  test "should get new" do
    get new_emp_status_master_url
    assert_response :success
  end

  test "should create emp_status_master" do
    assert_difference('EmpStatusMaster.count') do
      post emp_status_masters_url, params: { emp_status_master: { active_status: @emp_status_master.active_status, assigned_code: @emp_status_master.assigned_code, comment: @emp_status_master.comment, created_at: @emp_status_master.created_at, del_status: @emp_status_master.del_status, emp_status_desc: @emp_status_master.emp_status_desc, updated_at: @emp_status_master.updated_at, user_id: @emp_status_master.user_id } }
    end

    assert_redirected_to emp_status_master_url(EmpStatusMaster.last)
  end

  test "should show emp_status_master" do
    get emp_status_master_url(@emp_status_master)
    assert_response :success
  end

  test "should get edit" do
    get edit_emp_status_master_url(@emp_status_master)
    assert_response :success
  end

  test "should update emp_status_master" do
    patch emp_status_master_url(@emp_status_master), params: { emp_status_master: { active_status: @emp_status_master.active_status, assigned_code: @emp_status_master.assigned_code, comment: @emp_status_master.comment, created_at: @emp_status_master.created_at, del_status: @emp_status_master.del_status, emp_status_desc: @emp_status_master.emp_status_desc, updated_at: @emp_status_master.updated_at, user_id: @emp_status_master.user_id } }
    assert_redirected_to emp_status_master_url(@emp_status_master)
  end

  test "should destroy emp_status_master" do
    assert_difference('EmpStatusMaster.count', -1) do
      delete emp_status_master_url(@emp_status_master)
    end

    assert_redirected_to emp_status_masters_url
  end
end
