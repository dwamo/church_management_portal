require "test_helper"

class EntityExtraInfosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @entity_extra_info = entity_extra_infos(:one)
  end

  test "should get index" do
    get entity_extra_infos_url
    assert_response :success
  end

  test "should get new" do
    get new_entity_extra_info_url
    assert_response :success
  end

  test "should create entity_extra_info" do
    assert_difference('EntityExtraInfo.count') do
      post entity_extra_infos_url, params: { entity_extra_info: { active_status: @entity_extra_info.active_status, comment: @entity_extra_info.comment, created_at: @entity_extra_info.created_at, del_status: @entity_extra_info.del_status, entity_code: @entity_extra_info.entity_code, entity_division_code: @entity_extra_info.entity_division_code, person_assigned_code: @entity_extra_info.person_assigned_code, person_role_code: @entity_extra_info.person_role_code, sub_entity_code: @entity_extra_info.sub_entity_code, updated_at: @entity_extra_info.updated_at, user_id: @entity_extra_info.user_id } }
    end

    assert_redirected_to entity_extra_info_url(EntityExtraInfo.last)
  end

  test "should show entity_extra_info" do
    get entity_extra_info_url(@entity_extra_info)
    assert_response :success
  end

  test "should get edit" do
    get edit_entity_extra_info_url(@entity_extra_info)
    assert_response :success
  end

  test "should update entity_extra_info" do
    patch entity_extra_info_url(@entity_extra_info), params: { entity_extra_info: { active_status: @entity_extra_info.active_status, comment: @entity_extra_info.comment, created_at: @entity_extra_info.created_at, del_status: @entity_extra_info.del_status, entity_code: @entity_extra_info.entity_code, entity_division_code: @entity_extra_info.entity_division_code, person_assigned_code: @entity_extra_info.person_assigned_code, person_role_code: @entity_extra_info.person_role_code, sub_entity_code: @entity_extra_info.sub_entity_code, updated_at: @entity_extra_info.updated_at, user_id: @entity_extra_info.user_id } }
    assert_redirected_to entity_extra_info_url(@entity_extra_info)
  end

  test "should destroy entity_extra_info" do
    assert_difference('EntityExtraInfo.count', -1) do
      delete entity_extra_info_url(@entity_extra_info)
    end

    assert_redirected_to entity_extra_infos_url
  end
end
