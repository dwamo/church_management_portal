require "test_helper"

class EntityInfoBoardsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @entity_info_board = entity_info_boards(:one)
  end

  test "should get index" do
    get entity_info_boards_url
    assert_response :success
  end

  test "should get new" do
    get new_entity_info_board_url
    assert_response :success
  end

  test "should create entity_info_board" do
    assert_difference('EntityInfoBoard.count') do
      post entity_info_boards_url, params: { entity_info_board: { entity_code: @entity_info_board.entity_code, logo_data: @entity_info_board.logo_data, logo_path: @entity_info_board.logo_path, motto: @entity_info_board.motto } }
    end

    assert_redirected_to entity_info_board_url(EntityInfoBoard.last)
  end

  test "should show entity_info_board" do
    get entity_info_board_url(@entity_info_board)
    assert_response :success
  end

  test "should get edit" do
    get edit_entity_info_board_url(@entity_info_board)
    assert_response :success
  end

  test "should update entity_info_board" do
    patch entity_info_board_url(@entity_info_board), params: { entity_info_board: { entity_code: @entity_info_board.entity_code, logo_data: @entity_info_board.logo_data, logo_path: @entity_info_board.logo_path, motto: @entity_info_board.motto } }
    assert_redirected_to entity_info_board_url(@entity_info_board)
  end

  test "should destroy entity_info_board" do
    assert_difference('EntityInfoBoard.count', -1) do
      delete entity_info_board_url(@entity_info_board)
    end

    assert_redirected_to entity_info_boards_url
  end
end
