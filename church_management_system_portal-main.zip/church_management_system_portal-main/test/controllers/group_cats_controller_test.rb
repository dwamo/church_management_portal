require "test_helper"

class GroupCatsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @group_cat = group_cats(:one)
  end

  test "should get index" do
    get group_cats_url
    assert_response :success
  end

  test "should get new" do
    get new_group_cat_url
    assert_response :success
  end

  test "should create group_cat" do
    assert_difference('GroupCat.count') do
      post group_cats_url, params: { group_cat: { active_status: @group_cat.active_status, assigned_code: @group_cat.assigned_code, comment: @group_cat.comment, created_at: @group_cat.created_at, del_status: @group_cat.del_status, entity_info_code: @group_cat.entity_info_code, group_cat_desc: @group_cat.group_cat_desc, updated_at: @group_cat.updated_at, user_id: @group_cat.user_id } }
    end

    assert_redirected_to group_cat_url(GroupCat.last)
  end

  test "should show group_cat" do
    get group_cat_url(@group_cat)
    assert_response :success
  end

  test "should get edit" do
    get edit_group_cat_url(@group_cat)
    assert_response :success
  end

  test "should update group_cat" do
    patch group_cat_url(@group_cat), params: { group_cat: { active_status: @group_cat.active_status, assigned_code: @group_cat.assigned_code, comment: @group_cat.comment, created_at: @group_cat.created_at, del_status: @group_cat.del_status, entity_info_code: @group_cat.entity_info_code, group_cat_desc: @group_cat.group_cat_desc, updated_at: @group_cat.updated_at, user_id: @group_cat.user_id } }
    assert_redirected_to group_cat_url(@group_cat)
  end

  test "should destroy group_cat" do
    assert_difference('GroupCat.count', -1) do
      delete group_cat_url(@group_cat)
    end

    assert_redirected_to group_cats_url
  end
end
