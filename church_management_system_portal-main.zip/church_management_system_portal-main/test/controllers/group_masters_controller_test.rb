require "test_helper"

class GroupMastersControllerTest < ActionDispatch::IntegrationTest
  setup do
    @group_master = group_masters(:one)
  end

  test "should get index" do
    get group_masters_url
    assert_response :success
  end

  test "should get new" do
    get new_group_master_url
    assert_response :success
  end

  test "should create group_master" do
    assert_difference('GroupMaster.count') do
      post group_masters_url, params: { group_master: { active_status: @group_master.active_status, assigned_code: @group_master.assigned_code, comment: @group_master.comment, created_at: @group_master.created_at, del_status: @group_master.del_status, entity_info_code: @group_master.entity_info_code, group_alias: @group_master.group_alias, group_cat_code: @group_master.group_cat_code, group_name: @group_master.group_name, updated_at: @group_master.updated_at, user_id: @group_master.user_id } }
    end

    assert_redirected_to group_master_url(GroupMaster.last)
  end

  test "should show group_master" do
    get group_master_url(@group_master)
    assert_response :success
  end

  test "should get edit" do
    get edit_group_master_url(@group_master)
    assert_response :success
  end

  test "should update group_master" do
    patch group_master_url(@group_master), params: { group_master: { active_status: @group_master.active_status, assigned_code: @group_master.assigned_code, comment: @group_master.comment, created_at: @group_master.created_at, del_status: @group_master.del_status, entity_info_code: @group_master.entity_info_code, group_alias: @group_master.group_alias, group_cat_code: @group_master.group_cat_code, group_name: @group_master.group_name, updated_at: @group_master.updated_at, user_id: @group_master.user_id } }
    assert_redirected_to group_master_url(@group_master)
  end

  test "should destroy group_master" do
    assert_difference('GroupMaster.count', -1) do
      delete group_master_url(@group_master)
    end

    assert_redirected_to group_masters_url
  end
end
