require "test_helper"

class IssueLogTypesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @issue_log_type = issue_log_types(:one)
  end

  test "should get index" do
    get issue_log_types_url
    assert_response :success
  end

  test "should get new" do
    get new_issue_log_type_url
    assert_response :success
  end

  test "should create issue_log_type" do
    assert_difference('IssueLogType.count') do
      post issue_log_types_url, params: { issue_log_type: { active_status: @issue_log_type.active_status, created_at: @issue_log_type.created_at, del_status: @issue_log_type.del_status, log_type_desc: @issue_log_type.log_type_desc, updated_at: @issue_log_type.updated_at, user_id: @issue_log_type.user_id } }
    end

    assert_redirected_to issue_log_type_url(IssueLogType.last)
  end

  test "should show issue_log_type" do
    get issue_log_type_url(@issue_log_type)
    assert_response :success
  end

  test "should get edit" do
    get edit_issue_log_type_url(@issue_log_type)
    assert_response :success
  end

  test "should update issue_log_type" do
    patch issue_log_type_url(@issue_log_type), params: { issue_log_type: { active_status: @issue_log_type.active_status, created_at: @issue_log_type.created_at, del_status: @issue_log_type.del_status, log_type_desc: @issue_log_type.log_type_desc, updated_at: @issue_log_type.updated_at, user_id: @issue_log_type.user_id } }
    assert_redirected_to issue_log_type_url(@issue_log_type)
  end

  test "should destroy issue_log_type" do
    assert_difference('IssueLogType.count', -1) do
      delete issue_log_type_url(@issue_log_type)
    end

    assert_redirected_to issue_log_types_url
  end
end
