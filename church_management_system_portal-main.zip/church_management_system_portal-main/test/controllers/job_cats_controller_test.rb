require "test_helper"

class JobCatsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @job_cat = job_cats(:one)
  end

  test "should get index" do
    get job_cats_url
    assert_response :success
  end

  test "should get new" do
    get new_job_cat_url
    assert_response :success
  end

  test "should create job_cat" do
    assert_difference('JobCat.count') do
      post job_cats_url, params: { job_cat: { active_status: @job_cat.active_status, assigned_code: @job_cat.assigned_code, comment: @job_cat.comment, created_at: @job_cat.created_at, del_status: @job_cat.del_status, job_cat_desc: @job_cat.job_cat_desc, updated_at: @job_cat.updated_at, user_id: @job_cat.user_id } }
    end

    assert_redirected_to job_cat_url(JobCat.last)
  end

  test "should show job_cat" do
    get job_cat_url(@job_cat)
    assert_response :success
  end

  test "should get edit" do
    get edit_job_cat_url(@job_cat)
    assert_response :success
  end

  test "should update job_cat" do
    patch job_cat_url(@job_cat), params: { job_cat: { active_status: @job_cat.active_status, assigned_code: @job_cat.assigned_code, comment: @job_cat.comment, created_at: @job_cat.created_at, del_status: @job_cat.del_status, job_cat_desc: @job_cat.job_cat_desc, updated_at: @job_cat.updated_at, user_id: @job_cat.user_id } }
    assert_redirected_to job_cat_url(@job_cat)
  end

  test "should destroy job_cat" do
    assert_difference('JobCat.count', -1) do
      delete job_cat_url(@job_cat)
    end

    assert_redirected_to job_cats_url
  end
end
