require "test_helper"

class JobTypesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @job_type = job_types(:one)
  end

  test "should get index" do
    get job_types_url
    assert_response :success
  end

  test "should get new" do
    get new_job_type_url
    assert_response :success
  end

  test "should create job_type" do
    assert_difference('JobType.count') do
      post job_types_url, params: { job_type: { active_status: @job_type.active_status, assigned_code: @job_type.assigned_code, comment: @job_type.comment, created_at: @job_type.created_at, del_status: @job_type.del_status, job_cat_code: @job_type.job_cat_code, job_type_desc: @job_type.job_type_desc, updated_at: @job_type.updated_at } }
    end

    assert_redirected_to job_type_url(JobType.last)
  end

  test "should show job_type" do
    get job_type_url(@job_type)
    assert_response :success
  end

  test "should get edit" do
    get edit_job_type_url(@job_type)
    assert_response :success
  end

  test "should update job_type" do
    patch job_type_url(@job_type), params: { job_type: { active_status: @job_type.active_status, assigned_code: @job_type.assigned_code, comment: @job_type.comment, created_at: @job_type.created_at, del_status: @job_type.del_status, job_cat_code: @job_type.job_cat_code, job_type_desc: @job_type.job_type_desc, updated_at: @job_type.updated_at } }
    assert_redirected_to job_type_url(@job_type)
  end

  test "should destroy job_type" do
    assert_difference('JobType.count', -1) do
      delete job_type_url(@job_type)
    end

    assert_redirected_to job_types_url
  end
end
