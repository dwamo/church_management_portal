require "test_helper"

class MaritalStatusMastersControllerTest < ActionDispatch::IntegrationTest
  setup do
    @marital_status_master = marital_status_masters(:one)
  end

  test "should get index" do
    get marital_status_masters_url
    assert_response :success
  end

  test "should get new" do
    get new_marital_status_master_url
    assert_response :success
  end

  test "should create marital_status_master" do
    assert_difference('MaritalStatusMaster.count') do
      post marital_status_masters_url, params: { marital_status_master: { active_status: @marital_status_master.active_status, assigned_code: @marital_status_master.assigned_code, comment: @marital_status_master.comment, created_at: @marital_status_master.created_at, del_status: @marital_status_master.del_status, status_desc: @marital_status_master.status_desc, updated_at: @marital_status_master.updated_at, user_id: @marital_status_master.user_id } }
    end

    assert_redirected_to marital_status_master_url(MaritalStatusMaster.last)
  end

  test "should show marital_status_master" do
    get marital_status_master_url(@marital_status_master)
    assert_response :success
  end

  test "should get edit" do
    get edit_marital_status_master_url(@marital_status_master)
    assert_response :success
  end

  test "should update marital_status_master" do
    patch marital_status_master_url(@marital_status_master), params: { marital_status_master: { active_status: @marital_status_master.active_status, assigned_code: @marital_status_master.assigned_code, comment: @marital_status_master.comment, created_at: @marital_status_master.created_at, del_status: @marital_status_master.del_status, status_desc: @marital_status_master.status_desc, updated_at: @marital_status_master.updated_at, user_id: @marital_status_master.user_id } }
    assert_redirected_to marital_status_master_url(@marital_status_master)
  end

  test "should destroy marital_status_master" do
    assert_difference('MaritalStatusMaster.count', -1) do
      delete marital_status_master_url(@marital_status_master)
    end

    assert_redirected_to marital_status_masters_url
  end
end
