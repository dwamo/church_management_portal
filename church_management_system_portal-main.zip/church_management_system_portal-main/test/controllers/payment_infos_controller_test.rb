require "test_helper"

class PaymentInfosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @payment_info = payment_infos(:one)
  end

  test "should get index" do
    get payment_infos_url
    assert_response :success
  end

  test "should get new" do
    get new_payment_info_url
    assert_response :success
  end

  test "should create payment_info" do
    assert_difference('PaymentInfo.count') do
      post payment_infos_url, params: { payment_info: { amount: @payment_info.amount, created_at: @payment_info.created_at, mobile_number: @payment_info.mobile_number, payment_mode: @payment_info.payment_mode, person_assigned_code: @payment_info.person_assigned_code, product_id: @payment_info.product_id, reference: @payment_info.reference, status: @payment_info.status, trans_type: @payment_info.trans_type, updated_at: @payment_info.updated_at } }
    end

    assert_redirected_to payment_info_url(PaymentInfo.last)
  end

  test "should show payment_info" do
    get payment_info_url(@payment_info)
    assert_response :success
  end

  test "should get edit" do
    get edit_payment_info_url(@payment_info)
    assert_response :success
  end

  test "should update payment_info" do
    patch payment_info_url(@payment_info), params: { payment_info: { amount: @payment_info.amount, created_at: @payment_info.created_at, mobile_number: @payment_info.mobile_number, payment_mode: @payment_info.payment_mode, person_assigned_code: @payment_info.person_assigned_code, product_id: @payment_info.product_id, reference: @payment_info.reference, status: @payment_info.status, trans_type: @payment_info.trans_type, updated_at: @payment_info.updated_at } }
    assert_redirected_to payment_info_url(@payment_info)
  end

  test "should destroy payment_info" do
    assert_difference('PaymentInfo.count', -1) do
      delete payment_info_url(@payment_info)
    end

    assert_redirected_to payment_infos_url
  end
end
