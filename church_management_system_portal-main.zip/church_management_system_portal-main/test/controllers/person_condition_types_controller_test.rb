require "test_helper"

class PersonConditionTypesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_condition_type = person_condition_types(:one)
  end

  test "should get index" do
    get person_condition_types_url
    assert_response :success
  end

  test "should get new" do
    get new_person_condition_type_url
    assert_response :success
  end

  test "should create person_condition_type" do
    assert_difference('PersonConditionType.count') do
      post person_condition_types_url, params: { person_condition_type: { active_status: @person_condition_type.active_status, assigned_code: @person_condition_type.assigned_code, condition_desc: @person_condition_type.condition_desc, created_at: @person_condition_type.created_at, del_status: @person_condition_type.del_status, updated_at: @person_condition_type.updated_at, user_id: @person_condition_type.user_id } }
    end

    assert_redirected_to person_condition_type_url(PersonConditionType.last)
  end

  test "should show person_condition_type" do
    get person_condition_type_url(@person_condition_type)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_condition_type_url(@person_condition_type)
    assert_response :success
  end

  test "should update person_condition_type" do
    patch person_condition_type_url(@person_condition_type), params: { person_condition_type: { active_status: @person_condition_type.active_status, assigned_code: @person_condition_type.assigned_code, condition_desc: @person_condition_type.condition_desc, created_at: @person_condition_type.created_at, del_status: @person_condition_type.del_status, updated_at: @person_condition_type.updated_at, user_id: @person_condition_type.user_id } }
    assert_redirected_to person_condition_type_url(@person_condition_type)
  end

  test "should destroy person_condition_type" do
    assert_difference('PersonConditionType.count', -1) do
      delete person_condition_type_url(@person_condition_type)
    end

    assert_redirected_to person_condition_types_url
  end
end
