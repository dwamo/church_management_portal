require "test_helper"

class PersonContactInfosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_contact_info = person_contact_infos(:one)
  end

  test "should get index" do
    get person_contact_infos_url
    assert_response :success
  end

  test "should get new" do
    get new_person_contact_info_url
    assert_response :success
  end

  test "should create person_contact_info" do
    assert_difference('PersonContactInfo.count') do
      post person_contact_infos_url, params: { person_contact_info: { active_status: @person_contact_info.active_status, comment: @person_contact_info.comment, contact_email: @person_contact_info.contact_email, contact_number: @person_contact_info.contact_number, created_at: @person_contact_info.created_at, del_status: @person_contact_info.del_status, person_assigned_code: @person_contact_info.person_assigned_code, postal_addr: @person_contact_info.postal_addr, res_addr: @person_contact_info.res_addr, res_city_town_id: @person_contact_info.res_city_town_id, res_region_code: @person_contact_info.res_region_code, updated_at: @person_contact_info.updated_at, user_id: @person_contact_info.user_id } }
    end

    assert_redirected_to person_contact_info_url(PersonContactInfo.last)
  end

  test "should show person_contact_info" do
    get person_contact_info_url(@person_contact_info)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_contact_info_url(@person_contact_info)
    assert_response :success
  end

  test "should update person_contact_info" do
    patch person_contact_info_url(@person_contact_info), params: { person_contact_info: { active_status: @person_contact_info.active_status, comment: @person_contact_info.comment, contact_email: @person_contact_info.contact_email, contact_number: @person_contact_info.contact_number, created_at: @person_contact_info.created_at, del_status: @person_contact_info.del_status, person_assigned_code: @person_contact_info.person_assigned_code, postal_addr: @person_contact_info.postal_addr, res_addr: @person_contact_info.res_addr, res_city_town_id: @person_contact_info.res_city_town_id, res_region_code: @person_contact_info.res_region_code, updated_at: @person_contact_info.updated_at, user_id: @person_contact_info.user_id } }
    assert_redirected_to person_contact_info_url(@person_contact_info)
  end

  test "should destroy person_contact_info" do
    assert_difference('PersonContactInfo.count', -1) do
      delete person_contact_info_url(@person_contact_info)
    end

    assert_redirected_to person_contact_infos_url
  end
end
