require "test_helper"

class PersonContribSetupsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_contrib_setup = person_contrib_setups(:one)
  end

  test "should get index" do
    get person_contrib_setups_url
    assert_response :success
  end

  test "should get new" do
    get new_person_contrib_setup_url
    assert_response :success
  end

  test "should create person_contrib_setup" do
    assert_difference('PersonContribSetup.count') do
      post person_contrib_setups_url, params: { person_contrib_setup: { active_status: @person_contrib_setup.active_status, comment: @person_contrib_setup.comment, complete_status: @person_contrib_setup.complete_status, created_at: @person_contrib_setup.created_at, del_status: @person_contrib_setup.del_status, entity_contribution_id: @person_contrib_setup.entity_contribution_id, freq: @person_contrib_setup.freq, person_assigned_code: @person_contrib_setup.person_assigned_code, start_date: @person_contrib_setup.start_date, sub_entity_code: @person_contrib_setup.sub_entity_code, updated_at: @person_contrib_setup.updated_at, user_id: @person_contrib_setup.user_id } }
    end

    assert_redirected_to person_contrib_setup_url(PersonContribSetup.last)
  end

  test "should show person_contrib_setup" do
    get person_contrib_setup_url(@person_contrib_setup)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_contrib_setup_url(@person_contrib_setup)
    assert_response :success
  end

  test "should update person_contrib_setup" do
    patch person_contrib_setup_url(@person_contrib_setup), params: { person_contrib_setup: { active_status: @person_contrib_setup.active_status, comment: @person_contrib_setup.comment, complete_status: @person_contrib_setup.complete_status, created_at: @person_contrib_setup.created_at, del_status: @person_contrib_setup.del_status, entity_contribution_id: @person_contrib_setup.entity_contribution_id, freq: @person_contrib_setup.freq, person_assigned_code: @person_contrib_setup.person_assigned_code, start_date: @person_contrib_setup.start_date, sub_entity_code: @person_contrib_setup.sub_entity_code, updated_at: @person_contrib_setup.updated_at, user_id: @person_contrib_setup.user_id } }
    assert_redirected_to person_contrib_setup_url(@person_contrib_setup)
  end

  test "should destroy person_contrib_setup" do
    assert_difference('PersonContribSetup.count', -1) do
      delete person_contrib_setup_url(@person_contrib_setup)
    end

    assert_redirected_to person_contrib_setups_url
  end
end
