require "test_helper"

class PersonContribsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_contrib = person_contribs(:one)
  end

  test "should get index" do
    get person_contribs_url
    assert_response :success
  end

  test "should get new" do
    get new_person_contrib_url
    assert_response :success
  end

  test "should create person_contrib" do
    assert_difference('PersonContrib.count') do
      post person_contribs_url, params: { person_contrib: { amount: @person_contrib.amount, created_at: @person_contrib.created_at, person_assigned_code: @person_contrib.person_assigned_code, person_contrib_setup_id: @person_contrib.person_contrib_setup_id, src: @person_contrib.src, sub_entity_contrib_id: @person_contrib.sub_entity_contrib_id, updated_at: @person_contrib.updated_at } }
    end

    assert_redirected_to person_contrib_url(PersonContrib.last)
  end

  test "should show person_contrib" do
    get person_contrib_url(@person_contrib)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_contrib_url(@person_contrib)
    assert_response :success
  end

  test "should update person_contrib" do
    patch person_contrib_url(@person_contrib), params: { person_contrib: { amount: @person_contrib.amount, created_at: @person_contrib.created_at, person_assigned_code: @person_contrib.person_assigned_code, person_contrib_setup_id: @person_contrib.person_contrib_setup_id, src: @person_contrib.src, sub_entity_contrib_id: @person_contrib.sub_entity_contrib_id, updated_at: @person_contrib.updated_at } }
    assert_redirected_to person_contrib_url(@person_contrib)
  end

  test "should destroy person_contrib" do
    assert_difference('PersonContrib.count', -1) do
      delete person_contrib_url(@person_contrib)
    end

    assert_redirected_to person_contribs_url
  end
end
