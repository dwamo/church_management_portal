require "test_helper"

class PersonDisabilityInfosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_disability_info = person_disability_infos(:one)
  end

  test "should get index" do
    get person_disability_infos_url
    assert_response :success
  end

  test "should get new" do
    get new_person_disability_info_url
    assert_response :success
  end

  test "should create person_disability_info" do
    assert_difference('PersonDisabilityInfo.count') do
      post person_disability_infos_url, params: { person_disability_info: { active_status: @person_disability_info.active_status, comment: @person_disability_info.comment, created_at: @person_disability_info.created_at, del_status: @person_disability_info.del_status, disability_id: @person_disability_info.disability_id, person_assigned_code: @person_disability_info.person_assigned_code, updated_at: @person_disability_info.updated_at, user_id: @person_disability_info.user_id } }
    end

    assert_redirected_to person_disability_info_url(PersonDisabilityInfo.last)
  end

  test "should show person_disability_info" do
    get person_disability_info_url(@person_disability_info)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_disability_info_url(@person_disability_info)
    assert_response :success
  end

  test "should update person_disability_info" do
    patch person_disability_info_url(@person_disability_info), params: { person_disability_info: { active_status: @person_disability_info.active_status, comment: @person_disability_info.comment, created_at: @person_disability_info.created_at, del_status: @person_disability_info.del_status, disability_id: @person_disability_info.disability_id, person_assigned_code: @person_disability_info.person_assigned_code, updated_at: @person_disability_info.updated_at, user_id: @person_disability_info.user_id } }
    assert_redirected_to person_disability_info_url(@person_disability_info)
  end

  test "should destroy person_disability_info" do
    assert_difference('PersonDisabilityInfo.count', -1) do
      delete person_disability_info_url(@person_disability_info)
    end

    assert_redirected_to person_disability_infos_url
  end
end
