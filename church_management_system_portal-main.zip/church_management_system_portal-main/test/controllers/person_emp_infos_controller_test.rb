require "test_helper"

class PersonEmpInfosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_emp_info = person_emp_infos(:one)
  end

  test "should get index" do
    get person_emp_infos_url
    assert_response :success
  end

  test "should get new" do
    get new_person_emp_info_url
    assert_response :success
  end

  test "should create person_emp_info" do
    assert_difference('PersonEmpInfo.count') do
      post person_emp_infos_url, params: { person_emp_info: { active_status: @person_emp_info.active_status, comment: @person_emp_info.comment, contact_email: @person_emp_info.contact_email, contact_number: @person_emp_info.contact_number, created_at: @person_emp_info.created_at, del_status: @person_emp_info.del_status, emp_loc_addr: @person_emp_info.emp_loc_addr, emp_loc_city_town_id: @person_emp_info.emp_loc_city_town_id, emp_loc_region_code: @person_emp_info.emp_loc_region_code, emp_postal_addr: @person_emp_info.emp_postal_addr, job_title: @person_emp_info.job_title, job_type_code: @person_emp_info.job_type_code, location_addr: @person_emp_info.location_addr, person_assigned_code: @person_emp_info.person_assigned_code, postal_addr: @person_emp_info.postal_addr, updated_at: @person_emp_info.updated_at, user_id: @person_emp_info.user_id } }
    end

    assert_redirected_to person_emp_info_url(PersonEmpInfo.last)
  end

  test "should show person_emp_info" do
    get person_emp_info_url(@person_emp_info)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_emp_info_url(@person_emp_info)
    assert_response :success
  end

  test "should update person_emp_info" do
    patch person_emp_info_url(@person_emp_info), params: { person_emp_info: { active_status: @person_emp_info.active_status, comment: @person_emp_info.comment, contact_email: @person_emp_info.contact_email, contact_number: @person_emp_info.contact_number, created_at: @person_emp_info.created_at, del_status: @person_emp_info.del_status, emp_loc_addr: @person_emp_info.emp_loc_addr, emp_loc_city_town_id: @person_emp_info.emp_loc_city_town_id, emp_loc_region_code: @person_emp_info.emp_loc_region_code, emp_postal_addr: @person_emp_info.emp_postal_addr, job_title: @person_emp_info.job_title, job_type_code: @person_emp_info.job_type_code, location_addr: @person_emp_info.location_addr, person_assigned_code: @person_emp_info.person_assigned_code, postal_addr: @person_emp_info.postal_addr, updated_at: @person_emp_info.updated_at, user_id: @person_emp_info.user_id } }
    assert_redirected_to person_emp_info_url(@person_emp_info)
  end

  test "should destroy person_emp_info" do
    assert_difference('PersonEmpInfo.count', -1) do
      delete person_emp_info_url(@person_emp_info)
    end

    assert_redirected_to person_emp_infos_url
  end
end
