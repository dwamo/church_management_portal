require "test_helper"

class PersonExitInfosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_exit_info = person_exit_infos(:one)
  end

  test "should get index" do
    get person_exit_infos_url
    assert_response :success
  end

  test "should get new" do
    get new_person_exit_info_url
    assert_response :success
  end

  test "should create person_exit_info" do
    assert_difference('PersonExitInfo.count') do
      post person_exit_infos_url, params: { person_exit_info: { active_status: @person_exit_info.active_status, cause: @person_exit_info.cause, comment: @person_exit_info.comment, del_status: @person_exit_info.del_status, entity_code: @person_exit_info.entity_code, exit_lov_id: @person_exit_info.exit_lov_id, integer: @person_exit_info.integer, person_assigned_code: @person_exit_info.person_assigned_code, sub_entity_code: @person_exit_info.sub_entity_code } }
    end

    assert_redirected_to person_exit_info_url(PersonExitInfo.last)
  end

  test "should show person_exit_info" do
    get person_exit_info_url(@person_exit_info)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_exit_info_url(@person_exit_info)
    assert_response :success
  end

  test "should update person_exit_info" do
    patch person_exit_info_url(@person_exit_info), params: { person_exit_info: { active_status: @person_exit_info.active_status, cause: @person_exit_info.cause, comment: @person_exit_info.comment, del_status: @person_exit_info.del_status, entity_code: @person_exit_info.entity_code, exit_lov_id: @person_exit_info.exit_lov_id, integer: @person_exit_info.integer, person_assigned_code: @person_exit_info.person_assigned_code, sub_entity_code: @person_exit_info.sub_entity_code } }
    assert_redirected_to person_exit_info_url(@person_exit_info)
  end

  test "should destroy person_exit_info" do
    assert_difference('PersonExitInfo.count', -1) do
      delete person_exit_info_url(@person_exit_info)
    end

    assert_redirected_to person_exit_infos_url
  end
end
