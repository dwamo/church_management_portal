require "test_helper"

class PersonExitLovsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_exit_lov = person_exit_lovs(:one)
  end

  test "should get index" do
    get person_exit_lovs_url
    assert_response :success
  end

  test "should get new" do
    get new_person_exit_lov_url
    assert_response :success
  end

  test "should create person_exit_lov" do
    assert_difference('PersonExitLov.count') do
      post person_exit_lovs_url, params: { person_exit_lov: { active_status: @person_exit_lov.active_status, comment: @person_exit_lov.comment, created_at: @person_exit_lov.created_at, del_status: @person_exit_lov.del_status, entity_code: @person_exit_lov.entity_code, exit_desc: @person_exit_lov.exit_desc, user_id: @person_exit_lov.user_id } }
    end

    assert_redirected_to person_exit_lov_url(PersonExitLov.last)
  end

  test "should show person_exit_lov" do
    get person_exit_lov_url(@person_exit_lov)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_exit_lov_url(@person_exit_lov)
    assert_response :success
  end

  test "should update person_exit_lov" do
    patch person_exit_lov_url(@person_exit_lov), params: { person_exit_lov: { active_status: @person_exit_lov.active_status, comment: @person_exit_lov.comment, created_at: @person_exit_lov.created_at, del_status: @person_exit_lov.del_status, entity_code: @person_exit_lov.entity_code, exit_desc: @person_exit_lov.exit_desc, user_id: @person_exit_lov.user_id } }
    assert_redirected_to person_exit_lov_url(@person_exit_lov)
  end

  test "should destroy person_exit_lov" do
    assert_difference('PersonExitLov.count', -1) do
      delete person_exit_lov_url(@person_exit_lov)
    end

    assert_redirected_to person_exit_lovs_url
  end
end
