require "test_helper"

class PersonExtraInfosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_extra_info = person_extra_infos(:one)
  end

  test "should get index" do
    get person_extra_infos_url
    assert_response :success
  end

  test "should get new" do
    get new_person_extra_info_url
    assert_response :success
  end

  test "should create person_extra_info" do
    assert_difference('PersonExtraInfo.count') do
      post person_extra_infos_url, params: { person_extra_info: { active_status: @person_extra_info.active_status, comment: @person_extra_info.comment, created_at: @person_extra_info.created_at, day_born: @person_extra_info.day_born, del_status: @person_extra_info.del_status, emp_status_code: @person_extra_info.emp_status_code, marital_status_code: @person_extra_info.marital_status_code, person_assigned_code: @person_extra_info.person_assigned_code, physical_disability: @person_extra_info.physical_disability, updated_at: @person_extra_info.updated_at, user_id: @person_extra_info.user_id } }
    end

    assert_redirected_to person_extra_info_url(PersonExtraInfo.last)
  end

  test "should show person_extra_info" do
    get person_extra_info_url(@person_extra_info)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_extra_info_url(@person_extra_info)
    assert_response :success
  end

  test "should update person_extra_info" do
    patch person_extra_info_url(@person_extra_info), params: { person_extra_info: { active_status: @person_extra_info.active_status, comment: @person_extra_info.comment, created_at: @person_extra_info.created_at, day_born: @person_extra_info.day_born, del_status: @person_extra_info.del_status, emp_status_code: @person_extra_info.emp_status_code, marital_status_code: @person_extra_info.marital_status_code, person_assigned_code: @person_extra_info.person_assigned_code, physical_disability: @person_extra_info.physical_disability, updated_at: @person_extra_info.updated_at, user_id: @person_extra_info.user_id } }
    assert_redirected_to person_extra_info_url(@person_extra_info)
  end

  test "should destroy person_extra_info" do
    assert_difference('PersonExtraInfo.count', -1) do
      delete person_extra_info_url(@person_extra_info)
    end

    assert_redirected_to person_extra_infos_url
  end
end
