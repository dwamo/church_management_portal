require "test_helper"

class PersonGroupInfosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_group_info = person_group_infos(:one)
  end

  test "should get index" do
    get person_group_infos_url
    assert_response :success
  end

  test "should get new" do
    get new_person_group_info_url
    assert_response :success
  end

  test "should create person_group_info" do
    assert_difference('PersonGroupInfo.count') do
      post person_group_infos_url, params: { person_group_info: { active_status: @person_group_info.active_status, comment: @person_group_info.comment, created_at: @person_group_info.created_at, del_status: @person_group_info.del_status, group_code: @person_group_info.group_code, person_assigned_code: @person_group_info.person_assigned_code, sub_entity_code: @person_group_info.sub_entity_code, updated_at: @person_group_info.updated_at, user_id: @person_group_info.user_id } }
    end

    assert_redirected_to person_group_info_url(PersonGroupInfo.last)
  end

  test "should show person_group_info" do
    get person_group_info_url(@person_group_info)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_group_info_url(@person_group_info)
    assert_response :success
  end

  test "should update person_group_info" do
    patch person_group_info_url(@person_group_info), params: { person_group_info: { active_status: @person_group_info.active_status, comment: @person_group_info.comment, created_at: @person_group_info.created_at, del_status: @person_group_info.del_status, group_code: @person_group_info.group_code, person_assigned_code: @person_group_info.person_assigned_code, sub_entity_code: @person_group_info.sub_entity_code, updated_at: @person_group_info.updated_at, user_id: @person_group_info.user_id } }
    assert_redirected_to person_group_info_url(@person_group_info)
  end

  test "should destroy person_group_info" do
    assert_difference('PersonGroupInfo.count', -1) do
      delete person_group_info_url(@person_group_info)
    end

    assert_redirected_to person_group_infos_url
  end
end
