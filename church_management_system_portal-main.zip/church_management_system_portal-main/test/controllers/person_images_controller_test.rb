require "test_helper"

class PersonImagesControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_image = person_images(:one)
  end

  test "should get index" do
    get person_images_url
    assert_response :success
  end

  test "should get new" do
    get new_person_image_url
    assert_response :success
  end

  test "should create person_image" do
    assert_difference('PersonImage.count') do
      post person_images_url, params: { person_image: { active_status: @person_image.active_status, comment: @person_image.comment, created_at: @person_image.created_at, del_status: @person_image.del_status, image_data: @person_image.image_data, image_path: @person_image.image_path, person_assigned_code: @person_image.person_assigned_code, updated_at: @person_image.updated_at, user_id: @person_image.user_id } }
    end

    assert_redirected_to person_image_url(PersonImage.last)
  end

  test "should show person_image" do
    get person_image_url(@person_image)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_image_url(@person_image)
    assert_response :success
  end

  test "should update person_image" do
    patch person_image_url(@person_image), params: { person_image: { active_status: @person_image.active_status, comment: @person_image.comment, created_at: @person_image.created_at, del_status: @person_image.del_status, image_data: @person_image.image_data, image_path: @person_image.image_path, person_assigned_code: @person_image.person_assigned_code, updated_at: @person_image.updated_at, user_id: @person_image.user_id } }
    assert_redirected_to person_image_url(@person_image)
  end

  test "should destroy person_image" do
    assert_difference('PersonImage.count', -1) do
      delete person_image_url(@person_image)
    end

    assert_redirected_to person_images_url
  end
end
