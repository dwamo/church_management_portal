require "test_helper"

class PersonInfosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_info = person_infos(:one)
  end

  test "should get index" do
    get person_infos_url
    assert_response :success
  end

  test "should get new" do
    get new_person_info_url
    assert_response :success
  end

  test "should create person_info" do
    assert_difference('PersonInfo.count') do
      post person_infos_url, params: { person_info: { active_status: @person_info.active_status, assigned_code: @person_info.assigned_code, birth_date: @person_info.birth_date, comment: @person_info.comment, created_at: @person_info.created_at, del_status: @person_info.del_status, entity_info_code: @person_info.entity_info_code, first_name: @person_info.first_name, gender: @person_info.gender, last_name: @person_info.last_name, other_names: @person_info.other_names, status: @person_info.status, updated_at: @person_info.updated_at, user_id: @person_info.user_id } }
    end

    assert_redirected_to person_info_url(PersonInfo.last)
  end

  test "should show person_info" do
    get person_info_url(@person_info)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_info_url(@person_info)
    assert_response :success
  end

  test "should update person_info" do
    patch person_info_url(@person_info), params: { person_info: { active_status: @person_info.active_status, assigned_code: @person_info.assigned_code, birth_date: @person_info.birth_date, comment: @person_info.comment, created_at: @person_info.created_at, del_status: @person_info.del_status, entity_info_code: @person_info.entity_info_code, first_name: @person_info.first_name, gender: @person_info.gender, last_name: @person_info.last_name, other_names: @person_info.other_names, status: @person_info.status, updated_at: @person_info.updated_at, user_id: @person_info.user_id } }
    assert_redirected_to person_info_url(@person_info)
  end

  test "should destroy person_info" do
    assert_difference('PersonInfo.count', -1) do
      delete person_info_url(@person_info)
    end

    assert_redirected_to person_infos_url
  end
end
