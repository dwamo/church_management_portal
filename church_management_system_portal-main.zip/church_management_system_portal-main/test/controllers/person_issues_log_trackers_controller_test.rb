require "test_helper"

class PersonIssuesLogTrackersControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_issues_log_tracker = person_issues_log_trackers(:one)
  end

  test "should get index" do
    get person_issues_log_trackers_url
    assert_response :success
  end

  test "should get new" do
    get new_person_issues_log_tracker_url
    assert_response :success
  end

  test "should create person_issues_log_tracker" do
    assert_difference('PersonIssuesLogTracker.count') do
      post person_issues_log_trackers_url, params: { person_issues_log_tracker: { active_status: @person_issues_log_tracker.active_status, comment: @person_issues_log_tracker.comment, created_at: @person_issues_log_tracker.created_at, del_status: @person_issues_log_tracker.del_status, person_assigned_code: @person_issues_log_tracker.person_assigned_code, person_issues_log_id: @person_issues_log_tracker.person_issues_log_id, updated_at: @person_issues_log_tracker.updated_at, user_id: @person_issues_log_tracker.user_id } }
    end

    assert_redirected_to person_issues_log_tracker_url(PersonIssuesLogTracker.last)
  end

  test "should show person_issues_log_tracker" do
    get person_issues_log_tracker_url(@person_issues_log_tracker)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_issues_log_tracker_url(@person_issues_log_tracker)
    assert_response :success
  end

  test "should update person_issues_log_tracker" do
    patch person_issues_log_tracker_url(@person_issues_log_tracker), params: { person_issues_log_tracker: { active_status: @person_issues_log_tracker.active_status, comment: @person_issues_log_tracker.comment, created_at: @person_issues_log_tracker.created_at, del_status: @person_issues_log_tracker.del_status, person_assigned_code: @person_issues_log_tracker.person_assigned_code, person_issues_log_id: @person_issues_log_tracker.person_issues_log_id, updated_at: @person_issues_log_tracker.updated_at, user_id: @person_issues_log_tracker.user_id } }
    assert_redirected_to person_issues_log_tracker_url(@person_issues_log_tracker)
  end

  test "should destroy person_issues_log_tracker" do
    assert_difference('PersonIssuesLogTracker.count', -1) do
      delete person_issues_log_tracker_url(@person_issues_log_tracker)
    end

    assert_redirected_to person_issues_log_trackers_url
  end
end
