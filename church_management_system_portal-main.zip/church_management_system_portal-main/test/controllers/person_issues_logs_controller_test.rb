require "test_helper"

class PersonIssuesLogsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_issues_log = person_issues_logs(:one)
  end

  test "should get index" do
    get person_issues_logs_url
    assert_response :success
  end

  test "should get new" do
    get new_person_issues_log_url
    assert_response :success
  end

  test "should create person_issues_log" do
    assert_difference('PersonIssuesLog.count') do
      post person_issues_logs_url, params: { person_issues_log: { created_at: @person_issues_log.created_at, issues_log_desc: @person_issues_log.issues_log_desc, issues_log_title: @person_issues_log.issues_log_title, issues_log_type_id: @person_issues_log.issues_log_type_id, person_assigned_code: @person_issues_log.person_assigned_code, sub_entity_code: @person_issues_log.sub_entity_code, updated_at: @person_issues_log.updated_at } }
    end

    assert_redirected_to person_issues_log_url(PersonIssuesLog.last)
  end

  test "should show person_issues_log" do
    get person_issues_log_url(@person_issues_log)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_issues_log_url(@person_issues_log)
    assert_response :success
  end

  test "should update person_issues_log" do
    patch person_issues_log_url(@person_issues_log), params: { person_issues_log: { created_at: @person_issues_log.created_at, issues_log_desc: @person_issues_log.issues_log_desc, issues_log_title: @person_issues_log.issues_log_title, issues_log_type_id: @person_issues_log.issues_log_type_id, person_assigned_code: @person_issues_log.person_assigned_code, sub_entity_code: @person_issues_log.sub_entity_code, updated_at: @person_issues_log.updated_at } }
    assert_redirected_to person_issues_log_url(@person_issues_log)
  end

  test "should destroy person_issues_log" do
    assert_difference('PersonIssuesLog.count', -1) do
      delete person_issues_log_url(@person_issues_log)
    end

    assert_redirected_to person_issues_logs_url
  end
end
