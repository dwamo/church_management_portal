require "test_helper"

class PersonRelationInfosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_relation_info = person_relation_infos(:one)
  end

  test "should get index" do
    get person_relation_infos_url
    assert_response :success
  end

  test "should get new" do
    get new_person_relation_info_url
    assert_response :success
  end

  test "should create person_relation_info" do
    assert_difference('PersonRelationInfo.count') do
      post person_relation_infos_url, params: { person_relation_info: { active_status: @person_relation_info.active_status, comment: @person_relation_info.comment, created_at: @person_relation_info.created_at, del_status: @person_relation_info.del_status, person_assigned_code: @person_relation_info.person_assigned_code, relation_first_name: @person_relation_info.relation_first_name, relation_last_name: @person_relation_info.relation_last_name, relation_other_names: @person_relation_info.relation_other_names, relation_person_code: @person_relation_info.relation_person_code, relationship_code: @person_relation_info.relationship_code, updated_at: @person_relation_info.updated_at, user_id: @person_relation_info.user_id } }
    end

    assert_redirected_to person_relation_info_url(PersonRelationInfo.last)
  end

  test "should show person_relation_info" do
    get person_relation_info_url(@person_relation_info)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_relation_info_url(@person_relation_info)
    assert_response :success
  end

  test "should update person_relation_info" do
    patch person_relation_info_url(@person_relation_info), params: { person_relation_info: { active_status: @person_relation_info.active_status, comment: @person_relation_info.comment, created_at: @person_relation_info.created_at, del_status: @person_relation_info.del_status, person_assigned_code: @person_relation_info.person_assigned_code, relation_first_name: @person_relation_info.relation_first_name, relation_last_name: @person_relation_info.relation_last_name, relation_other_names: @person_relation_info.relation_other_names, relation_person_code: @person_relation_info.relation_person_code, relationship_code: @person_relation_info.relationship_code, updated_at: @person_relation_info.updated_at, user_id: @person_relation_info.user_id } }
    assert_redirected_to person_relation_info_url(@person_relation_info)
  end

  test "should destroy person_relation_info" do
    assert_difference('PersonRelationInfo.count', -1) do
      delete person_relation_info_url(@person_relation_info)
    end

    assert_redirected_to person_relation_infos_url
  end
end
