require "test_helper"

class PersonRoleMastersControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_role_master = person_role_masters(:one)
  end

  test "should get index" do
    get person_role_masters_url
    assert_response :success
  end

  test "should get new" do
    get new_person_role_master_url
    assert_response :success
  end

  test "should create person_role_master" do
    assert_difference('PersonRoleMaster.count') do
      post person_role_masters_url, params: { person_role_master: { active_status: @person_role_master.active_status, assigned_code: @person_role_master.assigned_code, comment: @person_role_master.comment, created_at: @person_role_master.created_at, del_status: @person_role_master.del_status, entity_code: @person_role_master.entity_code, role_desc: @person_role_master.role_desc, updated_at: @person_role_master.updated_at, user_id: @person_role_master.user_id } }
    end

    assert_redirected_to person_role_master_url(PersonRoleMaster.last)
  end

  test "should show person_role_master" do
    get person_role_master_url(@person_role_master)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_role_master_url(@person_role_master)
    assert_response :success
  end

  test "should update person_role_master" do
    patch person_role_master_url(@person_role_master), params: { person_role_master: { active_status: @person_role_master.active_status, assigned_code: @person_role_master.assigned_code, comment: @person_role_master.comment, created_at: @person_role_master.created_at, del_status: @person_role_master.del_status, entity_code: @person_role_master.entity_code, role_desc: @person_role_master.role_desc, updated_at: @person_role_master.updated_at, user_id: @person_role_master.user_id } }
    assert_redirected_to person_role_master_url(@person_role_master)
  end

  test "should destroy person_role_master" do
    assert_difference('PersonRoleMaster.count', -1) do
      delete person_role_master_url(@person_role_master)
    end

    assert_redirected_to person_role_masters_url
  end
end
