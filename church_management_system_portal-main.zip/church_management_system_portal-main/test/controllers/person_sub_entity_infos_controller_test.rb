require "test_helper"

class PersonSubEntityInfosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @person_sub_entity_info = person_sub_entity_infos(:one)
  end

  test "should get index" do
    get person_sub_entity_infos_url
    assert_response :success
  end

  test "should get new" do
    get new_person_sub_entity_info_url
    assert_response :success
  end

  test "should create person_sub_entity_info" do
    assert_difference('PersonSubEntityInfo.count') do
      post person_sub_entity_infos_url, params: { person_sub_entity_info: { active_status: @person_sub_entity_info.active_status, comment: @person_sub_entity_info.comment, created_at: @person_sub_entity_info.created_at, del_status: @person_sub_entity_info.del_status, person_assigned_code: @person_sub_entity_info.person_assigned_code, sub_entity_code: @person_sub_entity_info.sub_entity_code, updated_at: @person_sub_entity_info.updated_at, user_id: @person_sub_entity_info.user_id } }
    end

    assert_redirected_to person_sub_entity_info_url(PersonSubEntityInfo.last)
  end

  test "should show person_sub_entity_info" do
    get person_sub_entity_info_url(@person_sub_entity_info)
    assert_response :success
  end

  test "should get edit" do
    get edit_person_sub_entity_info_url(@person_sub_entity_info)
    assert_response :success
  end

  test "should update person_sub_entity_info" do
    patch person_sub_entity_info_url(@person_sub_entity_info), params: { person_sub_entity_info: { active_status: @person_sub_entity_info.active_status, comment: @person_sub_entity_info.comment, created_at: @person_sub_entity_info.created_at, del_status: @person_sub_entity_info.del_status, person_assigned_code: @person_sub_entity_info.person_assigned_code, sub_entity_code: @person_sub_entity_info.sub_entity_code, updated_at: @person_sub_entity_info.updated_at, user_id: @person_sub_entity_info.user_id } }
    assert_redirected_to person_sub_entity_info_url(@person_sub_entity_info)
  end

  test "should destroy person_sub_entity_info" do
    assert_difference('PersonSubEntityInfo.count', -1) do
      delete person_sub_entity_info_url(@person_sub_entity_info)
    end

    assert_redirected_to person_sub_entity_infos_url
  end
end
