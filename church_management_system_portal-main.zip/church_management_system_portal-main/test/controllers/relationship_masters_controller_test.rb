require "test_helper"

class RelationshipMastersControllerTest < ActionDispatch::IntegrationTest
  setup do
    @relationship_master = relationship_masters(:one)
  end

  test "should get index" do
    get relationship_masters_url
    assert_response :success
  end

  test "should get new" do
    get new_relationship_master_url
    assert_response :success
  end

  test "should create relationship_master" do
    assert_difference('RelationshipMaster.count') do
      post relationship_masters_url, params: { relationship_master: { active_status: @relationship_master.active_status, assigned_code: @relationship_master.assigned_code, comment: @relationship_master.comment, created_at: @relationship_master.created_at, del_status: @relationship_master.del_status, relationship_desc: @relationship_master.relationship_desc, updated_at: @relationship_master.updated_at, user_id: @relationship_master.user_id } }
    end

    assert_redirected_to relationship_master_url(RelationshipMaster.last)
  end

  test "should show relationship_master" do
    get relationship_master_url(@relationship_master)
    assert_response :success
  end

  test "should get edit" do
    get edit_relationship_master_url(@relationship_master)
    assert_response :success
  end

  test "should update relationship_master" do
    patch relationship_master_url(@relationship_master), params: { relationship_master: { active_status: @relationship_master.active_status, assigned_code: @relationship_master.assigned_code, comment: @relationship_master.comment, created_at: @relationship_master.created_at, del_status: @relationship_master.del_status, relationship_desc: @relationship_master.relationship_desc, updated_at: @relationship_master.updated_at, user_id: @relationship_master.user_id } }
    assert_redirected_to relationship_master_url(@relationship_master)
  end

  test "should destroy relationship_master" do
    assert_difference('RelationshipMaster.count', -1) do
      delete relationship_master_url(@relationship_master)
    end

    assert_redirected_to relationship_masters_url
  end
end
