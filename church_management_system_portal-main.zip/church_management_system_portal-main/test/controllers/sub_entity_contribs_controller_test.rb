require "test_helper"

class SubEntityContribsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @sub_entity_contrib = sub_entity_contribs(:one)
  end

  test "should get index" do
    get sub_entity_contribs_url
    assert_response :success
  end

  test "should get new" do
    get new_sub_entity_contrib_url
    assert_response :success
  end

  test "should create sub_entity_contrib" do
    assert_difference('SubEntityContrib.count') do
      post sub_entity_contribs_url, params: { sub_entity_contrib: { active_status: @sub_entity_contrib.active_status, amount: @sub_entity_contrib.amount, comment: @sub_entity_contrib.comment, contribution_alias: @sub_entity_contrib.contribution_alias, contribution_name: @sub_entity_contrib.contribution_name, contribution_type_code: @sub_entity_contrib.contribution_type_code, created_at: @sub_entity_contrib.created_at, del_status: @sub_entity_contrib.del_status, end_date: @sub_entity_contrib.end_date, start_date: @sub_entity_contrib.start_date, sub_entity_code: @sub_entity_contrib.sub_entity_code, updated_at: @sub_entity_contrib.updated_at, user_id: @sub_entity_contrib.user_id } }
    end

    assert_redirected_to sub_entity_contrib_url(SubEntityContrib.last)
  end

  test "should show sub_entity_contrib" do
    get sub_entity_contrib_url(@sub_entity_contrib)
    assert_response :success
  end

  test "should get edit" do
    get edit_sub_entity_contrib_url(@sub_entity_contrib)
    assert_response :success
  end

  test "should update sub_entity_contrib" do
    patch sub_entity_contrib_url(@sub_entity_contrib), params: { sub_entity_contrib: { active_status: @sub_entity_contrib.active_status, amount: @sub_entity_contrib.amount, comment: @sub_entity_contrib.comment, contribution_alias: @sub_entity_contrib.contribution_alias, contribution_name: @sub_entity_contrib.contribution_name, contribution_type_code: @sub_entity_contrib.contribution_type_code, created_at: @sub_entity_contrib.created_at, del_status: @sub_entity_contrib.del_status, end_date: @sub_entity_contrib.end_date, start_date: @sub_entity_contrib.start_date, sub_entity_code: @sub_entity_contrib.sub_entity_code, updated_at: @sub_entity_contrib.updated_at, user_id: @sub_entity_contrib.user_id } }
    assert_redirected_to sub_entity_contrib_url(@sub_entity_contrib)
  end

  test "should destroy sub_entity_contrib" do
    assert_difference('SubEntityContrib.count', -1) do
      delete sub_entity_contrib_url(@sub_entity_contrib)
    end

    assert_redirected_to sub_entity_contribs_url
  end
end
