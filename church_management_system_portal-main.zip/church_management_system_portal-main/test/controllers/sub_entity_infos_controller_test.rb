require "test_helper"

class SubEntityInfosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @sub_entity_info = sub_entity_infos(:one)
  end

  test "should get index" do
    get sub_entity_infos_url
    assert_response :success
  end

  test "should get new" do
    get new_sub_entity_info_url
    assert_response :success
  end

  test "should create sub_entity_info" do
    assert_difference('SubEntityInfo.count') do
      post sub_entity_infos_url, params: { sub_entity_info: { active_status: @sub_entity_info.active_status, assigned_code: @sub_entity_info.assigned_code, comment: @sub_entity_info.comment, created_at: @sub_entity_info.created_at, del_status: @sub_entity_info.del_status, entity_division_code: @sub_entity_info.entity_division_code, sub_entity_alias: @sub_entity_info.sub_entity_alias, sub_entity_name: @sub_entity_info.sub_entity_name, updated_at: @sub_entity_info.updated_at, user_id: @sub_entity_info.user_id } }
    end

    assert_redirected_to sub_entity_info_url(SubEntityInfo.last)
  end

  test "should show sub_entity_info" do
    get sub_entity_info_url(@sub_entity_info)
    assert_response :success
  end

  test "should get edit" do
    get edit_sub_entity_info_url(@sub_entity_info)
    assert_response :success
  end

  test "should update sub_entity_info" do
    patch sub_entity_info_url(@sub_entity_info), params: { sub_entity_info: { active_status: @sub_entity_info.active_status, assigned_code: @sub_entity_info.assigned_code, comment: @sub_entity_info.comment, created_at: @sub_entity_info.created_at, del_status: @sub_entity_info.del_status, entity_division_code: @sub_entity_info.entity_division_code, sub_entity_alias: @sub_entity_info.sub_entity_alias, sub_entity_name: @sub_entity_info.sub_entity_name, updated_at: @sub_entity_info.updated_at, user_id: @sub_entity_info.user_id } }
    assert_redirected_to sub_entity_info_url(@sub_entity_info)
  end

  test "should destroy sub_entity_info" do
    assert_difference('SubEntityInfo.count', -1) do
      delete sub_entity_info_url(@sub_entity_info)
    end

    assert_redirected_to sub_entity_infos_url
  end
end
