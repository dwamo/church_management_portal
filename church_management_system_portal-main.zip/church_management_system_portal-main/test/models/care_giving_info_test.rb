require "test_helper"

class CareGivingInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
