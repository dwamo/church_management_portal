require "test_helper"

class ContribTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
