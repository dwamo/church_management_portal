require "test_helper"

class DisabilityMasterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
