require "test_helper"

class EntityDivisionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
