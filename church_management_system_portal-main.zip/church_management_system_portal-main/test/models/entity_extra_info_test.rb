require "test_helper"

class EntityExtraInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
