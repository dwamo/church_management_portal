require "test_helper"

class EntityInfoBoardTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
