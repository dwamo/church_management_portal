require "test_helper"

class EntitySubDivisionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
