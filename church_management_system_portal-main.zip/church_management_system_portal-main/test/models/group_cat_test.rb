require "test_helper"

class GroupCatTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
