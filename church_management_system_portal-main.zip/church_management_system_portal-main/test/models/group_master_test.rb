require "test_helper"

class GroupMasterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
