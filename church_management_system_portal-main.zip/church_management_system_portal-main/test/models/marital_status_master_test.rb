require "test_helper"

class MaritalStatusMasterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
