require "test_helper"

class PermissionsRoleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
