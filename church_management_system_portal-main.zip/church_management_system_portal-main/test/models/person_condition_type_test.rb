require "test_helper"

class PersonConditionTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
