require "test_helper"

class PersonContribSetupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
