require "test_helper"

class PersonDisabilityInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
