require "test_helper"

class PersonExitInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
