require "test_helper"

class PersonExitLovTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
