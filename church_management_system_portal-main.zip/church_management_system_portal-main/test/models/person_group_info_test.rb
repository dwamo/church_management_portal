require "test_helper"

class PersonGroupInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
