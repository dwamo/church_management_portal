require "test_helper"

class PersonImageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
