require "test_helper"

class PersonInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
