require "test_helper"

class PersonIssuesLogTrackerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
