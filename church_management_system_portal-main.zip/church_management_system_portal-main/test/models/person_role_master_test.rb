require "test_helper"

class PersonRoleMasterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
