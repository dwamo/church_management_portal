require "test_helper"

class PersonSubEntityInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
