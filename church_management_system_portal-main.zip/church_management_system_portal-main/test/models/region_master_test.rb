require "test_helper"

class RegionMasterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
