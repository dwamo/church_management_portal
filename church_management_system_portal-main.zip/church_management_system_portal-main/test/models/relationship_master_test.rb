require "test_helper"

class RelationshipMasterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
