require "test_helper"

class SubEntityInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
