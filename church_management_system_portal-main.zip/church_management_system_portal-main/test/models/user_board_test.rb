require "test_helper"

class UserBoardTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
