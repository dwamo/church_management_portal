require "application_system_test_case"

class CareGivingInfosTest < ApplicationSystemTestCase
  setup do
    @care_giving_info = care_giving_infos(:one)
  end

  test "visiting the index" do
    visit care_giving_infos_url
    assert_selector "h1", text: "Care Giving Infos"
  end

  test "creating a Care giving info" do
    visit care_giving_infos_url
    click_on "New Care Giving Info"

    check "Active status" if @care_giving_info.active_status
    fill_in "Comment", with: @care_giving_info.comment
    fill_in "Condition type code", with: @care_giving_info.condition_type_code
    fill_in "Created at", with: @care_giving_info.created_at
    check "Del status" if @care_giving_info.del_status
    fill_in "End date", with: @care_giving_info.end_date
    fill_in "Facility name", with: @care_giving_info.facility_name
    fill_in "Facility type", with: @care_giving_info.facility_type
    fill_in "Person assigned code", with: @care_giving_info.person_assigned_code
    fill_in "Start date", with: @care_giving_info.start_date
    fill_in "Updated at", with: @care_giving_info.updated_at
    fill_in "User", with: @care_giving_info.user_id
    click_on "Create Care giving info"

    assert_text "Care giving info was successfully created"
    click_on "Back"
  end

  test "updating a Care giving info" do
    visit care_giving_infos_url
    click_on "Edit", match: :first

    check "Active status" if @care_giving_info.active_status
    fill_in "Comment", with: @care_giving_info.comment
    fill_in "Condition type code", with: @care_giving_info.condition_type_code
    fill_in "Created at", with: @care_giving_info.created_at
    check "Del status" if @care_giving_info.del_status
    fill_in "End date", with: @care_giving_info.end_date
    fill_in "Facility name", with: @care_giving_info.facility_name
    fill_in "Facility type", with: @care_giving_info.facility_type
    fill_in "Person assigned code", with: @care_giving_info.person_assigned_code
    fill_in "Start date", with: @care_giving_info.start_date
    fill_in "Updated at", with: @care_giving_info.updated_at
    fill_in "User", with: @care_giving_info.user_id
    click_on "Update Care giving info"

    assert_text "Care giving info was successfully updated"
    click_on "Back"
  end

  test "destroying a Care giving info" do
    visit care_giving_infos_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Care giving info was successfully destroyed"
  end
end
