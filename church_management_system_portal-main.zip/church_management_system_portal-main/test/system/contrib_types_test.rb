require "application_system_test_case"

class ContribTypesTest < ApplicationSystemTestCase
  setup do
    @contrib_type = contrib_types(:one)
  end

  test "visiting the index" do
    visit contrib_types_url
    assert_selector "h1", text: "Contrib Types"
  end

  test "creating a Contrib type" do
    visit contrib_types_url
    click_on "New Contrib Type"

    check "Active status" if @contrib_type.active_status
    fill_in "Assigned code", with: @contrib_type.assigned_code
    fill_in "Comment", with: @contrib_type.comment
    fill_in "Contribution desc", with: @contrib_type.contribution_desc
    fill_in "Created at", with: @contrib_type.created_at
    check "Del status" if @contrib_type.del_status
    fill_in "Updated at", with: @contrib_type.updated_at
    fill_in "User", with: @contrib_type.user_id
    click_on "Create Contrib type"

    assert_text "Contrib type was successfully created"
    click_on "Back"
  end

  test "updating a Contrib type" do
    visit contrib_types_url
    click_on "Edit", match: :first

    check "Active status" if @contrib_type.active_status
    fill_in "Assigned code", with: @contrib_type.assigned_code
    fill_in "Comment", with: @contrib_type.comment
    fill_in "Contribution desc", with: @contrib_type.contribution_desc
    fill_in "Created at", with: @contrib_type.created_at
    check "Del status" if @contrib_type.del_status
    fill_in "Updated at", with: @contrib_type.updated_at
    fill_in "User", with: @contrib_type.user_id
    click_on "Update Contrib type"

    assert_text "Contrib type was successfully updated"
    click_on "Back"
  end

  test "destroying a Contrib type" do
    visit contrib_types_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Contrib type was successfully destroyed"
  end
end
