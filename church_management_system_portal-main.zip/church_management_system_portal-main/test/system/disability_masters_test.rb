require "application_system_test_case"

class DisabilityMastersTest < ApplicationSystemTestCase
  setup do
    @disability_master = disability_masters(:one)
  end

  test "visiting the index" do
    visit disability_masters_url
    assert_selector "h1", text: "Disability Masters"
  end

  test "creating a Disability master" do
    visit disability_masters_url
    click_on "New Disability Master"

    check "Active status" if @disability_master.active_status
    fill_in "Comment", with: @disability_master.comment
    fill_in "Created at", with: @disability_master.created_at
    check "Del status" if @disability_master.del_status
    fill_in "Disability desc", with: @disability_master.disability_desc
    fill_in "Updated at", with: @disability_master.updated_at
    fill_in "User", with: @disability_master.user_id
    click_on "Create Disability master"

    assert_text "Disability master was successfully created"
    click_on "Back"
  end

  test "updating a Disability master" do
    visit disability_masters_url
    click_on "Edit", match: :first

    check "Active status" if @disability_master.active_status
    fill_in "Comment", with: @disability_master.comment
    fill_in "Created at", with: @disability_master.created_at
    check "Del status" if @disability_master.del_status
    fill_in "Disability desc", with: @disability_master.disability_desc
    fill_in "Updated at", with: @disability_master.updated_at
    fill_in "User", with: @disability_master.user_id
    click_on "Update Disability master"

    assert_text "Disability master was successfully updated"
    click_on "Back"
  end

  test "destroying a Disability master" do
    visit disability_masters_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Disability master was successfully destroyed"
  end
end
